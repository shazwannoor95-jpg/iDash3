/*
 * Copyright (c) 2001-2003 The FFmpeg project
 *
 * first version by Francois Revol (revol@free.fr)
 * fringe ADPCM codecs (e.g., DK3, DK4, Westwood)
 *   by Mike Melanson (melanson@pcisys.net)
 * CD-ROM XA ADPCM codec by BERO
 * EA ADPCM decoder by Robin Kay (komadori@myrealbox.com)
 * EA ADPCM R1/R2/R3 decoder by Peter Ross (pross@xvid.org)
 * EA IMA EACS decoder by Peter Ross (pross@xvid.org)
 * EA IMA SEAD decoder by Peter Ross (pross@xvid.org)
 * EA ADPCM XAS decoder by Peter Ross (pross@xvid.org)
 * MAXIS EA ADPCM decoder by Robert Marston (rmarston@gmail.com)
 * THP ADPCM decoder by Marco Gerards (mgerards@xs4all.nl)
 * Argonaut Games ADPCM decoder by Zane van Iperen (zane@zanevaniperen.com)
 * Simon & Schuster Interactive ADPCM decoder by Zane van Iperen (zane@zanevaniperen.com)
 * Ubisoft ADPCM decoder by Zane van Iperen (zane@zanevaniperen.com)
 * High Voltage Software ALP decoder by Zane van Iperen (zane@zanevaniperen.com)
 * Cunning Developments decoder by Zane van Iperen (zane@zanevaniperen.com)
 * Sanyo LD-ADPCM decoder by Peter Ross (pross@xvid.org)
 * Citrix ADPCM decoder by Peter Ross (pross@xvid.org)
 *
 * This file is part of Librempeg
 *
 * Librempeg is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Librempeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with Librempeg; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "config_components.h"

#include "avcodec.h"
#include "get_bits.h"
#include "bytestream.h"
#include "adpcm.h"
#include "adpcm_data.h"
#include "codec_internal.h"
#include "decode.h"

#include "libavutil/attributes.h"

/**
 * @file
 * ADPCM decoders
 * Features and limitations:
 *
 * Reference documents:
 * http://wiki.multimedia.cx/index.php?title=Category:ADPCM_Audio_Codecs
 * http://www.pcisys.net/~melanson/codecs/simpleaudio.html [dead]
 * http://www.geocities.com/SiliconValley/8682/aud3.txt [dead]
 * http://openquicktime.sourceforge.net/
 * XAnim sources (xa_codec.c) http://xanim.polter.net/
 * http://www.cs.ucla.edu/~leec/mediabench/applications.html [dead]
 * SoX source code http://sox.sourceforge.net/
 *
 * CD-ROM XA:
 * http://ku-www.ss.titech.ac.jp/~yatsushi/xaadpcm.html [dead]
 * vagpack & depack http://homepages.compuserve.de/bITmASTER32/psx-index.html [dead]
 * readstr http://www.geocities.co.jp/Playtown/2004/
 */

#define CASE_0(codec_id, ...)
#define CASE_1(codec_id, ...) \
    case codec_id:            \
    { __VA_ARGS__ }           \
    break;
#define CASE_2(enabled, codec_id, ...) \
        CASE_ ## enabled(codec_id, __VA_ARGS__)
#define CASE_3(config, codec_id, ...) \
        CASE_2(config, codec_id, __VA_ARGS__)
#define CASE(codec, ...) \
        CASE_3(CONFIG_ ## codec ## _DECODER, AV_CODEC_ID_ ## codec, __VA_ARGS__)

/* These are for CD-ROM XA ADPCM */
static const int8_t xa_adpcm_table[5][2] = {
    {   0,   0 },
    {  60,   0 },
    { 115, -52 },
    {  98, -55 },
    { 122, -60 }
};

static const float psx_adpcm_table[5][2] = {
    { 0.0f, 0.0f },
    { 0.9375f, 0.0f },
    { 1.796875f, -0.8125f },
    { 1.53125f, -0.859375f },
    { 1.90625f, -0.9375f },
};

static const int8_t fmod_adpcm_table[8][2] = {
    {   0,   0 },
    {  60,   0 },
    { 122,  60 },
    { 115,  52 },
    {  98,  55 },
};

static const int16_t afc_coeffs[2][16] = {
    { 0, 2048, 0, 1024, 4096, 3584, 3072, 4608, 4200, 4800, 5120, 2048, 1024, -1024, -1024, -2048 },
    { 0, 0, 2048, 1024, -2048, -1536, -1024, -2560, -2248, -2300, -3072, -2048, -1024, 1024, 0, 0 }
};

static const int16_t ea_adpcm_table[] = {
    0,  240,  460,  392,
    0,    0, -208, -220,
    0,    1,    3,    4,
    7,    8,   10,   11,
    0,   -1,   -3,   -4
};

/*
 * Dumped from the binaries:
 * - FantasticJourney.exe - 0x794D2, DGROUP:0x47A4D2
 * - BigRaceUSA.exe       - 0x9B8AA, DGROUP:0x49C4AA
 * - Timeshock!.exe       - 0x8506A, DGROUP:0x485C6A
 */
static const int8_t ima_cunning_index_table[9] = {
    -1, -1, -1, -1, 1, 2, 3, 4, -1
};

/*
 * Dumped from the binaries:
 * - FantasticJourney.exe - 0x79458, DGROUP:0x47A458
 * - BigRaceUSA.exe       - 0x9B830, DGROUP:0x49C430
 * - Timeshock!.exe       - 0x84FF0, DGROUP:0x485BF0
 */
static const int16_t ima_cunning_step_table[61] = {
       1,    1,   1,      1,     2,     2,     3,     3,    4,      5,
       6,    7,   8,     10,    12,    14,    16,    20,    24,    28,
      32,   40,  48,     56,    64,    80,    96,   112,   128,   160,
     192,  224,  256,   320,   384,   448,   512,   640,   768,   896,
    1024, 1280, 1536,  1792,  2048,  2560,  3072,  3584,  4096,  5120,
    6144, 7168, 8192, 10240, 12288, 14336, 16384, 20480, 24576, 28672, 0
};

static const int8_t adpcm_index_table2[4] = {
    -1,  2,
    -1,  2,
};

static const int8_t adpcm_index_table3[8] = {
    -1, -1,  1,  2,
    -1, -1,  1,  2,
};

static const int8_t adpcm_index_table5[32] = {
    -1, -1, -1, -1, -1, -1, -1, -1, 1, 2, 4, 6, 8, 10, 13, 16,
    -1, -1, -1, -1, -1, -1, -1, -1, 1, 2, 4, 6, 8, 10, 13, 16,
};

static const int8_t * const adpcm_index_tables[4] = {
    &adpcm_index_table2[0],
    &adpcm_index_table3[0],
    &ff_adpcm_index_table[0],
    &adpcm_index_table5[0],
};

static const int16_t mtaf_stepsize[32][16] = {
    {     1,     5,     9,    13,    16,    20,    24,    28,
         -1,    -5,    -9,   -13,   -16,   -20,   -24,   -28, },
    {     2,     6,    11,    15,    20,    24,    29,    33,
         -2,    -6,   -11,   -15,   -20,   -24,   -29,   -33, },
    {     2,     7,    13,    18,    23,    28,    34,    39,
         -2,    -7,   -13,   -18,   -23,   -28,   -34,   -39, },
    {     3,     9,    15,    21,    28,    34,    40,    46,
         -3,    -9,   -15,   -21,   -28,   -34,   -40,   -46, },
    {     3,    11,    18,    26,    33,    41,    48,    56,
         -3,   -11,   -18,   -26,   -33,   -41,   -48,   -56, },
    {     4,    13,    22,    31,    40,    49,    58,    67,
         -4,   -13,   -22,   -31,   -40,   -49,   -58,   -67, },
    {     5,    16,    26,    37,    48,    59,    69,    80,
         -5,   -16,   -26,   -37,   -48,   -59,   -69,   -80, },
    {     6,    19,    31,    44,    57,    70,    82,    95,
         -6,   -19,   -31,   -44,   -57,   -70,   -82,   -95, },
    {     7,    22,    38,    53,    68,    83,    99,   114,
         -7,   -22,   -38,   -53,   -68,   -83,   -99,  -114, },
    {     9,    27,    45,    63,    81,    99,   117,   135,
         -9,   -27,   -45,   -63,   -81,   -99,  -117,  -135, },
    {    10,    32,    53,    75,    96,   118,   139,   161,
        -10,   -32,   -53,   -75,   -96,  -118,  -139,  -161, },
    {    12,    38,    64,    90,   115,   141,   167,   193,
        -12,   -38,   -64,   -90,  -115,  -141,  -167,  -193, },
    {    15,    45,    76,   106,   137,   167,   198,   228,
        -15,   -45,   -76,  -106,  -137,  -167,  -198,  -228, },
    {    18,    54,    91,   127,   164,   200,   237,   273,
        -18,   -54,   -91,  -127,  -164,  -200,  -237,  -273, },
    {    21,    65,   108,   152,   195,   239,   282,   326,
        -21,   -65,  -108,  -152,  -195,  -239,  -282,  -326, },
    {    25,    77,   129,   181,   232,   284,   336,   388,
        -25,   -77,  -129,  -181,  -232,  -284,  -336,  -388, },
    {    30,    92,   153,   215,   276,   338,   399,   461,
        -30,   -92,  -153,  -215,  -276,  -338,  -399,  -461, },
    {    36,   109,   183,   256,   329,   402,   476,   549,
        -36,  -109,  -183,  -256,  -329,  -402,  -476,  -549, },
    {    43,   130,   218,   305,   392,   479,   567,   654,
        -43,  -130,  -218,  -305,  -392,  -479,  -567,  -654, },
    {    52,   156,   260,   364,   468,   572,   676,   780,
        -52,  -156,  -260,  -364,  -468,  -572,  -676,  -780, },
    {    62,   186,   310,   434,   558,   682,   806,   930,
        -62,  -186,  -310,  -434,  -558,  -682,  -806,  -930, },
    {    73,   221,   368,   516,   663,   811,   958,  1106,
        -73,  -221,  -368,  -516,  -663,  -811,  -958, -1106, },
    {    87,   263,   439,   615,   790,   966,  1142,  1318,
        -87,  -263,  -439,  -615,  -790,  -966, -1142, -1318, },
    {   104,   314,   523,   733,   942,  1152,  1361,  1571,
       -104,  -314,  -523,  -733,  -942, -1152, -1361, -1571, },
    {   124,   374,   623,   873,  1122,  1372,  1621,  1871,
       -124,  -374,  -623,  -873, -1122, -1372, -1621, -1871, },
    {   148,   445,   743,  1040,  1337,  1634,  1932,  2229,
       -148,  -445,  -743, -1040, -1337, -1634, -1932, -2229, },
    {   177,   531,   885,  1239,  1593,  1947,  2301,  2655,
       -177,  -531,  -885, -1239, -1593, -1947, -2301, -2655, },
    {   210,   632,  1053,  1475,  1896,  2318,  2739,  3161,
       -210,  -632, -1053, -1475, -1896, -2318, -2739, -3161, },
    {   251,   753,  1255,  1757,  2260,  2762,  3264,  3766,
       -251,  -753, -1255, -1757, -2260, -2762, -3264, -3766, },
    {   299,   897,  1495,  2093,  2692,  3290,  3888,  4486,
       -299,  -897, -1495, -2093, -2692, -3290, -3888, -4486, },
    {   356,  1068,  1781,  2493,  3206,  3918,  4631,  5343,
       -356, -1068, -1781, -2493, -3206, -3918, -4631, -5343, },
    {   424,  1273,  2121,  2970,  3819,  4668,  5516,  6365,
       -424, -1273, -2121, -2970, -3819, -4668, -5516, -6365, },
};

static const int16_t oki_step_table[49] = {
     16,  17,  19,  21,   23,   25,   28,   31,   34,  37,
     41,  45,  50,  55,   60,   66,   73,   80,   88,  97,
    107, 118, 130, 143,  157,  173,  190,  209,  230, 253,
    279, 307, 337, 371,  408,  449,  494,  544,  598, 658,
    724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552
};

// padded to zero where table size is less then 16
static const int8_t swf_index_tables[4][16] = {
    /*2*/ { -1, 2 },
    /*3*/ { -1, -1, 2, 4 },
    /*4*/ { -1, -1, -1, -1, 2, 4, 6, 8 },
    /*5*/ { -1, -1, -1, -1, -1, -1, -1, -1, 1, 2, 4, 6, 8, 10, 13, 16 }
};

static const int8_t zork_index_table[8] = {
    -1, -1, -1, 1, 4, 7, 10, 12,
};

static const int8_t mtf_index_table[16] = {
     8,  6,  4,  2, -1, -1, -1, -1,
    -1, -1, -1, -1,  2,  4,  6,  8,
};

static const int8_t citrix_index_table[4] = {
    -1, 1, -1, 1,
};

static const int32_t dsa_coefs[16] = {
    0x0,     0x1999,  0x3333,  0x4CCC,
    0x6666,  0x8000,  0x9999,  0xB333,
    0xCCCC,  0xE666,  0x10000, 0x11999,
    0x13333, 0x18000, 0x1CCCC, 0x21999
};

static const float hevag_coefs[128][4] = {
    {-0.0f, -0.0f, -0.0f, -0.0f },
    { 0.9375f, -0.0f, -0.0f, -0.0f },
    { 1.796875f, -0.8125f, -0.0f, -0.0f },
    { 1.53125f, -0.859375f, -0.0f, -0.0f },
    { 1.90625f, -0.9375f, -0.0f, -0.0f },
    { 1.7982178f, -0.86169434f, -0.0f, -0.0f },
    { 1.770874f, -0.89916992f, -0.0f, -0.0f },
    { 1.6992188f, -0.91821289f, -0.0f, -0.0f },
    { 1.6031494f, -0.9375f, -0.0f, -0.0f },
    { 1.4682617f, -0.9375f, -0.0f, -0.0f },
    { 1.3139648f, -0.9375f, -0.0f, -0.0f },
    { 1.1424561f, -0.9375f, -0.0f, -0.0f },
    { 0.95605469f, -0.9375f, -0.0f, -0.0f },
    { 0.75695801f, -0.9375f, -0.0f, -0.0f },
    { 0.54785156f, -0.9375f, -0.0f, -0.0f },
    { 0.33166504f, -0.9375f, -0.0f, -0.0f },
    { 0.11108398f, -0.9375f, -0.0f, -0.0f },
    {-0.11108398f, -0.9375f, -0.0f, -0.0f },
    {-0.33166504f, -0.9375f, -0.0f, -0.0f },
    {-0.54785156f, -0.9375f, -0.0f, -0.0f },
    {-0.75695801f, -0.9375f, -0.0f, -0.0f },
    {-0.95605469f, -0.9375f, -0.0f, -0.0f },
    {-1.1424561f, -0.9375f, -0.0f, -0.0f },
    {-1.3139648f, -0.9375f, -0.0f, -0.0f },
    {-1.4682617f, -0.9375f, -0.0f, -0.0f },
    {-1.6031494f, -0.9375f, -0.0f, -0.0f },
    {-1.6992188f, -0.91821289f, -0.0f, -0.0f },
    {-1.770874f, -0.89916992f, -0.0f, -0.0f },
    {-1.7982178f, -0.86169434f, -0.0f, -0.0f },
    { 0.65625f, -1.125f, 0.40625f, -0.375f },
    {-0.78125f, -0.875f, -0.40625f, -0.28125f },
    {-1.28125f, -0.90625f, -0.4375f, -0.125f },
    {-0.020385742f, -0.33227539f, -0.060302734f, -0.066040039f },
    {-0.90698242f, -0.27111816f, -0.28051758f, 0.051757812f },
    {-0.97668457f, -0.38647461f, -0.34350586f, 0.03527832f },
    { 0.73461914f, -0.57983398f, 0.32336426f, -0.15844727f },
    { 0.46362305f, -0.84790039f, 0.47302246f, -0.1484375f },
    {-1.0054932f, -0.31689453f, -0.25280762f, 0.027709961f },
    { 1.1229248f, 0.24194336f, -0.16870117f, -0.28271484f },
    { 1.5894775f, -0.37158203f, -0.46289062f, 0.15466309f },
    { 1.6005859f, -0.54772949f, -0.2746582f, 0.20324707f },
    {-0.20361328f, -0.45703125f, -0.78808594f, 0.10253906f },
    { 0.95446777f, -0.52832031f, 0.25769043f, -0.061767578f },
    { 1.168335f, -0.16308594f, -0.092407227f, 0.059448242f },
    { 1.2246094f, -0.31274414f, 0.036621094f, 0.024291992f },
    {-0.57922363f, -0.50317383f, -0.66967773f, -0.18225098f },
    {-0.71972656f, 0.2902832f, -0.58435059f, -0.84802246f },
    {-0.14562988f, -1.112915f, -0.15100098f, -0.38012695f },
    { 0.33972168f, -0.86767578f, -0.19226074f, -0.17663574f },
    {-0.89526367f, -0.25170898f, -0.27001953f, 0.054443359f },
    { 0.7479248f, -0.3145752f, -0.038452148f, -0.0021972656f },
    { 1.1544189f, -0.22680664f, 0.012451172f, 0.031494141f },
    { 0.96142578f, -0.54724121f, 0.25952148f, -0.065673828f },
    {-0.87548828f, -0.21911621f, -0.25256348f, 0.058837891f },
    {-0.89819336f, -0.2565918f, -0.27258301f, 0.053710938f },
    {-1.1193848f, -0.42834473f, -0.32641602f, -0.047729492f },
    {-0.32202148f, -0.32312012f, -0.23547363f, -0.1998291f },
    { 0.2286377f, 1.1209717f, 0.22705078f, -0.70141602f },
    { 1.1247559f, 0.22692871f, -0.13720703f, -0.29626465f },
    { 1.6118164f, -0.36767578f, -0.50524902f, 0.16723633f },
    { 1.5181885f, -0.58496094f, -0.03125f, 0.075927734f },
    {-0.32385254f, -0.13964844f, -0.38842773f, -0.83959961f },
    { 1.1390381f, -0.12792969f, -0.10107422f, 0.061889648f },
    { 0.20043945f, -0.075683594f, -0.11547852f, -0.51623535f },
    { 0.51831055f, -0.92590332f, -0.065063477f, -0.27575684f },
    {-1.097168f, -0.47497559f, -0.34265137f, 0.0053710938f },
    {-0.31274414f, -0.3338623f, -0.21118164f, -0.23181152f },
    { 0.38842773f, -0.058959961f, -0.087158203f, -0.17346191f },
    { 0.96887207f, -0.46923828f, 0.34436035f, -0.12438965f },
    { 1.229126f, -0.31848145f, 0.038330078f, 0.023803711f },
    { 1.0253906f, -0.40246582f, 0.18933105f, -0.018920898f },
    {-1.0411377f, -0.33874512f, -0.296875f, -0.041015625f },
    { 1.1568604f, -0.22973633f, 0.013183594f, 0.03125f },
    { 0.0091552734f, -0.27355957f, -0.036376953f, -0.84680176f },
    {-1.1160889f, -0.5078125f, -0.36169434f, 0.00061035156f },
    {-0.88745117f, -0.23901367f, -0.26318359f, 0.056152344f },
    {-0.33447266f, 0.45715332f, 0.72460938f, -0.13293457f },
    { 1.0977783f, 0.23779297f, -0.083374023f, -0.33007812f },
    { 1.5992432f, -0.34606934f, -0.47045898f, 0.12878418f },
    { 1.164917f, -0.23937988f, 0.015869141f, 0.030517578f },
    { 0.64355469f, -0.52124023f, 0.38134766f, -0.38537598f },
    {-0.93945312f, -0.41296387f, -0.3548584f, -0.055664062f },
    { 0.89221191f, 0.3079834f, 0.052978516f, -0.30041504f },
    { 1.2542725f, -0.34997559f, 0.047729492f, 0.020996094f },
    { 1.3354492f, -0.45422363f, 0.081176758f, 0.01184082f },
    { 0.0029296875f, -0.037841797f, -0.15405273f, 0.0390625f },
    {-0.99145508f, -0.29431152f, -0.28210449f, -0.033081055f },
    {-1.0389404f, -0.37438965f, -0.28527832f, 0.019897461f },
    { 0.039794922f, -0.46948242f, 0.051147461f, -0.1138916f },
    { 1.0858154f, 0.26782227f, -0.066040039f, -0.3515625f },
    { 1.4737549f, -0.22900391f, -0.24621582f, -0.073364258f },
    { 1.0655518f, -0.41784668f, 0.2043457f, -0.020629883f },
    { 1.5808105f, -0.46960449f, -0.36706543f, 0.23754883f },
    { 1.2253418f, -0.3137207f, 0.036865234f, 0.024169922f },
    { 1.1456299f, -0.33654785f, 0.12304688f, 0.0050048828f },
    {-0.57617188f, -0.61108398f, -0.34814453f, -0.14172363f },
    { 0.96057129f, -0.52807617f, 0.26062012f, -0.061157227f },
    { 0.29907227f, -1.0494385f, 0.15856934f, -0.33935547f },
    { 1.2441406f, -0.33728027f, 0.043945312f, 0.022094727f },
    { 1.3809814f, -0.51428223f, 0.10168457f, 0.0064697266f },
    { 1.239502f, -0.33154297f, 0.042114258f, 0.022583008f },
    { 1.1765137f, -0.17297363f, -0.08996582f, 0.058837891f },
    { 0.47045898f, -0.5559082f, 0.3470459f, -0.41467285f },
    { 0.81774902f, -0.6907959f, 0.27453613f, -0.13110352f },
    { 1.3527832f, -0.47705078f, 0.088867188f, 0.009765625f },
    {-0.12524414f, -1.1975098f, -0.098266602f, -0.42260742f },
    { 1.269043f, -0.45727539f, 0.16687012f, -0.01171875f },
    { 1.2557373f, 0.12060547f, -0.23376465f, -0.17541504f },
    { 0.9708252f, 0.47338867f, -0.093261719f, -0.39831543f },
    { 1.5489502f, -0.4119873f, -0.40942383f, 0.25378418f },
    { 0.81066895f, 0.38647461f, 0.028198242f, -0.25500488f },
    {-0.28662109f, -0.89770508f, -0.23730469f, -0.50317383f },
    { 1.1340332f, -0.49304199f, 0.23010254f, -0.030029297f },
    { 0.56555176f, -0.78161621f, 0.21337891f, -0.19763184f },
    { 1.3729248f, -0.50354004f, 0.097900391f, 0.0074462891f },
    { 1.1971436f, -0.27880859f, 0.026733398f, 0.027099609f },
    { 1.1884766f, -0.1875f, -0.086181641f, 0.057739258f },
    { 1.0302734f, -0.41943359f, 0.19067383f, -0.021484375f },
    { 1.1361084f, -0.12463379f, -0.10192871f, 0.062133789f },
    { 0.20727539f, -1.1016846f, 0.083984375f, -0.37072754f },
    { 1.2468262f, -0.34069824f, 0.044921875f, 0.021850586f },
    { 1.0241699f, 0.39648438f, -0.092529297f, -0.36486816f },
    { 0.87902832f, 0.40478516f, 0.0056152344f, -0.3190918f },
    {-0.010742188f, -0.95324707f, -0.065673828f, -0.5579834f },
    { 0.75598145f, -0.63342285f, 0.33691406f, -0.15197754f },
    { 1.5045166f, -0.1574707f, -0.40087891f, 0.030883789f },
    { 1.5947266f, -0.49743652f, -0.34472656f, 0.22912598f },
    { 0.65100098f, 0.36608887f, 0.094604492f, -0.13818359f },
};

static const uint8_t adpcmb_yamaha_indexscale[16] =
{
    57, 57, 57, 57, 77, 102, 128, 153,
    57, 57, 57, 57, 77, 102, 128, 153,
};

static const float adpcm_mta2_k0[8] = { 0.0, 0.9375, 1.796875, 1.53125, 1.90625, 1.796875, 1.796875, 0.9375 };
static const float adpcm_mta2_k1[8] = { -0.0, -0.0, -0.8125, -0.859375, -0.9375, -0.9375, -0.859375, -0.40625 };
static const float adpcm_mta2_ranges[32] = {
       1.0,   1.3125,    1.6875,     2.25,   2.9375,   3.8125,       5.0,   6.5625,
    8.5625,  11.1875,    14.625,   19.125,     25.0,    32.75,   42.8125,  55.9375,
   73.1875,  95.6875,  125.1875, 163.6875, 214.0625, 279.9375,   366.125, 478.8125,
   626.125, 818.8125, 1070.8125, 1400.375, 1831.375,   2395.0, 3132.0625,   4096.0
};

static const int16_t rhetorex_step[128] = {
       40,   130,   232,   350,   493,   673,   927,  1382,
       60,   195,   348,   526,   740,  1010,  1391,  2074,
       85,   277,   494,   745,  1048,  1431,  1971,  2938,
      121,   391,   697,  1052,  1480,  2021,  2782,  4148,
      176,   570,  1017,  1535,  2158,  2947,  4058,  6050,
      257,   831,  1482,  2236,  3145,  4295,  5913,  8815,
      373,  1206,  2151,  3245,  4564,  6232,  8579, 12791,
      534,  1728,  3082,  4649,  6538,  8928, 12290, 18323,
      782,  2527,  4507,  6798,  9560, 13055, 17971, 26793,
     1115,  3603,  6426,  9692, 13631, 18614, 25623, 32767,
     1620,  5233,  9334, 14078, 19799, 27036, 32767, 32767,
     2361,  7630, 13608, 20526, 28866, 32767, 32767, 32767,
     3447, 11136, 19860, 29955, 32767, 32767, 32767, 32767,
     4865, 15717, 28031, 32767, 32767, 32767, 32767, 32767,
     6888, 22255, 32767, 32767, 32767, 32767, 32767, 32767,
   -10336, 32144,  5984,-24288,  4752, 24112, 24688,-26336,
};

static const int16_t rhetorex_index[8] = {
    -83, -55, -27, 163, 374, 677, 1864, 3408,
};

/* end of tables */

typedef struct ADPCMDecodeContext {
    ADPCMChannelStatus status[16];
    int table[14][16];
    int start_skip;
    int vqa_version;                /**< VQA version. Used for ADPCM_IMA_WS */
    int block_size;                 /**< Block size for THP codecs */
} ADPCMDecodeContext;

static void adpcm_flush(AVCodecContext *avctx);

static av_cold int adpcm_decode_init(AVCodecContext * avctx)
{
    ADPCMDecodeContext *c = avctx->priv_data;
    unsigned int min_channels = 1;
    unsigned int max_channels = 2;

    adpcm_flush(avctx);

    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_BRR:
    case AV_CODEC_ID_ADPCM_IMA_AMV:
    case AV_CODEC_ID_ADPCM_N64:
    case AV_CODEC_ID_ADPCM_IMA_WV6:
    case AV_CODEC_ID_ADPCM_RHETOREX:
        max_channels = 1;
        break;
    case AV_CODEC_ID_ADPCM_AFC:
    case AV_CODEC_ID_ADPCM_EA_R1:
    case AV_CODEC_ID_ADPCM_EA_R2:
    case AV_CODEC_ID_ADPCM_EA_R3:
    case AV_CODEC_ID_ADPCM_EA_XAS:
    case AV_CODEC_ID_ADPCM_MS:
    case AV_CODEC_ID_ADPCM_MS_MONO:
    case AV_CODEC_ID_ADPCM_CKMK:
    case AV_CODEC_ID_ADPCM_IMA_FSB:
    case AV_CODEC_ID_ADPCM_IMA_XBOX:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_MONO:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_SBR:
    case AV_CODEC_ID_ADPCM_IMA_WW:
        max_channels = 6;
        break;
    case AV_CODEC_ID_ADPCM_MTAF:
        min_channels = 2;
        max_channels = 8;
        if (avctx->ch_layout.nb_channels & 1) {
            avpriv_request_sample(avctx, "channel count %d", avctx->ch_layout.nb_channels);
            return AVERROR_PATCHWELCOME;
        }
        break;
    case AV_CODEC_ID_ADPCM_DTK:
        min_channels = 2;
        break;
    case AV_CODEC_ID_ADPCM_HEVAG:
    case AV_CODEC_ID_ADPCM_PSX:
        max_channels = 8;
        if (avctx->ch_layout.nb_channels <= 0 ||
            avctx->block_align % (16 * avctx->ch_layout.nb_channels))
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_FMOD:
    case AV_CODEC_ID_ADPCM_PSXC:
        max_channels = 8;
        if (avctx->ch_layout.nb_channels <= 0)
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_IMA_WAV_MONO:
    case AV_CODEC_ID_ADPCM_IMA_DAT4:
    case AV_CODEC_ID_ADPCM_NXAP:
    case AV_CODEC_ID_ADPCM_THP:
    case AV_CODEC_ID_ADPCM_THP_LE:
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_LE:
    case AV_CODEC_ID_ADPCM_NDSP_SI:
    case AV_CODEC_ID_ADPCM_NDSP_SI1:
        max_channels = 14;
        break;
    case AV_CODEC_ID_ADPCM_MTA2:
        max_channels = 16;
        break;
    }
    if (avctx->ch_layout.nb_channels < min_channels ||
        avctx->ch_layout.nb_channels > max_channels) {
        av_log(avctx, AV_LOG_ERROR, "Invalid number of channels\n");
        return AVERROR(EINVAL);
    }

    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_IMA_WAV_MONO:
    case AV_CODEC_ID_ADPCM_IMA_WAV:
        if (avctx->bits_per_coded_sample < 2 || avctx->bits_per_coded_sample > 5)
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_ARGO:
        if (avctx->bits_per_coded_sample != 4 ||
            avctx->block_align != 17 * avctx->ch_layout.nb_channels)
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_SANYO:
        if (avctx->bits_per_coded_sample < 3 || avctx->bits_per_coded_sample > 5)
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_ZORK:
        if (avctx->bits_per_coded_sample != 8)
            return AVERROR_INVALIDDATA;
        break;
    case AV_CODEC_ID_ADPCM_IMA_CITRIX:
        if (avctx->bits_per_coded_sample != 2)
            return AVERROR_INVALIDDATA;
        break;
    default:
        break;
    }

    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_AICA:
    case AV_CODEC_ID_ADPCM_IMA_CUNNING:
    case AV_CODEC_ID_ADPCM_IMA_DAT4:
    case AV_CODEC_ID_ADPCM_IMA_QT:
    case AV_CODEC_ID_ADPCM_IMA_WAV_MONO:
    case AV_CODEC_ID_ADPCM_IMA_WAV:
    case AV_CODEC_ID_ADPCM_IMA_RAUD:
    case AV_CODEC_ID_ADPCM_IMA_AWC:
    case AV_CODEC_ID_ADPCM_IMA_FSB:
    case AV_CODEC_ID_ADPCM_IMA_XBOX:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_MONO:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_SBR:
    case AV_CODEC_ID_ADPCM_IMA_WW:
    case AV_CODEC_ID_ADPCM_4XM:
    case AV_CODEC_ID_ADPCM_DSA:
    case AV_CODEC_ID_ADPCM_XA:
    case AV_CODEC_ID_ADPCM_XA8:
    case AV_CODEC_ID_ADPCM_XMD:
    case AV_CODEC_ID_ADPCM_EA_R1:
    case AV_CODEC_ID_ADPCM_EA_R2:
    case AV_CODEC_ID_ADPCM_EA_R3:
    case AV_CODEC_ID_ADPCM_EA_XAS:
    case AV_CODEC_ID_ADPCM_TANTALUS:
    case AV_CODEC_ID_ADPCM_THP:
    case AV_CODEC_ID_ADPCM_THP_LE:
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_LE:
    case AV_CODEC_ID_ADPCM_NDSP_SI:
    case AV_CODEC_ID_ADPCM_AFC:
    case AV_CODEC_ID_ADPCM_DTK:
    case AV_CODEC_ID_ADPCM_PROCYON:
    case AV_CODEC_ID_ADPCM_HEVAG:
    case AV_CODEC_ID_ADPCM_PSX:
    case AV_CODEC_ID_ADPCM_PSXC:
    case AV_CODEC_ID_ADPCM_SANYO:
    case AV_CODEC_ID_ADPCM_MTA2:
    case AV_CODEC_ID_ADPCM_MTAF:
    case AV_CODEC_ID_ADPCM_ARGO:
    case AV_CODEC_ID_ADPCM_IMA_MO:
    case AV_CODEC_ID_ADPCM_IMA_MOFLEX:
    case AV_CODEC_ID_ADPCM_N64:
    case AV_CODEC_ID_ADPCM_FMOD:
    case AV_CODEC_ID_ADPCM_IMA_NDS:
    case AV_CODEC_ID_ADPCM_IMA_RAD_MONO:
    case AV_CODEC_ID_ADPCM_IMA_REF:
    case AV_CODEC_ID_ADPCM_BRR:
    case AV_CODEC_ID_ADPCM_IMA:
    case AV_CODEC_ID_ADPCM_IMA_DVI:
    case AV_CODEC_ID_ADPCM_IMA_TRA:
    case AV_CODEC_ID_ADPCM_IMA_HWAS:
    case AV_CODEC_ID_ADPCM_NXAP:
    case AV_CODEC_ID_ADPCM_CKMK:
    case AV_CODEC_ID_ADPCM_MS_MONO:
        avctx->sample_fmt = AV_SAMPLE_FMT_S16P;
        break;
    case AV_CODEC_ID_ADPCM_IMA_WS:
        avctx->sample_fmt = c->vqa_version >= 3 ? AV_SAMPLE_FMT_S16P :
                                                  AV_SAMPLE_FMT_S16;
        break;
    case AV_CODEC_ID_ADPCM_MS:
        avctx->sample_fmt = avctx->ch_layout.nb_channels > 2 ? AV_SAMPLE_FMT_S16P :
                                                  AV_SAMPLE_FMT_S16;
        break;
    default:
        avctx->sample_fmt = AV_SAMPLE_FMT_S16;
    }

    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_LE:
    case AV_CODEC_ID_ADPCM_NDSP_SI:
    case AV_CODEC_ID_ADPCM_NDSP_SI1:
        if (avctx->extradata_size < 32 * avctx->ch_layout.nb_channels) {
            av_log(avctx, AV_LOG_ERROR, "Missing coeff table\n");
            return AVERROR_INVALIDDATA;
        }
        break;
    }

    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_SI:
    case AV_CODEC_ID_ADPCM_NDSP_SI1:
        for (int ch = 0; ch < avctx->ch_layout.nb_channels && avctx->extradata; ch++) {
            for (int n = 0; n < 16; n++)
                c->table[ch][n] = sign_extend(AV_RB16(avctx->extradata + ch * 32 + n * 2), 16);
        }
        if (avctx->extradata_size > 32 * avctx->ch_layout.nb_channels)
            c->start_skip = avctx->extradata[32 * avctx->ch_layout.nb_channels];
        break;
    case AV_CODEC_ID_ADPCM_NDSP_LE:
        for (int ch = 0; ch < avctx->ch_layout.nb_channels && avctx->extradata; ch++) {
            for (int n = 0; n < 16; n++)
                c->table[ch][n] = sign_extend(AV_RL16(avctx->extradata + ch * 32 + n * 2), 16);
        }
        if (avctx->extradata_size > 32 * avctx->ch_layout.nb_channels)
            c->start_skip = avctx->extradata[32 * avctx->ch_layout.nb_channels];
        break;
    default:
        break;
    }

    return 0;
}

static inline int16_t adpcm_agm_expand_nibble(ADPCMChannelStatus *c, int8_t nibble)
{
    int delta, pred, step, add;

    pred = c->predictor;
    delta = nibble & 7;
    step = c->step;
    add = (delta * 2 + 1) * step;
    if (add < 0)
        add = add + 7;

    if ((nibble & 8) == 0)
        pred = av_clip(pred + (add >> 3), -32767, 32767);
    else
        pred = av_clip(pred - (add >> 3), -32767, 32767);

    switch (delta) {
    case 7:
        step *= 0x99;
        break;
    case 6:
        c->step = av_clip(c->step * 2, 127, 24576);
        c->predictor = pred;
        return pred;
    case 5:
        step *= 0x66;
        break;
    case 4:
        step *= 0x4d;
        break;
    default:
        step *= 0x39;
        break;
    }

    if (step < 0)
        step += 0x3f;

    c->step = step >> 6;
    c->step = av_clip(c->step, 127, 24576);
    c->predictor = pred;
    return pred;
}

static inline int16_t adpcm_ima_escape_expand_nibble(ADPCMChannelStatus *c, int8_t nibble)
{
    int step_index;
    int predictor;
    int sign, delta, diff, step;

    step = ff_adpcm_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 88);

    sign = nibble & 8;
    delta = nibble & 7;
    diff = (delta * step) >> 2;
    predictor = c->predictor;
    if (sign) predictor -= diff;
    else predictor += diff;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return (int16_t)c->predictor;
}

static inline int16_t adpcm_ima_expand_nibble(ADPCMChannelStatus *c, int8_t nibble, int shift)
{
    int step_index;
    int predictor;
    int sign, delta, diff, step;

    step = ff_adpcm_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 88);

    sign = nibble & 8;
    delta = nibble & 7;
    /* perform direct multiplication instead of series of jumps proposed by
     * the reference ADPCM implementation since modern CPUs can do the mults
     * quickly enough */
    diff = ((2 * delta + 1) * step) >> shift;
    predictor = c->predictor;
    if (sign) predictor -= diff;
    else predictor += diff;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return (int16_t)c->predictor;
}

static inline int16_t adpcm_ima_alp_expand_nibble(ADPCMChannelStatus *c, int8_t nibble, int shift)
{
    int step_index;
    int predictor;
    int sign, delta, diff, step;

    step = ff_adpcm_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 88);

    sign = nibble & 8;
    delta = nibble & 7;
    diff = (delta * step) >> shift;
    predictor = c->predictor;
    if (sign) predictor -= diff;
    else predictor += diff;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return (int16_t)c->predictor;
}

static inline int16_t adpcm_ima_mtf_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int step_index, step, delta, predictor;

    step = ff_adpcm_step_table[c->step_index];

    delta = step * (2 * nibble - 15);
    predictor = c->predictor + delta;

    step_index = c->step_index + mtf_index_table[(unsigned)nibble];
    c->predictor = av_clip_int16(predictor >> 4);
    c->step_index = av_clip(step_index, 0, 88);

    return (int16_t)c->predictor;
}

static inline int16_t adpcm_ima_cunning_expand_nibble(ADPCMChannelStatus *c, int8_t nibble)
{
    int step_index;
    int predictor;
    int step;

    nibble = sign_extend(nibble & 0xF, 4);

    step = ima_cunning_step_table[c->step_index];
    step_index = c->step_index + ima_cunning_index_table[abs(nibble)];
    step_index = av_clip(step_index, 0, 60);

    predictor = c->predictor + step * nibble;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return c->predictor;
}

static inline int16_t adpcm_ima_wav_expand_nibble(ADPCMChannelStatus *c, GetBitContext *gb, int bps)
{
    int nibble, step_index, predictor, sign, delta, diff, step, shift;

    shift = bps - 1;
    nibble = get_bits_le(gb, bps),
    step = ff_adpcm_step_table[c->step_index];
    step_index = c->step_index + adpcm_index_tables[bps - 2][nibble];
    step_index = av_clip(step_index, 0, 88);

    sign = nibble & (1 << shift);
    delta = av_zero_extend(nibble, shift);
    diff = step >> shift;
    for (int i = 0; i < shift; i++)
        diff += (step >> (shift-1-i)) * !!(delta & (1 << i));
    predictor = c->predictor;
    if (sign) predictor -= diff;
    else predictor += diff;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return (int16_t)c->predictor;
}

int16_t ff_adpcm_ima_qt_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int predictor = c->predictor;
    int step_index;
    int diff, step;

    step = ff_adpcm_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[nibble];
    step_index = av_clip(step_index, 0, 88);

    diff = step >> 3;
    if (nibble & 4) diff += step;
    if (nibble & 2) diff += step >> 1;
    if (nibble & 1) diff += step >> 2;
    if (nibble & 8) diff = -diff;

    predictor += diff;
    predictor = av_clip_int16(predictor);

    c->predictor = predictor;
    c->step_index = step_index;

    return predictor;
}

static void decode_adpcm_ima_hvqm2(AVCodecContext *avctx, int16_t *outbuf, int samples_to_do,
                                   int frame_format, GetByteContext *gb)
{
    ADPCMDecodeContext *c = avctx->priv_data;
    int st = avctx->ch_layout.nb_channels == 2;
    uint8_t nibble;

    for (int ch = 0; ch < avctx->ch_layout.nb_channels; ch++) {
        unsigned tmp;

        switch (frame_format) {
        case 0: /* combined hist+index */
            tmp = bytestream2_get_be16(gb);
            c->status[ch].predictor  = sign_extend(tmp & 0xFF80, 16);
            c->status[ch].step_index = tmp & 0x7f;
            *outbuf++ = c->status[ch].predictor;
            samples_to_do--;
            break;
        default:
            break;
        }

        c->status[ch].step_index = av_clip(c->status[ch].step_index, 0, 88);
    }

    for (int i = 0; i < samples_to_do; i++) {
        if (!(i&1)) {
            nibble = bytestream2_get_byte(gb);
            *outbuf++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], nibble >> 4);
        } else {
            *outbuf++ = ff_adpcm_ima_qt_expand_nibble(&c->status[ 0], nibble & 15);
        }
    }

    bytestream2_seek(gb, 0, SEEK_END);
}

static void decode_adpcm_ima_hvqm4(AVCodecContext *avctx, int16_t *outbuf, int samples_to_do,
                                   int frame_format, GetByteContext *gb)
{
    ADPCMDecodeContext *c = avctx->priv_data;
    int st = avctx->ch_layout.nb_channels == 2;
    unsigned tmp;

    for (int ch = 0; ch < avctx->ch_layout.nb_channels; ch++) {
        switch (frame_format) {
        case 1: /* combined hist+index */
            tmp = bytestream2_get_be16(gb);
            c->status[ch].predictor  = sign_extend(tmp & 0xFF80, 16);
            c->status[ch].step_index = tmp & 0x7f;
            break;
        case 2:  /* no hist/index (continues from previous frame) */
        default:
            break;
        case 3: /* separate hist+index */
            tmp = bytestream2_get_be16(gb);
            c->status[ch].predictor  = sign_extend(tmp, 16);
            c->status[ch].step_index = bytestream2_get_byte(gb);
            break;
        }

        c->status[ch].step_index = av_clip(c->status[ch].step_index, 0, 88);
    }

    if (frame_format == 1 || frame_format == 3) {
        for (int ch = 0; ch < avctx->ch_layout.nb_channels; ch++)
            *outbuf++ = (int16_t)c->status[st - ch].predictor;
        samples_to_do--;
    }

    for (int i = 0; i < samples_to_do; i += 1+(!st)) {
        uint8_t nibble = bytestream2_get_byte(gb);

        *outbuf++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], nibble & 15);
        *outbuf++ = ff_adpcm_ima_qt_expand_nibble(&c->status[ 0], nibble >> 4);
    }

    bytestream2_seek(gb, 0, SEEK_END);
}

static inline int16_t adpcm_ms_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int predictor;

    predictor = (((c->sample1) * (c->coeff1)) + ((c->sample2) * (c->coeff2))) >> 6;
    predictor += ((nibble & 0x08)?(nibble - 0x10):(nibble)) * c->idelta;

    c->sample2 = c->sample1;
    c->sample1 = av_clip_int16(predictor);
    c->idelta = (ff_adpcm_AdaptationTable[(int)nibble] * c->idelta) >> 8;
    if (c->idelta < 16) c->idelta = 16;
    if (c->idelta > INT_MAX/768) {
        av_log(NULL, AV_LOG_WARNING, "idelta overflow\n");
        c->idelta = INT_MAX/768;
    }

    return c->sample1;
}

static inline int16_t adpcm_ima_oki_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int step_index, predictor, sign, delta, diff, step;

    step = oki_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 48);

    sign = nibble & 8;
    delta = nibble & 7;
    diff = ((2 * delta + 1) * step) >> 3;
    predictor = c->predictor;
    if (sign) predictor -= diff;
    else predictor += diff;

    c->predictor = av_clip_intp2(predictor, 11);
    c->step_index = step_index;

    return c->predictor * 16;
}

static inline int16_t adpcm_ima_oki4_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int step_index, predictor, delta, step;

    step = oki_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 48);
    step <<= 4;

    delta = step >> 3;
    if (nibble & 1) delta += step >> 2;
    if (nibble & 2) delta += step >> 1;
    if (nibble & 4) delta += step;
    if (nibble & 8) delta = -delta;
    predictor = c->predictor;
    predictor += delta;

    c->predictor = av_clip_int16(predictor);
    c->step_index = step_index;

    return c->predictor;
}

static inline int16_t adpcm_ima_wv6_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int sample_decoded, step, delta;

    sample_decoded = c->predictor;
    step = ff_adpcm_step_table[c->step_index];

    delta = (nibble & 0x7);
    delta = ((delta * step) >> 3) + ((delta * step) >> 2);
    if (nibble & 8)
        delta = -delta;
    sample_decoded += delta;

    c->predictor = av_clip_int16(sample_decoded);
    c->step_index += ff_adpcm_index_table[nibble];
    c->step_index = av_clip(c->step_index, 0, 88);

    return c->predictor;
}

static inline int16_t adpcm_ima_zmusic_expand_nibble(ADPCMChannelStatus *c, int nibble)
{
    int step_index, predictor, diff, step;

    step = oki_step_table[c->step_index];
    step_index = c->step_index + ff_adpcm_index_table[(unsigned)nibble];
    step_index = av_clip(step_index, 0, 48);

    diff = step >> 3;
    if (nibble & 4) diff += step;
    if (nibble & 2) diff += step >> 1;
    if (nibble & 1) diff += step >> 2;
    if (nibble & 8) diff = -diff;

    predictor = c->predictor;
    predictor += diff;

    c->predictor = av_clip_intp2(predictor, 11);
    c->step_index = step_index;

    return c->predictor * 16;
}

static inline int16_t adpcm_ct_expand_nibble(ADPCMChannelStatus *c, int8_t nibble)
{
    int sign, delta, diff;
    int new_step;

    sign = nibble & 8;
    delta = nibble & 7;
    /* perform direct multiplication instead of series of jumps proposed by
     * the reference ADPCM implementation since modern CPUs can do the mults
     * quickly enough */
    diff = ((2 * delta + 1) * c->step) >> 3;
    /* predictor update is not so trivial: predictor is multiplied on 254/256 before updating */
    c->predictor = ((c->predictor * 254) >> 8) + (sign ? -diff : diff);
    c->predictor = av_clip_int16(c->predictor);
    /* calculate new step and clamp it to range 511..32767 */
    new_step = (ff_adpcm_AdaptationTable[nibble & 7] * c->step) >> 8;
    c->step = av_clip(new_step, 511, 32767);

    return (int16_t)c->predictor;
}

static inline int16_t adpcm_rhetorex_expand_nibble(ADPCMChannelStatus *c, const uint8_t nibble)
{
    int delta, add, a, b;
    int16_t sample;

    delta = nibble & 7;
    add = rhetorex_step[((c->step_index >> 8) & 0x78) + delta];
    if (nibble & 0x8)
        add = -add;

    sample = av_clip_int16(c->predictor + add);

    a = (c->coeff1 << 15) + (add >> 1) * c->sample2;
    c->coeff1 = av_clip_int16((a - ((a >> 7) & ~0xFF)) >> 15);

    b = (c->coeff2 << 15) + (add >> 1) * c->sample1;
    c->coeff2 = av_clip_int16((b - ((b >> 7) & ~0xFF) + 0x800000) >> 15);

    c->predictor = av_clip_int16((c->coeff1 * c->sample1 + c->coeff2 * sample) >> 15);

    c->sample2 = c->sample1;
    c->sample1 = sample;

    c->step_index = FFABS(64512 * c->step_index + (rhetorex_index[delta] << 16)) >> 16;

    return sample;
}

static inline int16_t adpcm_sbpro_expand_nibble(ADPCMChannelStatus *c, int8_t nibble, int size, int shift)
{
    int sign, delta, diff;

    sign = nibble & (1<<(size-1));
    delta = nibble & ((1<<(size-1))-1);
    diff = delta << (7 + c->step + shift);

    /* clamp result */
    c->predictor = av_clip(c->predictor + (sign ? -diff : diff), -16384,16256);

    /* calculate new step */
    if (delta >= (2*size - 3) && c->step < 3)
        c->step++;
    else if (delta == 0 && c->step > 0)
        c->step--;

    return (int16_t) c->predictor;
}

static inline int16_t adpcmb_yamaha_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    int delta, sample;

    delta = ((((nibble & 0x7) * 2) + 1) * c->step) >> 3;
    if (nibble & 8)
        delta = -delta;
    sample = c->predictor + delta;

    sample = av_clip_int16(sample);

    c->step = (c->step * adpcmb_yamaha_indexscale[nibble]) >> 6;
    c->step = av_clip(c->step, 127, 24576);

    c->predictor = sample;

    return sample;
}

static inline int16_t adpcm_yamaha_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    if(!c->step) {
        c->predictor = 0;
        c->step = 127;
    }

    c->predictor += (c->step * ff_adpcm_yamaha_difflookup[nibble]) / 8;
    c->predictor = av_clip_int16(c->predictor);
    c->step = (c->step * ff_adpcm_yamaha_indexscale[nibble]) >> 8;
    c->step = av_clip(c->step, 127, 24576);
    return c->predictor;
}

static inline int16_t adpcm_mtaf_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    c->predictor += mtaf_stepsize[c->step][nibble];
    c->predictor = av_clip_int16(c->predictor);
    c->step += ff_adpcm_index_table[nibble];
    c->step = av_clip_uintp2(c->step, 5);
    return c->predictor;
}

static inline int16_t adpcm_circus_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    int32_t sample = c->predictor;
    int32_t scale = c->step;
    int32_t code = sign_extend(nibble, 8);

    sample += code * (1 << scale);
    if (code == 0) {
        scale--;
    } else if (code == 127 || code == -128) {
        scale++;
    }
    scale = av_clip(scale, 0, 8);
    sample = av_clip_int16(sample);

    c->predictor = sample;
    c->step = scale;

    return sample;
}

static inline int16_t adpcm_tantalus_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    static const int8_t tantalus_nibbles[16] = {0,1,2,3,4,5,6,7,-8,-7,-6,-5,-4,-3,-2,-1};
    int32_t sample = tantalus_nibbles[nibble];
    int32_t shift = c->step;

    sample = sample * (1 << shift);
    sample = sample + c->predictor;

    sample = av_clip_int16(sample);

    c->predictor = sample;

    return sample;
}

static inline int16_t adpcm_zork_expand_nibble(ADPCMChannelStatus *c, uint8_t nibble)
{
    int16_t index = c->step_index;
    uint32_t lookup_sample = ff_adpcm_step_table[index];
    int32_t sample = 0;

    if (nibble & 0x40)
        sample += lookup_sample;
    if (nibble & 0x20)
        sample += lookup_sample >> 1;
    if (nibble & 0x10)
        sample += lookup_sample >> 2;
    if (nibble & 0x08)
        sample += lookup_sample >> 3;
    if (nibble & 0x04)
        sample += lookup_sample >> 4;
    if (nibble & 0x02)
        sample += lookup_sample >> 5;
    if (nibble & 0x01)
        sample += lookup_sample >> 6;
    if (nibble & 0x80)
        sample = -sample;

    sample += c->predictor;
    sample = av_clip_int16(sample);

    index += zork_index_table[(nibble >> 4) & 7];
    index = av_clip(index, 0, 88);

    c->predictor = sample;
    c->step_index = index;

    return sample;
}

static int xa_decode(AVCodecContext *avctx, int16_t *out0, int16_t *out1,
                     const uint8_t *in, ADPCMChannelStatus *left,
                     ADPCMChannelStatus *right, int channels, int sample_offset)
{
    int shift, filter, f0, f1;
    int s_1, s_2;
    int d, s, t;

    out0 += sample_offset;
    if (channels == 1)
        out1 = out0 + 28;
    else
        out1 += sample_offset;

    for (int i = 0; i < 4; i++) {
        shift  = 12 - (in[4+i*2] & 15);
        filter = in[4+i*2] >> 4;
        if (filter >= FF_ARRAY_ELEMS(xa_adpcm_table)) {
            avpriv_request_sample(avctx, "unknown XA-ADPCM filter %d", filter);
            filter=0;
        }
        if (shift < 0) {
            avpriv_request_sample(avctx, "unknown XA-ADPCM shift %d", shift);
            shift = 0;
        }
        f0 = xa_adpcm_table[filter][0];
        f1 = xa_adpcm_table[filter][1];

        s_1 = left->sample1;
        s_2 = left->sample2;

        for (int j = 0; j < 28; j++) {
            d = in[16+i+j*4];

            t = sign_extend(d, 4);
            s = t*(1<<shift) + ((s_1*f0 + s_2*f1+32)>>6);
            s_2 = s_1;
            s_1 = av_clip_int16(s);
            out0[j] = s_1;
        }

        if (channels == 2) {
            left->sample1 = s_1;
            left->sample2 = s_2;
            s_1 = right->sample1;
            s_2 = right->sample2;
        }

        shift  = 12 - (in[5+i*2] & 15);
        filter = in[5+i*2] >> 4;
        if (filter >= FF_ARRAY_ELEMS(xa_adpcm_table) || shift < 0) {
            avpriv_request_sample(avctx, "unknown XA-ADPCM filter %d", filter);
            filter=0;
        }
        if (shift < 0) {
            avpriv_request_sample(avctx, "unknown XA-ADPCM shift %d", shift);
            shift = 0;
        }

        f0 = xa_adpcm_table[filter][0];
        f1 = xa_adpcm_table[filter][1];

        for (int j = 0; j < 28; j++) {
            d = in[16+i+j*4];

            t = sign_extend(d >> 4, 4);
            s = t*(1<<shift) + ((s_1*f0 + s_2*f1+32)>>6);
            s_2 = s_1;
            s_1 = av_clip_int16(s);
            out1[j] = s_1;
        }

        if (channels == 2) {
            right->sample1 = s_1;
            right->sample2 = s_2;
        } else {
            left->sample1 = s_1;
            left->sample2 = s_2;
        }

        out0 += 28 * (3 - channels);
        out1 += 28 * (3 - channels);
    }

    return 0;
}

static int xa8_decode(AVCodecContext *avctx, int16_t *out0, int16_t *out1,
                      const uint8_t *in, ADPCMChannelStatus *left,
                      ADPCMChannelStatus *right, int channels, int sample_offset)
{
    int shift, filter, f0, f1;
    int s_1, s_2;
    int d, s;

    out0 += sample_offset;
    out1 += sample_offset;

    if (channels == 2) {
        for (int i = 0; i < 2; i++) {
            shift  = in[i*2] & 15;
            filter = in[i*2] >> 4;
            shift = FFMIN(shift, 8);
            filter = FFMIN(filter, 5);
            f0 = xa_adpcm_table[filter][0];
            f1 = xa_adpcm_table[filter][1];

            s_1 = left->sample1;
            s_2 = left->sample2;
            for (int j = 0; j < 28; j++) {
                d = in[16+i*2+j*4];

                s = sign_extend((d << 8) & 0xff00, 16) >> shift;
                s = s + ((f0 * s_1 + f1 * s_2 + 32) >> 6);
                s = av_clip_int16(s);
                s_2 = s_1;
                s_1 = s;
                out0[j] = s_1;
            }
            out0 += 28;
            left->sample1 = s_1;
            left->sample2 = s_2;

            shift  = in[i*2+1] & 15;
            filter = in[i*2+1] >> 4;
            shift = FFMIN(shift, 8);
            filter = FFMIN(filter, 5);
            f0 = xa_adpcm_table[filter][0];
            f1 = xa_adpcm_table[filter][1];

            s_1 = right->sample1;
            s_2 = right->sample2;
            for (int j = 0; j < 28; j++) {
                d = in[16+i*2+j*4+1];

                s = sign_extend((d << 8) & 0xff00, 16) >> shift;
                s = s + ((f0 * s_1 + f1 * s_2 + 32) >> 6);
                s = av_clip_int16(s);
                s_2 = s_1;
                s_1 = s;
                out1[j] = s_1;
            }
            out1 += 28;
            right->sample1 = s_1;
            right->sample2 = s_2;
        }
    }

    return 0;
}

static void adpcm_swf_decode(AVCodecContext *avctx, const uint8_t *buf, int buf_size, int16_t *samples)
{
    ADPCMDecodeContext *c = avctx->priv_data;
    GetBitContext gb;
    const int8_t *table;
    int channels = avctx->ch_layout.nb_channels;
    int k0, signmask, nb_bits, count;
    int size = buf_size*8;
    int i;

    init_get_bits(&gb, buf, size);

    //read bits & initial values
    nb_bits = get_bits(&gb, 2)+2;
    table = swf_index_tables[nb_bits-2];
    k0 = 1 << (nb_bits-2);
    signmask = 1 << (nb_bits-1);

    while (get_bits_count(&gb) <= size - 22 * channels) {
        for (i = 0; i < channels; i++) {
            *samples++ = c->status[i].predictor = get_sbits(&gb, 16);
            c->status[i].step_index = get_bits(&gb, 6);
        }

        for (count = 0; get_bits_count(&gb) <= size - nb_bits * channels && count < 4095; count++) {
            int i;

            for (i = 0; i < channels; i++) {
                // similar to IMA adpcm
                int delta = get_bits(&gb, nb_bits);
                int step = ff_adpcm_step_table[c->status[i].step_index];
                int vpdiff = 0; // vpdiff = (delta+0.5)*step/4
                int k = k0;

                do {
                    if (delta & k)
                        vpdiff += step;
                    step >>= 1;
                    k >>= 1;
                } while(k);
                vpdiff += step;

                if (delta & signmask)
                    c->status[i].predictor -= vpdiff;
                else
                    c->status[i].predictor += vpdiff;

                c->status[i].step_index += table[delta & (~signmask)];

                c->status[i].step_index = av_clip(c->status[i].step_index, 0, 88);
                c->status[i].predictor = av_clip_int16(c->status[i].predictor);

                *samples++ = c->status[i].predictor;
            }
        }
    }
}

int16_t ff_adpcm_argo_expand_nibble(ADPCMChannelStatus *cs, int nibble, int shift, int flag)
{
    int sample = sign_extend(nibble, 4) * (1 << shift);

    if (flag)
        sample += (8 * cs->sample1) - (4 * cs->sample2);
    else
        sample += 4 * cs->sample1;

    sample = av_clip_int16(sample >> 2);

    cs->sample2 = cs->sample1;
    cs->sample1 = sample;

    return sample;
}

static int adpcm_sanyo_expand3(ADPCMChannelStatus *c, int bits)
{
    int sign, delta, add;

    sign = bits & 4;
    if (sign)
        delta = 4 - (bits & 3);
    else
        delta = bits;

    switch (delta) {
    case 0:
        add = 0;
        c->step = (3 * c->step) >> 2;
        break;
    case 1:
        add = c->step;
        c->step = (4 * c->step - (c->step >> 1)) >> 2;
        break;
    case 2:
        add = 2 * c->step;
        c->step = ((c->step >> 1) + add) >> 1;
        break;
    case 3:
        add = 4 * c->step - (c->step >> 1);
        c->step = 2 * c->step;
        break;
    case 4:
        add = (11 * c->step) >> 1;
        c->step = 3 * c->step;
        break;
    default:
        av_unreachable("There are cases for all control paths when bits is 3-bit");
    }

    if (sign)
        add = -add;

    c->predictor = av_clip_int16(c->predictor + add);
    c->step = av_clip(c->step, 1, 7281);
    return c->predictor;
}

static int adpcm_sanyo_expand4(ADPCMChannelStatus *c, int bits)
{
    int sign, delta, add;

    sign = bits & 8;
    if (sign)
        delta = 8 - (bits & 7);
    else
        delta = bits;

    switch (delta) {
    case 0:
        add = 0;
        c->step = (3 * c->step) >> 2;
        break;
    case 1:
        add = c->step;
        c->step = (3 * c->step) >> 2;
        break;
    case 2:
        add = 2 * c->step;
        break;
    case 3:
        add = 3 * c->step;
        break;
    case 4:
        add = 4 * c->step;
        break;
    case 5:
        add = (11 * c->step) >> 1;
        c->step += c->step >> 2;
        break;
    case 6:
        add = (15 * c->step) >> 1;
        c->step = 2 * c->step;
        break;
    case 7:
        if (sign)
            add = (19 * c->step) >> 1;
        else
            add = (21 * c->step) >> 1;
        c->step = (c->step >> 1) + 2 * c->step;
        break;
    case 8:
        add = (25 * c->step) >> 1;
        c->step = 5 * c->step;
        break;
    default:
        av_unreachable("There are cases for all control paths when bits is 4-bit");
    }

    if (sign)
        add = -add;

    c->predictor = av_clip_int16(c->predictor + add);
    c->step = av_clip(c->step, 1, 2621);
    return c->predictor;
}

static int adpcm_sanyo_expand5(ADPCMChannelStatus *c, int bits)
{
    int sign, delta, add;

    sign = bits & 0x10;
    if (sign)
        delta = 16 - (bits & 0xF);
    else
        delta = bits;

    add = delta * c->step;
    switch (delta) {
    case 0:
        c->step += (c->step >> 2) - (c->step >> 1);
        break;
    case 1:
    case 2:
    case 3:
        c->step += (c->step >> 3) - (c->step >> 2);
        break;
    case 4:
    case 5:
        c->step += (c->step >> 4) - (c->step >> 3);
        break;
    case 6:
        break;
    case 7:
        c->step += c->step >> 3;
        break;
    case 8:
        c->step += c->step >> 2;
        break;
    case 9:
        c->step += c->step >> 1;
        break;
    case 10:
        c->step = 2 * c->step - (c->step >> 3);
        break;
    case 11:
        c->step = 2 * c->step + (c->step >> 3);
        break;
    case 12:
        c->step = 2 * c->step + (c->step >> 1) - (c->step >> 3);
        break;
    case 13:
        c->step = 3 * c->step - (c->step >> 2);
        break;
    case 14:
        c->step *= 3;
        break;
    case 15:
    case 16:
        c->step = (7 * c->step) >> 1;
        break;
    }

    if (sign)
        add = -add;

    c->predictor = av_clip_int16(c->predictor + add);
    c->step = av_clip(c->step, 1, 1024);
    return c->predictor;
}

static int adpcm_citrix_expand(ADPCMChannelStatus *c, int bits)
{
    int step = ff_adpcm_step_table[c->step_index];
    int add = step >> 1;

    if ((bits & 1))
        add += step;
    if ((bits & 2))
        add = -add;

    c->step_index = av_clip(c->step_index + citrix_index_table[bits], 0, 88);
    c->predictor = av_clip_int16(c->predictor + add);

    return c->predictor;
}

/**
 * Get the number of samples (per channel) that will be decoded from the packet.
 * In one case, this is actually the maximum number of samples possible to
 * decode with the given buf_size.
 *
 * @param[out] coded_samples set to the number of samples as coded in the
 *                           packet, or 0 if the codec does not encode the
 *                           number of samples in each frame.
 * @param[out] approx_nb_samples set to non-zero if the number of samples
 *                               returned is an approximation.
 */
static int get_nb_samples(AVCodecContext *avctx, GetByteContext *gb,
                          int buf_size, int *coded_samples, int *approx_nb_samples,
                          int64_t pts)
{
    ADPCMDecodeContext *s = avctx->priv_data;
    int block_align       = avctx->block_align;
    int nb_samples        = 0;
    int ch                = avctx->ch_layout.nb_channels;
    int has_coded_samples = 0;
    int header_size;

    *coded_samples = 0;
    *approx_nb_samples = 0;

    if (ch <= 0)
        return 0;
    if (buf_size > INT_MAX / 14)
        return 0;

    switch (avctx->codec->id) {
    /* constant, only check buf_size */
    case AV_CODEC_ID_ADPCM_EA_XAS:
        if (buf_size < 76 * ch)
            return 0;
        nb_samples = 128;
        break;
    case AV_CODEC_ID_ADPCM_IMA_QT:
        if (buf_size < 34 * ch)
            return 0;
        nb_samples = 64;
        break;
    case AV_CODEC_ID_ADPCM_N64:
        nb_samples = (buf_size / 9) * 16;
        break;
    /* simple 4-bit adpcm */
    case AV_CODEC_ID_ADPCM_CT:
    case AV_CODEC_ID_ADPCM_IMA_APC:
    case AV_CODEC_ID_ADPCM_IMA_CUNNING:
    case AV_CODEC_ID_ADPCM_IMA:
    case AV_CODEC_ID_ADPCM_IMA_DVI:
    case AV_CODEC_ID_ADPCM_IMA_HWAS:
    case AV_CODEC_ID_ADPCM_IMA_EA_SEAD:
    case AV_CODEC_ID_ADPCM_IMA_ESCAPE:
    case AV_CODEC_ID_ADPCM_IMA_OKI:
    case AV_CODEC_ID_ADPCM_IMA_OKI4:
    case AV_CODEC_ID_ADPCM_IMA_WS:
    case AV_CODEC_ID_ADPCM_YAMAHA:
    case AV_CODEC_ID_ADPCM_AICA:
    case AV_CODEC_ID_ADPCM_IMA_SSI:
    case AV_CODEC_ID_ADPCM_IMA_APM:
    case AV_CODEC_ID_ADPCM_IMA_ALP:
    case AV_CODEC_ID_ADPCM_IMA_MTF:
    case AV_CODEC_ID_ADPCM_IMA_WV6:
    case AV_CODEC_ID_ADPCM_IMA_ZMUSIC:
    case AV_CODEC_ID_ADPCM_RHETOREX:
        nb_samples = buf_size * 2 / ch;
        break;
    }
    if (nb_samples)
        return nb_samples;

    /* simple 4-bit adpcm, with header */
    header_size = 0;
    switch (avctx->codec->id) {
        case AV_CODEC_ID_ADPCM_4XM:
        case AV_CODEC_ID_ADPCM_AGM:
        case AV_CODEC_ID_ADPCM_IMA_ACORN:
        case AV_CODEC_ID_ADPCM_IMA_MAGIX:
        case AV_CODEC_ID_ADPCM_IMA_MOFLEX:
        case AV_CODEC_ID_ADPCM_IMA_ISS:     header_size = 4 * ch;      break;
        case AV_CODEC_ID_ADPCM_IMA_SMJPEG:  header_size = 4 * ch;      break;
    }
    if (header_size > 0)
        return (buf_size - header_size) * 2 / ch;

    /* more complex formats */
    switch (avctx->codec->id) {
    case AV_CODEC_ID_ADPCM_IMA_AMV:
        bytestream2_skip(gb, 4);
        has_coded_samples  = 1;
        *coded_samples     = bytestream2_get_le32u(gb);
        nb_samples         = FFMIN((buf_size - 8) * 2, *coded_samples);
        bytestream2_seek(gb, -8, SEEK_CUR);
        break;
    case AV_CODEC_ID_ADPCM_EA:
        /* Stereo is 30 bytes per block */
        /* Mono is 15 bytes per block */
        has_coded_samples = 1;
        *coded_samples  = bytestream2_get_le32(gb);
        *coded_samples -= *coded_samples % 28;
        nb_samples      = (buf_size - 12) / (ch == 2 ? 30 : 15) * 28;
        break;
    case AV_CODEC_ID_ADPCM_IMA_HVQM2:
        nb_samples = ((bytestream2_peek_be64(gb) >> 16) & 0xFFFF);
        break;
    case AV_CODEC_ID_ADPCM_IMA_HVQM4:
        {
            int frame_format = bytestream2_get_be16(gb);
            int skip = 6;

            if (frame_format == 1)
                skip += 2 * ch;
            if (frame_format == 3)
                skip += 3 * ch;

            nb_samples = (buf_size - skip) * 2 / ch;
            bytestream2_seek(gb, 0, SEEK_SET);
        }
        break;
    case AV_CODEC_ID_ADPCM_IMA_EA_EACS:
        has_coded_samples = 1;
        *coded_samples = bytestream2_get_le32(gb);
        nb_samples     = (buf_size - (4 + 8 * ch)) * 2 / ch;
        break;
    case AV_CODEC_ID_ADPCM_EA_MAXIS_XA:
        nb_samples = (buf_size/block_align)*(block_align - ch) / ch * 2;
        break;
    case AV_CODEC_ID_ADPCM_IMA_MO:
        nb_samples = (buf_size / (132 * ch)) * 256;
        break;
    case AV_CODEC_ID_ADPCM_EA_R1:
    case AV_CODEC_ID_ADPCM_EA_R2:
    case AV_CODEC_ID_ADPCM_EA_R3:
        /* maximum number of samples */
        /* has internal offsets and a per-frame switch to signal raw 16-bit */
        has_coded_samples = 1;
        switch (avctx->codec->id) {
        case AV_CODEC_ID_ADPCM_EA_R1:
            header_size    = 4 + 9 * ch;
            *coded_samples = bytestream2_get_le32(gb);
            break;
        case AV_CODEC_ID_ADPCM_EA_R2:
            header_size    = 4 + 5 * ch;
            *coded_samples = bytestream2_get_le32(gb);
            break;
        case AV_CODEC_ID_ADPCM_EA_R3:
            header_size    = 4 + 5 * ch;
            *coded_samples = bytestream2_get_be32(gb);
            break;
        }
        *coded_samples -= *coded_samples % 28;
        nb_samples      = (buf_size - header_size) * 2 / ch;
        nb_samples     -= nb_samples % 28;
        *approx_nb_samples = 1;
        break;
    case AV_CODEC_ID_ADPCM_IMA_DK3:
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        nb_samples = ((buf_size - 16) * 2 / 3 * 4) / ch;
        break;
    case AV_CODEC_ID_ADPCM_IMA_DK4:
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        if (buf_size < 4 * ch)
            return AVERROR_INVALIDDATA;
        nb_samples = 1 + (buf_size - 4 * ch) * 2 / ch;
        break;
    case AV_CODEC_ID_ADPCM_IMA_RAD:
    case AV_CODEC_ID_ADPCM_IMA_RAD_MONO:
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        nb_samples = (buf_size - 4 * ch) * 2 / ch;
        break;
    case AV_CODEC_ID_ADPCM_IMA_PDA:
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        nb_samples = (buf_size - 4 * ch) * 2 / ch;
        break;
    CASE(ADPCM_IMA_WAV_MONO,
        int bsize = ff_adpcm_ima_block_sizes[avctx->bits_per_coded_sample - 2];
        int bsamples = ff_adpcm_ima_block_samples[avctx->bits_per_coded_sample - 2];
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        if (buf_size < 4 * ch)
            return AVERROR_INVALIDDATA;
        nb_samples = 1 + (buf_size - 4 * ch) / (bsize * ch) * bsamples;
        ) /* End of CASE */
    CASE(ADPCM_IMA_WAV,
        int bsize = ff_adpcm_ima_block_sizes[avctx->bits_per_coded_sample - 2];
        int bsamples = ff_adpcm_ima_block_samples[avctx->bits_per_coded_sample - 2];
        if (block_align > 0)
            buf_size = FFMIN(buf_size, block_align);
        if (buf_size < 4 * ch)
            return AVERROR_INVALIDDATA;
        nb_samples = 1 + (buf_size - 4 * ch) / (bsize * ch) * bsamples;
        ) /* End of CASE */
    case AV_CODEC_ID_ADPCM_IMA_FSB:
    case AV_CODEC_ID_ADPCM_IMA_XBOX:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_MONO:
    case AV_CODEC_ID_ADPCM_IMA_XBOX_SBR:
    case AV_CODEC_ID_ADPCM_IMA_WW:
        {
            int left = buf_size;

            if (block_align <= 0)
                block_align = left;

            nb_samples = 0;
            while (left > 0) {
                const int block_size = FFMIN(left, block_align);

                if (block_size <= 0)
                    break;

                nb_samples += (block_size / (0x24 * ch)) * 64 + 1;
                left -= block_size;
            }
        }
        if (avctx->codec->id == AV_CODEC_ID_ADPCM_IMA_FSB && nb_samples == 1)
            nb_samples = 0;
        break;
    case AV_CODEC_ID_ADPCM_CKMK:
    case AV_CODEC_ID_ADPCM_MS:
    case AV_CODEC_ID_ADPCM_MS_MONO:
        {
            int left = buf_size;

            if (block_align <= 0)
                block_align = left;

            nb_samples = 0;
            while (left > 0) {
                const int block_size = FFMIN(left, block_align);

                if (block_size <= 0)
                    break;

                const int block_samples = (block_size - 6 * ch) * 2 / ch;
                if (block_samples <= 0)
                    break;

                nb_samples += block_samples;
                left -= block_size;
            }
        }
        break;
    case AV_CODEC_ID_ADPCM_MTA2:
        nb_samples = buf_size / (16 + ch * 0x90) * 256;
        break;
    case AV_CODEC_ID_ADPCM_MTAF:
        {
            int left = buf_size;

            if (block_align <= 0)
                block_align = left;

            nb_samples = 0;
            while (left > 0) {
                const int block_size = FFMIN(left, block_align);

                if (block_size <= 0)
                    break;

                const int block_samples = (block_size - 16 * (ch / 2)) * 2 / ch;
                if (block_samples <= 0)
                    break;

                nb_samples += block_samples;
                left -= block_size;
            }
        }
        break;
    case AV_CODEC_ID_ADPCM_SBPRO_2:
    case AV_CODEC_ID_ADPCM_SBPRO_3:
    case AV_CODEC_ID_ADPCM_SBPRO_4:
    {
        int samples_per_byte;
        switch (avctx->codec->id) {
        case AV_CODEC_ID_ADPCM_SBPRO_2: samples_per_byte = 4; break;
        case AV_CODEC_ID_ADPCM_SBPRO_3: samples_per_byte = 3; break;
        case AV_CODEC_ID_ADPCM_SBPRO_4: samples_per_byte = 2; break;
        }
        if (!s->status[0].step_index) {
            if (buf_size < ch)
                return AVERROR_INVALIDDATA;
            nb_samples++;
            buf_size -= ch;
        }
        nb_samples += buf_size * samples_per_byte / ch;
        break;
    }
    case AV_CODEC_ID_ADPCM_SWF:
    {
        int buf_bits       = buf_size * 8 - 2;
        int nbits          = (bytestream2_get_byte(gb) >> 6) + 2;
        int block_hdr_size = 22 * ch;
        int block_size     = block_hdr_size + nbits * ch * 4095;
        int nblocks        = buf_bits / block_size;
        int bits_left      = buf_bits - nblocks * block_size;
        nb_samples         = nblocks * 4096;
        if (bits_left >= block_hdr_size)
            nb_samples += 1 + (bits_left - block_hdr_size) / (nbits * ch);
        break;
    }
    case AV_CODEC_ID_ADPCM_TANTALUS:
        nb_samples = (buf_size/ch/16) * 30;
        break;
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_LE:
    case AV_CODEC_ID_ADPCM_NDSP_SI:
    case AV_CODEC_ID_ADPCM_NDSP_SI1:
        {
            int left = buf_size;

            if (block_align <= 0)
                block_align = left;

            nb_samples = 0;
            while (left > 0) {
                const int block_size = FFMIN(left, block_align);

                if (block_size <= 0)
                    break;

                if (s->start_skip > 0 && pts == 0 && left == buf_size) {
                    nb_samples += ((block_size - s->start_skip * ch) / ch) / 8 * 14;
                } else {
                    nb_samples += (block_size / ch) / 8 * 14;
                }

                left -= block_size;
            }
        }
        break;
    case AV_CODEC_ID_ADPCM_THP:
    case AV_CODEC_ID_ADPCM_THP_LE:
        s->block_size = (avctx->codec->id == AV_CODEC_ID_ADPCM_THP_LE) ?
                        bytestream2_get_le32(gb) :
                        bytestream2_get_be32(gb);
        nb_samples = (avctx->codec->id == AV_CODEC_ID_ADPCM_THP_LE) ?
                     bytestream2_get_le32(gb) :
                     bytestream2_get_be32(gb);
        break;
    case AV_CODEC_ID_ADPCM_AFC:
    case AV_CODEC_ID_ADPCM_BRR:
        nb_samples = buf_size / (9 * ch) * 16;
        break;
    case AV_CODEC_ID_ADPCM_IMA_REF:
        nb_samples = (buf_size / block_align) * ((block_align - 4*ch) * 2 / ch + 1);
        break;
    case AV_CODEC_ID_ADPCM_IMA_TRA:
    case AV_CODEC_ID_ADPCM_IMA_DAT4:
        nb_samples = (buf_size / block_align) * ((block_align/ch - 4) * 2);
        break;
    case AV_CODEC_ID_ADPCM_IMA_RAUD:
        nb_samples = ((buf_size / (0x804 * ch))) * ((0x800) * 2);
        break;
    case AV_CODEC_ID_ADPCM_IMA_AWC:
        nb_samples = ((buf_size / (0x800 * ch))) * ((0x800 - 4) * 2);
        break;
    case AV_CODEC_ID_ADPCM_IMA_NDS:
        {
            int left = buf_size;

            if (block_align <= 0)
                block_align = left;

            nb_samples = 0;
            while (left > 0) {
                const int block_size = FFMIN(left, block_align);

                if (block_size <= 0)
                    break;

                int block_samples = (block_size - 4 * ch) * 2 / ch;
                if (block_samples <= 0)
                    break;

                nb_samples += block_samples;

                left -= block_size;
            }
        }
        break;
    case AV_CODEC_ID_ADPCM_NXAP:
        nb_samples = ((buf_size / (0x40 * ch))) * ((0x40 - 4) * 2);
        break;
    case AV_CODEC_ID_ADPCM_XA:
        nb_samples = (buf_size / 128) * 224 / ch;
        break;
    case AV_CODEC_ID_ADPCM_XA8:
        nb_samples = (buf_size / 128) * 112 / ch;
        break;
    case AV_CODEC_ID_ADPCM_XMD:
        nb_samples = buf_size / (21 * ch) * 32;
        break;
    case AV_CODEC_ID_ADPCM_DTK:
    case AV_CODEC_ID_ADPCM_PSX:
    case AV_CODEC_ID_ADPCM_HEVAG:
        nb_samples = buf_size / (16 * ch) * 28;
        break;
    case AV_CODEC_ID_ADPCM_DSA:
        nb_samples = buf_size / (8 * ch) * 14;
        break;
    case AV_CODEC_ID_ADPCM_PROCYON:
        nb_samples = buf_size / (16 * ch) * 30;
        break;
    case AV_CODEC_ID_ADPCM_PSXC:
        nb_samples = (buf_size / block_align) * ((block_align - 1) / ch) * 2;
        break;
    case AV_CODEC_ID_ADPCM_ARGO:
        nb_samples = buf_size / block_align * 32;
        break;
    case AV_CODEC_ID_ADPCM_CIRCUS:
    case AV_CODEC_ID_ADPCM_ZORK:
        nb_samples = buf_size / ch;
        break;
    case AV_CODEC_ID_ADPCM_SANYO:
        if (!avctx->extradata || avctx->extradata_size != 2)
            return AVERROR_INVALIDDATA;
        nb_samples = AV_RL16(avctx->extradata);
        break;
    case AV_CODEC_ID_ADPCM_FMOD:
        if (block_align / ch <= 0xc)
            return AVERROR_INVALIDDATA;
        nb_samples = (buf_size / block_align) * (block_align / ch - 0xc) * 2;
        break;
    case AV_CODEC_ID_ADPCM_IMA_CITRIX:
        nb_samples = (buf_size / block_align) * (1 + ((block_align / ch) - 4) * 4);
        break;
    }

    /* validate coded sample count */
    if (has_coded_samples && (*coded_samples <= 0 || *coded_samples > nb_samples))
        return AVERROR_INVALIDDATA;

    return nb_samples;
}

static int brr_predict(const int filter, const int p1, const int p2)
{
    int p;

    switch (filter)  {
    case 0:
        return 0;
    case 1:
        p = p1;
        p -= p1 >> 4;
        return p;
    case 2:
        p = p1 << 1;
        p += (-(p1 + (p1 << 1))) >> 5;
        p -= p2;
        p += p2 >> 4;
        return p;
    case 3:
        p = p1 << 1;
        p += (-(p1 + (p1 << 2) + (p1 << 3))) >> 6;
        p -= p2;
        p += (p2 + (p2 << 1)) >> 4;
        return p;
    default:
        return 0;
    }
}

static int adpcm_decode_frame(AVCodecContext *avctx, AVFrame *frame,
                              int *got_frame_ptr, AVPacket *avpkt)
{
    const uint8_t *buf = avpkt->data;
    int buf_size = avpkt->size;
    ADPCMDecodeContext *c = avctx->priv_data;
    int channels = avctx->ch_layout.nb_channels;
    int16_t *samples;
    int16_t **samples_p;
    int st; /* stereo */
    int nb_samples, coded_samples, approx_nb_samples, ret;
    GetByteContext gb;

    bytestream2_init(&gb, buf, buf_size);
    nb_samples = get_nb_samples(avctx, &gb, buf_size, &coded_samples, &approx_nb_samples, avpkt->pts);
    if (nb_samples <= 0) {
        av_log(avctx, AV_LOG_ERROR, "invalid number of samples in packet\n");
        return AVERROR_INVALIDDATA;
    }

    /* get output buffer */
    frame->nb_samples = nb_samples;
    if ((ret = ff_get_buffer(avctx, frame, 0)) < 0)
        return ret;
    samples = (int16_t *)frame->data[0];
    samples_p = (int16_t **)frame->extended_data;

    /* use coded_samples when applicable */
    /* it is always <= nb_samples, so the output buffer will be large enough */
    if (coded_samples) {
        if (!approx_nb_samples && coded_samples != nb_samples)
            av_log(avctx, AV_LOG_WARNING, "mismatch in coded sample count\n");
        frame->nb_samples = nb_samples = coded_samples;
    }

    st = channels == 2 ? 1 : 0;

    switch (avctx->codec->id) {
    CASE(ADPCM_IMA_QT,
        /* In QuickTime, IMA is encoded by chunks of 34 bytes (=64 samples).
           Channel data is interleaved per-chunk. */
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            int predictor;
            int step_index;
            /* (pppppp) (piiiiiii) */

            /* Bits 15-7 are the _top_ 9 bits of the 16-bit initial predictor value */
            predictor = sign_extend(bytestream2_get_be16u(&gb), 16);
            step_index = predictor & 0x7F;
            predictor &= ~0x7F;

            if (cs->step_index == step_index) {
                int diff = predictor - cs->predictor;
                if (diff < 0)
                    diff = - diff;
                if (diff > 0x7f)
                    goto update;
            } else {
            update:
                cs->step_index = step_index;
                cs->predictor = predictor;
            }

            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }

            samples = samples_p[channel];

            for (int m = 0; m < 64; m += 2) {
                int byte = bytestream2_get_byteu(&gb);
                samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, byte & 15);
                samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, byte >> 4);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_WAV_MONO,
        for (int i = 0; i < channels; i++) {
            ADPCMChannelStatus *cs = &c->status[i];

            cs->predictor = samples_p[i][0] = sign_extend(bytestream2_get_le16u(&gb), 16);
            cs->step_index = av_clip(bytestream2_get_byteu(&gb), 0, 88);
            bytestream2_skipu(&gb, 1);

            for (int n = 0; n < (nb_samples - 1) / 8; n++) {
                samples = &samples_p[i][1 + n * 8];
                for (int m = 0; m < 8; m += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                    samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_WAV,
        for (int i = 0; i < channels; i++) {
            ADPCMChannelStatus *cs = &c->status[i];
            cs->predictor = samples_p[i][0] = sign_extend(bytestream2_get_le16u(&gb), 16);

            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       i, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        if (avctx->bits_per_coded_sample != 4) {
            int samples_per_block = ff_adpcm_ima_block_samples[avctx->bits_per_coded_sample - 2];
            int block_size = ff_adpcm_ima_block_sizes[avctx->bits_per_coded_sample - 2];
            uint8_t temp[20 + AV_INPUT_BUFFER_PADDING_SIZE] = { 0 };
            GetBitContext g;

            for (int n = 0; n < (nb_samples - 1) / samples_per_block; n++) {
                for (int i = 0; i < channels; i++) {
                    ADPCMChannelStatus *cs = &c->status[i];
                    samples = &samples_p[i][1 + n * samples_per_block];
                    for (int j = 0; j < block_size; j++) {
                        temp[j] = buf[4 * channels + block_size * n * channels +
                                        (j % 4) + (j / 4) * (channels * 4) + i * 4];
                    }
                    ret = init_get_bits8(&g, (const uint8_t *)&temp, block_size);
                    if (ret < 0)
                        return ret;
                    for (int m = 0; m < samples_per_block; m++) {
                        samples[m] = adpcm_ima_wav_expand_nibble(cs, &g,
                                          avctx->bits_per_coded_sample);
                    }
                }
            }
            bytestream2_skip(&gb, avctx->block_align - channels * 4);
        } else {
            for (int n = 0; n < (nb_samples - 1) / 8; n++) {
                for (int i = 0; i < channels; i++) {
                    ADPCMChannelStatus *cs = &c->status[i];
                    samples = &samples_p[i][1 + n * 8];
                    for (int m = 0; m < 8; m += 2) {
                        int v = bytestream2_get_byteu(&gb);
                        samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                        samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                    }
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_FSB,
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int nb_samples_per_block = 64 * (block_size / (36 * channels)) + 1;

                if (nb_samples_per_block <= 1)
                    break;

                for (int bs = 0; bs < nb_samples_per_block-1; bs += 64) {
                    for (int bc = 0; bc < channels; bc++) {
                        ADPCMChannelStatus *cs = &c->status[bc];

                        cs->predictor = samples_p[bc][bs + samples_offset] = sign_extend(bytestream2_get_le16u(&gb), 16);
                    }

                    for (int bc = 0; bc < channels; bc++) {
                        ADPCMChannelStatus *cs = &c->status[bc];

                        cs->step_index = bytestream2_get_byteu(&gb);
                        bytestream2_skipu(&gb, 1);
                        if (cs->step_index > 88u) {
                            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                                   bc, cs->step_index);
                            return AVERROR_INVALIDDATA;
                        }
                    }

                    for (int n = 0; n < 16; n++) {
                        for (int bc = 0; bc < channels; bc++) {
                            ADPCMChannelStatus *cs = &c->status[bc];

                            samples = samples_p[bc] + bs + 1 + n * 4 + samples_offset;
                            for (int m = 0; m < 4; m += 2) {
                                int v = bytestream2_get_byteu(&gb);
                                samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                                samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                            }
                        }
                    }

                    samples_offset += nb_samples_per_block-1;
                    left -= block_size;
                    frame->nb_samples--;
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_XBOX_SBR,
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int nb_samples_per_block = 64 * (block_size / (36 * channels)) + 1;

                for (int bs = 0; bs < nb_samples_per_block-1; bs += 64) {
                    for (int i = 0; i < channels; i++) {
                        ADPCMChannelStatus *cs = &c->status[i];

                        cs->predictor = samples_p[i][bs + samples_offset] = sign_extend(bytestream2_get_le16u(&gb), 16);
                    }

                    for (int i = 0; i < channels; i++) {
                        ADPCMChannelStatus *cs = &c->status[i];

                        cs->step_index = bytestream2_get_byteu(&gb);
                        bytestream2_skipu(&gb, 1);
                        if (cs->step_index > 88u) {
                            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                                   i, cs->step_index);
                            return AVERROR_INVALIDDATA;
                        }
                    }

                    for (int n = 0; n < 16; n++) {
                        for (int i = 0; i < channels; i++) {
                            ADPCMChannelStatus *cs = &c->status[i];

                            samples = samples_p[i] + bs + 1 + n * 4 + samples_offset;
                            for (int m = 0; m < 4; m += 2) {
                                int v = bytestream2_get_byteu(&gb);
                                samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                                samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                            }
                        }
                    }
                }

                samples_offset += nb_samples_per_block-1;
                left -= block_size;
                frame->nb_samples--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_XBOX,
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int nb_samples_per_block = 64 * (block_size / (36 * channels)) + 1;

                for (int bc = 0; bc < channels; bc += 2) {
                    for (int bs = 0; bs < nb_samples_per_block-1; bs += 64) {
                        for (int i = 0; i < FFMIN(channels, 2); i++) {
                            ADPCMChannelStatus *cs = &c->status[bc+i];

                            cs->predictor = samples_p[bc+i][bs + samples_offset] = sign_extend(bytestream2_get_le16u(&gb), 16);
                            cs->step_index = bytestream2_get_byteu(&gb);
                            bytestream2_skipu(&gb, 1);
                            if (cs->step_index > 88u) {
                                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                                       i, cs->step_index);
                                return AVERROR_INVALIDDATA;
                            }
                        }

                        for (int n = 0; n < 8; n++) {
                            for (int i = 0; i < FFMIN(channels, 2); i++) {
                                ADPCMChannelStatus *cs = &c->status[bc+i];

                                samples = samples_p[bc+i] + bs + 1 + n * 8 + samples_offset;
                                for (int m = 0; m < 8; m += 2) {
                                    int v = bytestream2_get_byteu(&gb);
                                    samples[m    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                                    samples[m + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                                }
                            }
                        }
                    }
                }

                samples_offset += nb_samples_per_block-1;
                left -= block_size;
                frame->nb_samples--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_XBOX_MONO,
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int nb_samples_per_block = 64 * (block_size / (36 * channels)) + 1;

                for (int ch = 0; ch < channels; ch++) {
                    ADPCMChannelStatus *cs = &c->status[ch];

                    for (int bs = 0; bs < nb_samples_per_block-1; bs += 64) {
                        cs->predictor = samples_p[ch][bs + samples_offset] = sign_extend(bytestream2_get_le16u(&gb), 16);
                        cs->step_index = bytestream2_get_byteu(&gb);
                        bytestream2_skipu(&gb, 1);
                        if (cs->step_index > 88u) {
                            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                                   ch, cs->step_index);
                            return AVERROR_INVALIDDATA;
                        }

                        samples = &samples_p[ch][1 + bs + samples_offset];
                        for (int n = 0; n < 64; n += 2) {
                            int v = bytestream2_get_byteu(&gb);
                            samples[n    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                            samples[n + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                        }
                    }
                }

                samples_offset += nb_samples_per_block-1;
                left -= block_size;
                frame->nb_samples--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_WW,
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int nb_samples_per_block = 64 * (block_size / (36 * channels)) + 1;

                for (int ch = 0; ch < channels; ch++) {
                    ADPCMChannelStatus *cs = &c->status[ch];

                    for (int bs = 0; bs < nb_samples_per_block-1; bs += 64) {
                        cs->predictor = samples_p[ch][bs + samples_offset] = sign_extend(bytestream2_get_be16u(&gb), 16);
                        cs->step_index = bytestream2_get_byteu(&gb);
                        bytestream2_skipu(&gb, 1);
                        if (cs->step_index > 88u) {
                            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                                   ch, cs->step_index);
                            return AVERROR_INVALIDDATA;
                        }

                        samples = &samples_p[ch][1 + bs + samples_offset];
                        for (int n = 0; n < 64; n += 2) {
                            int v = bytestream2_get_byteu(&gb);
                            samples[n    ] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                            samples[n + 1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                        }
                    }
                }

                samples_offset += nb_samples_per_block-1;
                left -= block_size;
                frame->nb_samples--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_4XM,
        for (int i = 0; i < channels; i++)
            c->status[i].predictor = sign_extend(bytestream2_get_le16u(&gb), 16);

        for (int i = 0; i < channels; i++) {
            c->status[i].step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (c->status[i].step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       i, c->status[i].step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int i = 0; i < channels; i++) {
            ADPCMChannelStatus *cs = &c->status[i];
            samples = (int16_t *)frame->data[i];
            for (int n = nb_samples >> 1; n > 0; n--) {
                int v = bytestream2_get_byteu(&gb);
                *samples++ = adpcm_ima_expand_nibble(cs, v & 0x0F, 4);
                *samples++ = adpcm_ima_expand_nibble(cs, v >> 4  , 4);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_AGM,
        for (int i = 0; i < channels; i++)
            c->status[i].predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
        for (int i = 0; i < channels; i++)
            c->status[i].step = sign_extend(bytestream2_get_le16u(&gb), 16);

        for (int n = 0; n < nb_samples >> (1 - st); n++) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_agm_expand_nibble(&c->status[0], v & 0xF);
            *samples++ = adpcm_agm_expand_nibble(&c->status[st], v >> 4 );
        }
        ) /* End of CASE */
    CASE(ADPCM_MS,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;
        const int nb_samples_per_block = (block_size - 6 * channels) * 2 / channels;

        for (int block = 0; block < avpkt->size / block_size; block++) {
            int offset = block * nb_samples_per_block;
            int block_predictor;

            if (avctx->ch_layout.nb_channels > 2) {
                for (int channel = 0; channel < avctx->ch_layout.nb_channels; channel++) {
                    ADPCMChannelStatus *cs = &c->status[channel];
                    samples = samples_p[channel] + offset;
                    block_predictor = bytestream2_get_byteu(&gb);
                    if (block_predictor > 6) {
                        av_log(avctx, AV_LOG_ERROR, "ERROR: block_predictor[%d] = %d\n",
                               channel, block_predictor);
                        return AVERROR_INVALIDDATA;
                    }
                    cs->coeff1 = ff_adpcm_AdaptCoeff1[block_predictor];
                    cs->coeff2 = ff_adpcm_AdaptCoeff2[block_predictor];
                    cs->idelta = sign_extend(bytestream2_get_le16u(&gb), 16);
                    cs->sample1 = sign_extend(bytestream2_get_le16u(&gb), 16);
                    cs->sample2 = sign_extend(bytestream2_get_le16u(&gb), 16);
                    *samples++ = cs->sample2;
                    *samples++ = cs->sample1;
                    for (int n = (nb_samples_per_block - 2) >> 1; n > 0; n--) {
                        int byte = bytestream2_get_byteu(&gb);
                        *samples++ = adpcm_ms_expand_nibble(cs, byte >> 4  );
                        *samples++ = adpcm_ms_expand_nibble(cs, byte & 0x0F);
                    }
                }
            } else {
                block_predictor = bytestream2_get_byteu(&gb);
                if (block_predictor > 6) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: block_predictor[0] = %d\n",
                           block_predictor);
                    return AVERROR_INVALIDDATA;
                }
                c->status[0].coeff1 = ff_adpcm_AdaptCoeff1[block_predictor];
                c->status[0].coeff2 = ff_adpcm_AdaptCoeff2[block_predictor];
                if (st) {
                    block_predictor = bytestream2_get_byteu(&gb);
                    if (block_predictor > 6) {
                        av_log(avctx, AV_LOG_ERROR, "ERROR: block_predictor[1] = %d\n",
                               block_predictor);
                        return AVERROR_INVALIDDATA;
                    }
                    c->status[1].coeff1 = ff_adpcm_AdaptCoeff1[block_predictor];
                    c->status[1].coeff2 = ff_adpcm_AdaptCoeff2[block_predictor];
                }
                c->status[0].idelta = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (st) {
                    c->status[1].idelta = sign_extend(bytestream2_get_le16u(&gb), 16);
                }

                c->status[0].sample1 = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (st) c->status[1].sample1 = sign_extend(bytestream2_get_le16u(&gb), 16);
                c->status[0].sample2 = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (st) c->status[1].sample2 = sign_extend(bytestream2_get_le16u(&gb), 16);

                *samples++ = c->status[0].sample2;
                if (st) *samples++ = c->status[1].sample2;
                *samples++ = c->status[0].sample1;
                if (st) *samples++ = c->status[1].sample1;
                for (int n = (nb_samples_per_block - 2) >> (1 - st); n > 0; n--) {
                    int byte = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_ms_expand_nibble(&c->status[0 ], byte >> 4  );
                    *samples++ = adpcm_ms_expand_nibble(&c->status[st], byte & 0x0F);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_MS_MONO,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;
        const int nb_samples_per_block = (block_size - 6 * channels) / channels * 2;

        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];

            for (int block = 0; block < avpkt->size / block_size; block++) {
                int offset = block * nb_samples_per_block;
                int block_predictor;

                samples = samples_p[channel] + offset;
                block_predictor = bytestream2_get_byteu(&gb);
                if (block_predictor > 6) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: block_predictor[%d] = %d\n",
                           channel, block_predictor);
                    return AVERROR_INVALIDDATA;
                }
                cs->coeff1 = ff_adpcm_AdaptCoeff1[block_predictor];
                cs->coeff2 = ff_adpcm_AdaptCoeff2[block_predictor];
                cs->idelta = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->sample1 = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->sample2 = sign_extend(bytestream2_get_le16u(&gb), 16);
                *samples++ = cs->sample2;
                *samples++ = cs->sample1;
                for (int n = (nb_samples_per_block - 2) >> 1; n > 0; n--) {
                    int byte = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_ms_expand_nibble(cs, byte >> 4);
                    *samples++ = adpcm_ms_expand_nibble(cs, byte & 15);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_CKMK,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;
        const int nb_samples_per_block = (block_size - 6 * channels) / channels * 2;

        for (int block = 0; block < avpkt->size / block_size; block++) {
            int offset = block * nb_samples_per_block;
            int block_predictor;

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                samples = samples_p[channel] + offset;
                block_predictor = bytestream2_get_byteu(&gb);
                if (block_predictor > 6) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: block_predictor[%d] = %d\n",
                           channel, block_predictor);
                    return AVERROR_INVALIDDATA;
                }
                cs->coeff1 = ff_adpcm_AdaptCoeff1[block_predictor];
                cs->coeff2 = ff_adpcm_AdaptCoeff2[block_predictor];
                cs->idelta = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->sample2 = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->sample1 = sign_extend(bytestream2_get_le16u(&gb), 16);
                *samples++ = cs->sample2;
                *samples++ = cs->sample1;
                for (int n = (nb_samples_per_block - 2) >> 1; n > 0; n--) {
                    int byte = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_ms_expand_nibble(cs, byte & 15);
                    *samples++ = adpcm_ms_expand_nibble(cs, byte >> 4);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_MTA2,
        int track, size, layout, offset[8] = { 0 };
        while (bytestream2_get_bytes_left(&gb) >= 16+0x90) {
            int track_channels = 0;

            track = bytestream2_get_byte(&gb);
            bytestream2_skip(&gb, 4);
            layout = bytestream2_get_byte(&gb);
            size = bytestream2_get_be16(&gb);
            bytestream2_skip(&gb, 8);

            for (int i = 0; i < 8; i++) {
                if ((layout >> i) & 1)
                    track_channels++;
            }

            if (size == 0 || layout == 0 || track_channels == 0)
                continue;

            if (track >= FF_ARRAY_ELEMS(offset))
                return AVERROR_INVALIDDATA;
            if (track_channels + track * track_channels > channels)
                return AVERROR_INVALIDDATA;

            for (int channel = 0; channel < track_channels; channel++) {
                uint32_t group_headers[4];
                int start;

                for (int group = 0; group < 4; group++)
                    group_headers[group] = bytestream2_get_be32u(&gb);

                start = bytestream2_tell(&gb);
                if (offset[track] >= nb_samples)
                    return AVERROR_INVALIDDATA;

                samples = samples_p[channel + track * track_channels] + offset[track];
                for (int group = 0; group < 4; group++) {
                    uint32_t group_header = group_headers[group];
                    int hist2, hist1, coefs, scale;

                    hist2 = sign_extend((group_header >> 16) & 0xfff0, 16);
                    hist1 = sign_extend((group_header >>  4) & 0xfff0, 16);
                    coefs = (group_header >> 5) & 0x07;
                    scale = (group_header >> 0) & 0x1f;

                    *samples++ = hist2;
                    *samples++ = hist1;

                    for (int row = 0; row < 8; row++) {
                        bytestream2_seek(&gb, start + group*0x4 + row*0x10, SEEK_SET);
                        for (int col = 0; col < 4; col++) {
                            int sample, byte = bytestream2_get_byteu(&gb);

                            sample = sign_extend(byte >> 4, 4);
                            sample = sample * adpcm_mta2_ranges[scale] + hist1 * adpcm_mta2_k0[coefs] + hist2 * adpcm_mta2_k1[coefs];
                            sample = av_clip_int16(sample);

                            if (row < 7 || col < 3)
                                *samples++ = sample;

                            hist2 = hist1;
                            hist1 = sample;

                            sample = sign_extend(byte & 15, 4);
                            sample = sample * adpcm_mta2_ranges[scale] + hist1 * adpcm_mta2_k0[coefs] + hist2 * adpcm_mta2_k1[coefs];
                            sample = av_clip_int16(sample);

                            if (row < 7 || col < 3)
                                *samples++ = sample;

                            hist2 = hist1;
                            hist1 = sample;
                        }
                    }
                }
            }

            offset[track] += 256;
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_MTAF,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;
        const int nb_samples_per_block = (block_size - 16 * (channels / 2)) * 2 / channels;
        int offset = 0;

        for (int block = 0; block < avpkt->size / block_size; block++) {
            for (int channel = 0; channel < channels; channel += 2) {
                ADPCMChannelStatus *cs0 = &c->status[channel + 0];
                ADPCMChannelStatus *cs1 = &c->status[channel + 1];

                bytestream2_skipu(&gb, 4);
                cs0->step = bytestream2_get_le16u(&gb) & 0x1f;
                cs1->step = bytestream2_get_le16u(&gb) & 0x1f;
                cs0->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                bytestream2_skipu(&gb, 2);
                cs1->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                bytestream2_skipu(&gb, 2);
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    samples_p[channel][offset + n    ] = adpcm_mtaf_expand_nibble(cs0, v & 0x0F);
                    samples_p[channel][offset + n + 1] = adpcm_mtaf_expand_nibble(cs0, v >> 4  );
                }
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    samples_p[channel + 1][offset + n    ] = adpcm_mtaf_expand_nibble(cs1, v & 0x0F);
                    samples_p[channel + 1][offset + n + 1] = adpcm_mtaf_expand_nibble(cs1, v >> 4  );
                }
            }

            offset += nb_samples_per_block;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_DK4,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->predictor  = *samples++ = sign_extend(bytestream2_get_le16u(&gb), 16);
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }
        for (int n = (nb_samples - 1) >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0 ], v >> 4  , 3);
            *samples++ = adpcm_ima_expand_nibble(&c->status[st], v & 0x0F, 3);
        }
        ) /* End of CASE */

        /* DK3 ADPCM support macro */
#define DK3_GET_NEXT_NIBBLE() \
    if (decode_top_nibble_next) { \
        nibble = last_byte >> 4; \
        decode_top_nibble_next = 0; \
    } else { \
        last_byte = bytestream2_get_byteu(&gb); \
        nibble = last_byte & 0x0F; \
        decode_top_nibble_next = 1; \
    }
    CASE(ADPCM_IMA_DK3,
        int last_byte = 0;
        int nibble;
        int decode_top_nibble_next = 0;
        int diff_channel;
        const int16_t *samples_end = samples + channels * nb_samples;

        bytestream2_skipu(&gb, 10);
        c->status[0].predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
        c->status[1].predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
        c->status[0].step_index = bytestream2_get_byteu(&gb);
        c->status[1].step_index = bytestream2_get_byteu(&gb);
        if (c->status[0].step_index > 88u || c->status[1].step_index > 88u) {
            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i/%i\n",
                   c->status[0].step_index, c->status[1].step_index);
            return AVERROR_INVALIDDATA;
        }
        /* sign extend the predictors */
        diff_channel = c->status[1].predictor;

        while (samples < samples_end) {

            /* for this algorithm, c->status[0] is the sum channel and
             * c->status[1] is the diff channel */

            /* process the first predictor of the sum channel */
            DK3_GET_NEXT_NIBBLE();
            adpcm_ima_expand_nibble(&c->status[0], nibble, 3);

            /* process the diff channel predictor */
            DK3_GET_NEXT_NIBBLE();
            adpcm_ima_expand_nibble(&c->status[1], nibble, 3);

            /* process the first pair of stereo PCM samples */
            diff_channel = (diff_channel + c->status[1].predictor) / 2;
            *samples++ = c->status[0].predictor + c->status[1].predictor;
            *samples++ = c->status[0].predictor - c->status[1].predictor;

            /* process the second predictor of the sum channel */
            DK3_GET_NEXT_NIBBLE();
            adpcm_ima_expand_nibble(&c->status[0], nibble, 3);

            /* process the second pair of stereo PCM samples */
            diff_channel = (diff_channel + c->status[1].predictor) / 2;
            *samples++ = c->status[0].predictor + c->status[1].predictor;
            *samples++ = c->status[0].predictor - c->status[1].predictor;
        }

        if ((bytestream2_tell(&gb) & 1))
            bytestream2_skip(&gb, 1);
        ) /* End of CASE */
    CASE(ADPCM_IMA_MAGIX,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int m = 0; m < avctx->block_align-8; m += 8) {
            uint32_t v0 = bytestream2_get_le32u(&gb);
            uint32_t v1 = bytestream2_get_le32u(&gb);

            for (int n = 8; n > 0; n--, v0 >>= 4, v1 >>= 4, samples += 2) {
                samples[0] = adpcm_ima_expand_nibble(&c->status[0], v0 & 15, 3);
                samples[1] = adpcm_ima_expand_nibble(&c->status[1], v1 & 15, 3);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_NDS,
        const int max_block_samples = (avctx->block_align - 4 * channels) * 2 / channels;
        int left = nb_samples;
        int offset = 0;

        while (left > 0) {
            const int block_samples = FFMIN(left, max_block_samples);

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                           channel, cs->step_index);
                    return AVERROR_INVALIDDATA;
                }

                samples = samples_p[channel] + offset;
                for (int m = 0; m < block_samples; m += 2) {
                    unsigned v0 = bytestream2_get_byteu(&gb);

                    *samples++ = adpcm_ima_expand_nibble(cs, v0 & 0xf, 3);
                    *samples++ = adpcm_ima_expand_nibble(cs, v0 >>  4, 3);
                }
            }

            offset += block_samples;
            left -= block_samples;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_REF,
        const int blocks = (avpkt->size > avctx->block_align) ? avpkt->size / avctx->block_align : 1;
        const int block_samples = (avctx->block_align > 0) ? nb_samples / blocks : nb_samples;

        for (int block = 0; block < blocks; block++) {
            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                samples = samples_p[channel] + block * block_samples;
                cs->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                samples[0] = cs->predictor;
                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                           channel, cs->step_index);
                    return AVERROR_INVALIDDATA;
                }
            }

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];

                samples = samples_p[channel] + block * block_samples + 1;
                for (int m = 1; m < block_samples; m += 2) {
                    unsigned v0 = bytestream2_get_byteu(&gb);

                    *samples++ = adpcm_ima_expand_nibble(cs, v0 & 15, 3);
                    *samples++ = adpcm_ima_expand_nibble(cs, v0 >> 4, 3);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_ISS,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v1, v2;
            int v = bytestream2_get_byteu(&gb);
            /* nibbles are swapped for mono */
            if (st) {
                v1 = v >> 4;
                v2 = v & 0x0F;
            } else {
                v2 = v >> 4;
                v1 = v & 0x0F;
            }
            *samples++ = adpcm_ima_expand_nibble(&c->status[0 ], v1, 3);
            *samples++ = adpcm_ima_expand_nibble(&c->status[st], v2, 3);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_MO,
        for (int subframe = 0; subframe < nb_samples / 256; subframe++) {
            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                           channel, cs->step_index);
                    return AVERROR_INVALIDDATA;
                }

                samples = samples_p[channel] + 256 * subframe;
                for (int n = 0; n < 256; n += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_ima_expand_nibble(cs, v & 0x0F, 3);
                    *samples++ = adpcm_ima_expand_nibble(cs, v >> 4  , 3);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_MOFLEX,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int subframe = 0; subframe < nb_samples / 256; subframe++) {
            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                samples = samples_p[channel] + 256 * subframe;
                for (int n = 0; n < 256; n += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_ima_expand_nibble(cs, v & 0x0F, 3);
                    *samples++ = adpcm_ima_expand_nibble(cs, v >> 4  , 3);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_DAT4,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;
        int nb_samples_per_block = (block_size/channels - 4) * 2;

        for (int block = 0; block < avpkt->size / block_size; block++) {
            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];

                cs->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                if (cs->step_index > 88u)
                    continue;

                samples = samples_p[channel] + block * nb_samples_per_block;
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);
                    samples[n+0] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                    samples[n+1] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_APC,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[0],  v >> 4);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], v & 15);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_HVQM2,
        int format = bytestream2_get_be16(&gb);

        bytestream2_skip(&gb, 4);
        decode_adpcm_ima_hvqm2(avctx, samples, nb_samples, format, &gb);
        ) /* End of CASE */
    CASE(ADPCM_IMA_HVQM4,
        int format = bytestream2_get_be16(&gb);

        bytestream2_skip(&gb, 4);
        decode_adpcm_ima_hvqm4(avctx, samples, nb_samples, format, &gb);
        ) /* End of CASE */
    CASE(ADPCM_IMA_SSI,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[0],  v >> 4);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], v & 15);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_APM,
        for (int n = nb_samples / 2; n > 0; n--) {
            for (int channel = 0; channel < channels; channel++) {
                int v = bytestream2_get_byteu(&gb);
                *samples++  = ff_adpcm_ima_qt_expand_nibble(&c->status[channel], v >> 4);
                samples[st] = ff_adpcm_ima_qt_expand_nibble(&c->status[channel], v & 15);
            }
            samples += channels;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_ALP,
        for (int n = nb_samples / 2; n > 0; n--) {
            for (int channel = 0; channel < channels; channel++) {
                int v = bytestream2_get_byteu(&gb);
                *samples++  = adpcm_ima_alp_expand_nibble(&c->status[channel], v >> 4  , 2);
                samples[st] = adpcm_ima_alp_expand_nibble(&c->status[channel], v & 0x0F, 2);
            }
            samples += channels;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_CUNNING,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            int16_t *smp = samples_p[channel];
            for (int n = 0; n < nb_samples / 2; n++) {
                int v = bytestream2_get_byteu(&gb);
                *smp++ = adpcm_ima_cunning_expand_nibble(cs, v & 0x0F);
                *smp++ = adpcm_ima_cunning_expand_nibble(cs, v >> 4);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_OKI,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_oki_expand_nibble(&c->status[0],  v >> 4  );
            *samples++ = adpcm_ima_oki_expand_nibble(&c->status[st], v & 0x0F);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_OKI4,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_oki4_expand_nibble(&c->status[0],  v >> 4  );
            *samples++ = adpcm_ima_oki4_expand_nibble(&c->status[st], v & 0x0F);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_WV6,
        for (int n = nb_samples; n > 0; n -= 2) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_wv6_expand_nibble(&c->status[0], v >> 4  );
            *samples++ = adpcm_ima_wv6_expand_nibble(&c->status[0], v & 0x0F);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_ZMUSIC,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_zmusic_expand_nibble(&c->status[st], v & 0x0F);
            *samples++ = adpcm_ima_zmusic_expand_nibble(&c->status[0],  v >> 4  );
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_RAD,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }
        for (int n = 0; n < nb_samples / 2; n++) {
            int byte[2];

            byte[0] = bytestream2_get_byteu(&gb);
            if (st)
                byte[1] = bytestream2_get_byteu(&gb);
            for (int channel = 0; channel < channels; channel++) {
                *samples++ = adpcm_ima_expand_nibble(&c->status[channel], byte[channel] & 0x0F, 3);
            }
            for (int channel = 0; channel < channels; channel++) {
                *samples++ = adpcm_ima_expand_nibble(&c->status[channel], byte[channel] >> 4  , 3);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_RAD_MONO,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
            int16_t *smp = samples_p[channel];
            for (int n = 0; n < nb_samples / 2; n++) {
                const int byte = bytestream2_get_byteu(&gb);

                *smp++ = adpcm_ima_expand_nibble(cs, byte & 0x0F, 3);
                *smp++ = adpcm_ima_expand_nibble(cs, byte >> 4  , 3);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_WS,
        if (c->vqa_version == 3) {
            const int block_samples = avctx->block_align / channels * 2;

            for (int block = 0; block < avpkt->size / avctx->block_align; block++) {
                for (int channel = 0; channel < channels; channel++) {
                    int16_t *smp = samples_p[channel] + block * block_samples;

                    for (int n = block_samples / 2; n > 0; n--) {
                        int v = bytestream2_get_byteu(&gb);
                        *smp++ = adpcm_ima_expand_nibble(&c->status[channel], v & 0x0F, 3);
                        *smp++ = adpcm_ima_expand_nibble(&c->status[channel], v >> 4  , 3);
                    }
                }
            }
        } else {
            for (int n = nb_samples / 2; n > 0; n--) {
                for (int channel = 0; channel < channels; channel++) {
                    int v = bytestream2_get_byteu(&gb);
                    *samples++  = adpcm_ima_expand_nibble(&c->status[channel], v & 0x0F, 3);
                    samples[st] = adpcm_ima_expand_nibble(&c->status[channel], v >> 4  , 3);
                }
                samples += channels;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA,
        const int block_align = avctx->block_align > 0 ? avctx->block_align : avpkt->size;
        const int block_size = (avpkt->size > block_align) ? block_align : avpkt->size;
        const int nb_blocks = (avpkt->size + block_size-1) / block_size;
        const int block_samples = (block_size / channels) * 2;
        int left_samples = nb_samples;

        for (int block = 0; block < nb_blocks; block++) {
            const int this_block_samples = FFMIN(block_samples, left_samples);

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                int16_t *smp = samples_p[channel] + block * block_samples;

                for (int n = this_block_samples / 2; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                }
            }

            left_samples -= this_block_samples;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_DVI,
        const int block_align = avctx->block_align > 0 ? avctx->block_align : avpkt->size;
        const int block_size = (avpkt->size > block_align) ? block_align : avpkt->size;
        const int nb_blocks = (avpkt->size + block_size-1) / block_size;
        const int block_samples = (block_size / channels) * 2;
        int left_samples = nb_samples;

        for (int block = 0; block < nb_blocks; block++) {
            const int this_block_samples = FFMIN(block_samples, left_samples);

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                int16_t *smp = samples_p[channel] + block * block_samples;

                for (int n = this_block_samples / 2; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                }
            }

            left_samples -= this_block_samples;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_TRA,
        const int block_align = avctx->block_align > 0 ? avctx->block_align : avpkt->size;
        const int block_size = (avpkt->size > block_align) ? block_align : avpkt->size;
        const int nb_blocks = (avpkt->size + block_size-1) / block_size;
        const int block_samples = (block_size / channels - 4) * 2;
        int left_samples = nb_samples;

        for (int block = 0; block < nb_blocks; block++) {
            const int this_block_samples = FFMIN(block_samples, left_samples);

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                int16_t *smp = samples_p[channel] + block * block_samples;

                bytestream2_skip(&gb, 1);
                cs->step_index = bytestream2_get_byteu(&gb);
                cs->predictor = sign_extend(bytestream2_get_be16u(&gb), 16);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                           cs->step_index);
                    return AVERROR_INVALIDDATA;
                }

                for (int n = this_block_samples / 2; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                }
            }

            left_samples -= this_block_samples;
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_HWAS,
        for (int block = 0; block < avpkt->size / FFMAX(avctx->block_align, 1); block++) {
            const int nb_samples_per_block = 2 * FFMAX(avctx->block_align, 1) / channels;

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = c->status + channel;

                cs->predictor = 0;
                cs->step_index = 0;
            }

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = c->status + channel;
                int16_t *smp = samples_p[channel] + block * nb_samples_per_block;

                for (int n = nb_samples_per_block / 2; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                    *smp++ = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_XMD,
        int bytes_remaining, block = 0;
        while (bytestream2_get_bytes_left(&gb) >= 21 * channels) {
            for (int channel = 0; channel < channels; channel++) {
                int16_t *out = samples_p[channel] + block * 32;
                int16_t history[2];
                uint16_t scale;

                history[1] = sign_extend(bytestream2_get_le16(&gb), 16);
                history[0] = sign_extend(bytestream2_get_le16(&gb), 16);
                scale = bytestream2_get_le16(&gb);

                out[0] = history[1];
                out[1] = history[0];

                for (int n = 0; n < 15; n++) {
                    unsigned byte = bytestream2_get_byte(&gb);
                    int32_t nibble[2];

                    nibble[0] = sign_extend(byte & 15, 4);
                    nibble[1] = sign_extend(byte >> 4, 4);

                    out[2+n*2] = nibble[0]*scale + ((history[0]*3667 - history[1]*1642) >> 11);
                    history[1] = history[0];
                    history[0] = out[2+n*2];

                    out[2+n*2+1] = nibble[1]*scale + ((history[0]*3667 - history[1]*1642) >> 11);
                    history[1] = history[0];
                    history[0] = out[2+n*2+1];
                }
            }

            block++;
        }
        bytes_remaining = bytestream2_get_bytes_left(&gb);
        if (bytes_remaining > 0) {
            bytestream2_skip(&gb, bytes_remaining);
        }
        ) /* End of CASE */
    CASE(ADPCM_XA,
        int16_t *out0 = samples_p[0];
        int16_t *out1 = samples_p[1];
        int samples_per_block = 28 * (3 - channels) * 4;
        int sample_offset = 0;
        int bytes_remaining;
        while (bytestream2_get_bytes_left(&gb) >= 128) {
            if ((ret = xa_decode(avctx, out0, out1, buf + bytestream2_tell(&gb),
                                 &c->status[0], &c->status[1],
                                 channels, sample_offset)) < 0)
                return ret;
            bytestream2_skipu(&gb, 128);
            sample_offset += samples_per_block;
        }
        /* Less than a full block of data left, e.g. when reading from
         * 2324 byte per sector XA; the remainder is padding */
        bytes_remaining = bytestream2_get_bytes_left(&gb);
        if (bytes_remaining > 0) {
            bytestream2_skip(&gb, bytes_remaining);
        }
        ) /* End of CASE */
    CASE(ADPCM_XA8,
        int16_t *out0 = samples_p[0];
        int16_t *out1 = samples_p[1];
        int samples_per_block = 28 * (3 - channels) * 2;
        int sample_offset = 0;
        int bytes_remaining;
        while (bytestream2_get_bytes_left(&gb) >= 128) {
            if ((ret = xa8_decode(avctx, out0, out1, buf + bytestream2_tell(&gb),
                                  &c->status[0], &c->status[1],
                                  channels, sample_offset)) < 0)
                return ret;
            bytestream2_skipu(&gb, 128);
            sample_offset += samples_per_block;
        }
        /* Less than a full block of data left, e.g. when reading from
         * 2324 byte per sector XA; the remainder is padding */
        bytes_remaining = bytestream2_get_bytes_left(&gb);
        if (bytes_remaining > 0) {
            bytestream2_skip(&gb, bytes_remaining);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_ESCAPE,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int byte = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_escape_expand_nibble(&c->status[0],  byte >> 4);
            *samples++ = adpcm_ima_escape_expand_nibble(&c->status[st], byte & 0xF);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_EA_EACS,
        for (int i = 0; i <= st; i++) {
            c->status[i].step_index = bytestream2_get_le32u(&gb);
            if (c->status[i].step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       i, c->status[i].step_index);
                return AVERROR_INVALIDDATA;
            }
        }
        for (int i = 0; i <= st; i++) {
            c->status[i].predictor  = bytestream2_get_le32u(&gb);
            if (FFABS((int64_t)c->status[i].predictor) > (1<<16))
                return AVERROR_INVALIDDATA;
        }

        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int byte   = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0],  byte >> 4,   3);
            *samples++ = adpcm_ima_expand_nibble(&c->status[st], byte & 0x0F, 3);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_EA_SEAD,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int byte = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0],  byte >> 4,   6);
            *samples++ = adpcm_ima_expand_nibble(&c->status[st], byte & 0x0F, 6);
        }
        ) /* End of CASE */
    CASE(ADPCM_EA,
        int previous_left_sample, previous_right_sample;
        int current_left_sample, current_right_sample;
        int next_left_sample, next_right_sample;
        int coeff1l, coeff2l, coeff1r, coeff2r;
        int shift_left, shift_right;

        /* Each EA ADPCM frame has a 12-byte header followed by 30-byte (stereo) or 15-byte (mono) pieces,
           each coding 28 stereo/mono samples. */

        if (channels != 2 && channels != 1)
            return AVERROR_INVALIDDATA;

        current_left_sample   = sign_extend(bytestream2_get_le16u(&gb), 16);
        previous_left_sample  = sign_extend(bytestream2_get_le16u(&gb), 16);
        current_right_sample  = sign_extend(bytestream2_get_le16u(&gb), 16);
        previous_right_sample = sign_extend(bytestream2_get_le16u(&gb), 16);

        for (int count1 = 0; count1 < nb_samples / 28; count1++) {
            int byte = bytestream2_get_byteu(&gb);
            coeff1l = ea_adpcm_table[ byte >> 4       ];
            coeff2l = ea_adpcm_table[(byte >> 4  ) + 4];
            coeff1r = ea_adpcm_table[ byte & 0x0F];
            coeff2r = ea_adpcm_table[(byte & 0x0F) + 4];

            if (channels == 2) {
                byte = bytestream2_get_byteu(&gb);
                shift_left = 20 - (byte >> 4);
                shift_right = 20 - (byte & 0x0F);
            } else{
                /* Mono packs the shift into the coefficient byte's lower nibble instead */
                shift_left = 20 - (byte & 0x0F);
            }

            for (int count2 = 0; count2 < (channels == 2 ? 28 : 14); count2++) {
                byte = bytestream2_get_byteu(&gb);
                next_left_sample  = sign_extend(byte >> 4, 4) * (1 << shift_left);

                next_left_sample = (next_left_sample +
                    (current_left_sample * coeff1l) +
                    (previous_left_sample * coeff2l) + 0x80) >> 8;

                previous_left_sample = current_left_sample;
                current_left_sample = av_clip_int16(next_left_sample);
                *samples++ = current_left_sample;

                if (channels == 2) {
                    next_right_sample = sign_extend(byte, 4) * (1 << shift_right);

                    next_right_sample = (next_right_sample +
                        (current_right_sample * coeff1r) +
                        (previous_right_sample * coeff2r) + 0x80) >> 8;

                    previous_right_sample = current_right_sample;
                    current_right_sample = av_clip_int16(next_right_sample);
                    *samples++ = current_right_sample;
                } else {
                    next_left_sample  = sign_extend(byte, 4) * (1 << shift_left);

                    next_left_sample = (next_left_sample +
                        (current_left_sample * coeff1l) +
                        (previous_left_sample * coeff2l) + 0x80) >> 8;

                    previous_left_sample = current_left_sample;
                    current_left_sample = av_clip_int16(next_left_sample);

                    *samples++ = current_left_sample;
                }
            }
        }
        bytestream2_skip(&gb, channels == 2 ? 2 : 3); // Skip terminating NULs
        ) /* End of CASE */
    CASE(ADPCM_EA_MAXIS_XA,
        const int blocks = (avpkt->size > avctx->block_align) ? avpkt->size / avctx->block_align : 1;
        const int block_samples = (avctx->block_align > 0) ? nb_samples / blocks : nb_samples;

        for (int b = 0; b < blocks; b++) {
            int coeff[2][2], shift[2];

            samples = ((int16_t *)frame->data[0]) + block_samples * b * channels;

            for (int channel = 0; channel < channels; channel++) {
                int byte = bytestream2_get_byteu(&gb);
                for (int i = 0; i < 2; i++)
                    coeff[channel][i] = ea_adpcm_table[(byte >> 4) + 4*i];
                shift[channel] = 20 - (byte & 0x0F);
            }
            for (int count1 = 0; count1 < block_samples / 2; count1++) {
                int byte[2];

                byte[0] = bytestream2_get_byteu(&gb);
                if (st) byte[1] = bytestream2_get_byteu(&gb);
                for (int i = 4; i >= 0; i-=4) { /* Pairwise samples LL RR (st) or LL LL (mono) */
                    for (int channel = 0; channel < channels; channel++) {
                        int sample = sign_extend(byte[channel] >> i, 4) * (1 << shift[channel]);
                        sample = (sample +
                                 c->status[channel].sample1 * coeff[channel][0] +
                                 c->status[channel].sample2 * coeff[channel][1] + 0x80) >> 8;
                        c->status[channel].sample2 = c->status[channel].sample1;
                        c->status[channel].sample1 = av_clip_int16(sample);
                        *samples++ = c->status[channel].sample1;
                    }
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
#if CONFIG_ADPCM_EA_R1_DECODER || CONFIG_ADPCM_EA_R2_DECODER || CONFIG_ADPCM_EA_R3_DECODER
    case AV_CODEC_ID_ADPCM_EA_R1:
    case AV_CODEC_ID_ADPCM_EA_R2:
    case AV_CODEC_ID_ADPCM_EA_R3: {
        /* channel numbering
           2chan: 0=fl, 1=fr
           4chan: 0=fl, 1=rl, 2=fr, 3=rr
           6chan: 0=fl, 1=c,  2=fr, 3=rl,  4=rr, 5=sub */
        const int big_endian = avctx->codec->id == AV_CODEC_ID_ADPCM_EA_R3;
        int previous_sample, current_sample, next_sample;
        int coeff1, coeff2;
        int shift;
        uint16_t *samplesC;
        int count = 0;
        int offsets[6];

        for (unsigned channel = 0; channel < channels; channel++)
            offsets[channel] = (big_endian ? bytestream2_get_be32(&gb) :
                                             bytestream2_get_le32(&gb)) +
                               (channels + 1) * 4;

        for (unsigned channel = 0; channel < channels; channel++) {
            int count1;

            bytestream2_seek(&gb, offsets[channel], SEEK_SET);
            samplesC = samples_p[channel];

            if (avctx->codec->id == AV_CODEC_ID_ADPCM_EA_R1) {
                current_sample  = sign_extend(bytestream2_get_le16(&gb), 16);
                previous_sample = sign_extend(bytestream2_get_le16(&gb), 16);
            } else {
                current_sample  = c->status[channel].predictor;
                previous_sample = c->status[channel].prev_sample;
            }

            for (count1 = 0; count1 < nb_samples / 28; count1++) {
                int byte = bytestream2_get_byte(&gb);
                if (byte == 0xEE) {  /* only seen in R2 and R3 */
                    current_sample  = sign_extend(bytestream2_get_be16(&gb), 16);
                    previous_sample = sign_extend(bytestream2_get_be16(&gb), 16);

                    for (int count2 = 0; count2 < 28; count2++)
                        *samplesC++ = sign_extend(bytestream2_get_be16(&gb), 16);
                } else {
                    coeff1 = ea_adpcm_table[ byte >> 4     ];
                    coeff2 = ea_adpcm_table[(byte >> 4) + 4];
                    shift = 20 - (byte & 0x0F);

                    for (int count2 = 0; count2 < 28; count2++) {
                        if (count2 & 1)
                            next_sample = (unsigned)sign_extend(byte,    4) << shift;
                        else {
                            byte = bytestream2_get_byte(&gb);
                            next_sample = (unsigned)sign_extend(byte >> 4, 4) << shift;
                        }

                        next_sample += (current_sample  * coeff1) +
                                       (previous_sample * coeff2);
                        next_sample = av_clip_int16(next_sample >> 8);

                        previous_sample = current_sample;
                        current_sample  = next_sample;
                        *samplesC++ = current_sample;
                    }
                }
            }
            if (!count) {
                count = count1;
            } else if (count != count1) {
                av_log(avctx, AV_LOG_WARNING, "per-channel sample count mismatch\n");
                count = FFMAX(count, count1);
            }

            if (avctx->codec->id != AV_CODEC_ID_ADPCM_EA_R1) {
                c->status[channel].predictor   = current_sample;
                c->status[channel].prev_sample = previous_sample;
            }
        }

        frame->nb_samples = count * 28;
        bytestream2_seek(&gb, 0, SEEK_END);
        break;
    }
#endif /* CONFIG_ADPCM_EA_Rx_DECODER */
    CASE(ADPCM_EA_XAS,
        for (int channel=0; channel < channels; channel++) {
            int coeff[2][4], shift[4];
            int16_t *s = samples_p[channel];
            for (int n = 0; n < 4; n++, s += 32) {
                int val = sign_extend(bytestream2_get_le16u(&gb), 16);
                for (int i = 0; i < 2; i++)
                    coeff[i][n] = ea_adpcm_table[(val&0x0F)+4*i];
                s[0] = val & ~0x0F;

                val = sign_extend(bytestream2_get_le16u(&gb), 16);
                shift[n] = 20 - (val & 0x0F);
                s[1] = val & ~0x0F;
            }

            for (int m = 2; m < 32; m += 2) {
                s = &samples_p[channel][m];
                for (int n = 0; n < 4; n++, s += 32) {
                    int level, pred;
                    int byte = bytestream2_get_byteu(&gb);

                    level = sign_extend(byte >> 4, 4) * (1 << shift[n]);
                    pred  = s[-1] * coeff[0][n] + s[-2] * coeff[1][n];
                    s[0]  = av_clip_int16((level + pred + 0x80) >> 8);

                    level = sign_extend(byte, 4) * (1 << shift[n]);
                    pred  = s[0] * coeff[0][n] + s[-1] * coeff[1][n];
                    s[1]  = av_clip_int16((level + pred + 0x80) >> 8);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_ACORN,
        for (int channel = 0; channel < channels; channel++) {
            ADPCMChannelStatus *cs = &c->status[channel];
            cs->predictor  = sign_extend(bytestream2_get_le16u(&gb), 16);
            cs->step_index = bytestream2_get_le16u(&gb) & 0xFF;
            if (cs->step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index[%d] = %i\n",
                       channel, cs->step_index);
                return AVERROR_INVALIDDATA;
            }
        }
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int byte = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0],  byte & 0x0F, 3);
            *samples++ = adpcm_ima_expand_nibble(&c->status[st], byte >> 4,   3);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_AMV,
        av_assert0(channels == 1);

        /*
         * Header format:
         *   int16_t  predictor;
         *   uint8_t  step_index;
         *   uint8_t  reserved;
         *   uint32_t frame_size;
         *
         * Some implementations have step_index as 16-bits, but others
         * only use the lower 8 and store garbage in the upper 8.
         */
        c->status[0].predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
        c->status[0].step_index = bytestream2_get_byteu(&gb);
        bytestream2_skipu(&gb, 5);
        if (c->status[0].step_index > 88u) {
            av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                   c->status[0].step_index);
            return AVERROR_INVALIDDATA;
        }

        for (int n = nb_samples >> 1; n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);

            *samples++ = adpcm_ima_expand_nibble(&c->status[0], v >> 4, 3);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0], v & 0xf, 3);
        }

        if (nb_samples & 1) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ima_expand_nibble(&c->status[0], v >> 4, 3);

            if (v & 0x0F) {
                /* Holds true on all the http://samples.mplayerhq.hu/amv samples. */
                av_log(avctx, AV_LOG_WARNING, "Last nibble set on packet with odd sample count.\n");
                av_log(avctx, AV_LOG_WARNING, "Sample will be skipped.\n");
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_PDA,
        for (int i = 0; i < channels; i++) {
            c->status[i].predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
            c->status[i].step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (c->status[i].step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                       c->status[i].step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);

            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[0 ], v >> 4);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], v & 15);
        }
        ) /* End of CASE */
    CASE(ADPCM_NXAP,
        const int nb_samples_per_block = (0x40 - 4) * 2;
        const int nb_blocks = avpkt->size / (channels * 0x40);

        for (int block = 0; block < nb_blocks; block++) {
            for (int i = 0; i < channels; i++) {
                ADPCMChannelStatus *cs = &c->status[i];
                const int samples_offset = block * nb_samples_per_block;

                cs->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                cs->step_index = bytestream2_get_le16u(&gb) >> 1;
                cs->step_index = av_clip(cs->step_index, 0x7f, 0x6000);

                samples = samples_p[i] + samples_offset;
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);

                    samples[n+0] = adpcmb_yamaha_expand_nibble(cs, v >> 4 );
                    samples[n+1] = adpcmb_yamaha_expand_nibble(cs, v & 0xf);
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_AWC,
        const int nb_samples_per_block = (0x800 - 4) * 2;
        const int nb_blocks = avpkt->size / channels / 0x800;

        for (int i = 0; i < channels; i++) {
            int samples_offset = 0;
            int left = nb_blocks;

            while (left > 0) {
                ADPCMChannelStatus *cs = &c->status[i];

                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                cs->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                           cs->step_index);
                    return AVERROR_INVALIDDATA;
                }

                samples = samples_p[i] + samples_offset;
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);

                    samples[n+0] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                    samples[n+1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                }

                samples_offset += nb_samples_per_block;
                left--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_RAUD,
        const int nb_samples_per_block = (0x800) * 2;
        const int nb_blocks = avpkt->size / channels / 0x804;

        for (int i = 0; i < channels; i++) {
            int samples_offset = 0;
            int left = nb_blocks;

            while (left > 0) {
                ADPCMChannelStatus *cs = &c->status[i];

                cs->step_index = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 1);
                cs->predictor = sign_extend(bytestream2_get_le16u(&gb), 16);
                if (cs->step_index > 88u) {
                    av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                           cs->step_index);
                    return AVERROR_INVALIDDATA;
                }

                samples = samples_p[i] + samples_offset;
                for (int n = 0; n < nb_samples_per_block; n += 2) {
                    int v = bytestream2_get_byteu(&gb);

                    samples[n+0] = ff_adpcm_ima_qt_expand_nibble(cs, v & 15);
                    samples[n+1] = ff_adpcm_ima_qt_expand_nibble(cs, v >> 4);
                }

                samples_offset += nb_samples_per_block;
                left--;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_IMA_SMJPEG,
        for (int i = 0; i < channels; i++) {
            c->status[i].predictor = sign_extend(bytestream2_get_be16u(&gb), 16);
            c->status[i].step_index = bytestream2_get_byteu(&gb);
            bytestream2_skipu(&gb, 1);
            if (c->status[i].step_index > 88u) {
                av_log(avctx, AV_LOG_ERROR, "ERROR: step_index = %i\n",
                       c->status[i].step_index);
                return AVERROR_INVALIDDATA;
            }
        }

        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);

            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[0 ], v >> 4);
            *samples++ = ff_adpcm_ima_qt_expand_nibble(&c->status[st], v & 15);
        }
        ) /* End of CASE */
    CASE(ADPCM_CT,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_ct_expand_nibble(&c->status[0 ], v >> 4  );
            *samples++ = adpcm_ct_expand_nibble(&c->status[st], v & 0x0F);
        }
        ) /* End of CASE */
#if CONFIG_ADPCM_SBPRO_2_DECODER || CONFIG_ADPCM_SBPRO_3_DECODER || \
    CONFIG_ADPCM_SBPRO_4_DECODER
    case AV_CODEC_ID_ADPCM_SBPRO_4:
    case AV_CODEC_ID_ADPCM_SBPRO_3:
    case AV_CODEC_ID_ADPCM_SBPRO_2:
        if (!c->status[0].step_index) {
            /* the first byte is a raw sample */
            *samples++ = 128 * (bytestream2_get_byteu(&gb) - 0x80);
            if (st)
                *samples++ = 128 * (bytestream2_get_byteu(&gb) - 0x80);
            c->status[0].step_index = 1;
            nb_samples--;
        }
        if (avctx->codec->id == AV_CODEC_ID_ADPCM_SBPRO_4) {
            for (int n = nb_samples >> (1 - st); n > 0; n--) {
                int byte = bytestream2_get_byteu(&gb);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                       byte >> 4,   4, 0);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[st],
                                                       byte & 0x0F, 4, 0);
            }
        } else if (avctx->codec->id == AV_CODEC_ID_ADPCM_SBPRO_3) {
            for (int n = (nb_samples<<st) / 3; n > 0; n--) {
                int byte = bytestream2_get_byteu(&gb);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                        byte >> 5        , 3, 0);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                       (byte >> 2) & 0x07, 3, 0);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                        byte & 0x03,       2, 0);
            }
        } else {
            for (int n = nb_samples >> (2 - st); n > 0; n--) {
                int byte = bytestream2_get_byteu(&gb);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                        byte >> 6        , 2, 2);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[st],
                                                       (byte >> 4) & 0x03, 2, 2);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[0],
                                                       (byte >> 2) & 0x03, 2, 2);
                *samples++ = adpcm_sbpro_expand_nibble(&c->status[st],
                                                        byte & 0x03,       2, 2);
            }
        }
        break;
#endif /* CONFIG_ADPCM_SBPRO_x_DECODER */
    CASE(ADPCM_SWF,
        adpcm_swf_decode(avctx, buf, buf_size, samples);
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_YAMAHA,
        for (int n = nb_samples >> (1 - st); n > 0; n--) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_yamaha_expand_nibble(&c->status[0 ], v & 0x0F);
            *samples++ = adpcm_yamaha_expand_nibble(&c->status[st], v >> 4  );
        }
        ) /* End of CASE */
    CASE(ADPCM_AICA,
        int block_samples = nb_samples, off = 0;
        int left = nb_samples;

        if (avctx->block_align > 0)
            block_samples = (FFMIN(avctx->block_align, avpkt->size) / channels) * 2;
        while (left > 0) {
            int nbs = FFMIN(left, block_samples);

            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];

                samples = samples_p[channel] + off;
                for (int n = nbs >> 1; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_yamaha_expand_nibble(cs, v & 0x0F);
                    *samples++ = adpcm_yamaha_expand_nibble(cs, v >> 4  );
                }
            }

            off += nbs;
            left -= nbs;
        }
        ) /* End of CASE */
    CASE(ADPCM_AFC,
        int blocks;

        if (avpkt->size >= avctx->block_align && avctx->block_align > channels) {
            blocks = avpkt->size / avctx->block_align;
        } else {
            blocks = 1;
        }

        for (int m = 0; m < blocks; m++) {
            for (int channel = 0; channel < channels; channel++) {
                int prev1 = c->status[channel].sample1;
                int prev2 = c->status[channel].sample2;

                samples = samples_p[channel] + m * 16;
                /* Read in every sample for this channel.  */
                int byte = bytestream2_get_byteu(&gb);
                int scale = 1 << (byte >> 4);
                int index = byte & 0xf;
                int factor1 = afc_coeffs[0][index];
                int factor2 = afc_coeffs[1][index];

                /* Decode 16 samples.  */
                for (int n = 0; n < 16; n++) {
                    int32_t sampledat;

                    if (n & 1) {
                        sampledat = sign_extend(byte, 4);
                    } else {
                        byte = bytestream2_get_byteu(&gb);
                        sampledat = sign_extend(byte >> 4, 4);
                    }

                    sampledat = ((prev1 * factor1 + prev2 * factor2) >> 11) +
                                sampledat * scale;
                    *samples = av_clip_int16(sampledat);
                    prev2 = prev1;
                    prev1 = *samples++;
                }

                c->status[channel].sample1 = prev1;
                c->status[channel].sample2 = prev2;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
#if CONFIG_ADPCM_NDSP_DECODER || CONFIG_ADPCM_NDSP_LE_DECODER
    case AV_CODEC_ID_ADPCM_NDSP:
    case AV_CODEC_ID_ADPCM_NDSP_LE:
        {
            int left = avpkt->size;
            int block_align = (avctx->block_align > 0) ? avctx->block_align : left;
            int samples_offset = 0;

            while (left > 0) {
                const int block_size = FFMIN(left, block_align);
                const int start_skip = (left == avpkt->size && avpkt->pts == 0) ? c->start_skip * channels : 0;
                const int nb_samples_per_block = 14 * ((block_size - start_skip) / channels / 8);

                for (int ch = 0; ch < channels; ch++) {
                    samples = samples_p[ch] + samples_offset;

                    if (avpkt->pts == 0 && c->start_skip > 0 && left == avpkt->size)
                        bytestream2_skip(&gb, c->start_skip);

                    /* Read in every sample for this channel.  */
                    for (int i = 0; i < nb_samples_per_block / 14; i++) {
                        int byte = bytestream2_get_byteu(&gb);
                        const int index = (byte >> 4) & 0x7;
                        const int scale = 1 << (byte & 0xF);
                        int factor1 = c->table[ch][index * 2];
                        int factor2 = c->table[ch][index * 2 + 1];
                        int sample1 = c->status[ch].sample1;
                        int sample2 = c->status[ch].sample2;

                        /* Decode 14 samples.  */
                        for (int n = 0; n < 14; n++) {
                            int32_t sampledat;

                            if (n & 1) {
                                sampledat = sign_extend(byte, 4);
                            } else {
                                byte = bytestream2_get_byteu(&gb);
                                sampledat = sign_extend(byte >> 4, 4);
                            }

                            sampledat = (sampledat * scale) << 11;
                            sampledat = ((sample1 * factor1 +
                                          sample2 * factor2 + 1024 + sampledat) >> 11);
                            *samples = av_clip_int16(sampledat);
                            sample2 = sample1;
                            sample1 = *samples++;
                        }

                        c->status[ch].sample1 = sample1;
                        c->status[ch].sample2 = sample2;
                    }
                }

                samples_offset += nb_samples_per_block;
                left -= block_size;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        break;
#endif /* CONFIG_ADPCM_NDSP(_LE)_DECODER */
#if CONFIG_ADPCM_THP_DECODER || CONFIG_ADPCM_THP_LE_DECODER
    case AV_CODEC_ID_ADPCM_THP:
    case AV_CODEC_ID_ADPCM_THP_LE:
#define THP_GET16(g) \
    sign_extend( \
        avctx->codec->id == AV_CODEC_ID_ADPCM_THP_LE ? \
        bytestream2_get_le16u(&(g)) : \
        bytestream2_get_be16u(&(g)), 16)

        for (int i = 0; i < channels; i++)
            for (int n = 0; n < 16; n++)
                c->table[i][n] = THP_GET16(gb);

        /* Initialize the previous sample.  */
        for (int i = 0; i < channels; i++) {
            c->status[i].sample1 = THP_GET16(gb);
            c->status[i].sample2 = THP_GET16(gb);
        }

        int pos = bytestream2_tell(&gb);
        for (int ch = 0; ch < channels; ch++) {
            samples = samples_p[ch];

            bytestream2_seek(&gb, pos + c->block_size * ch, SEEK_SET);
            if (avpkt->pts == 0 && c->start_skip > 0)
                bytestream2_skip(&gb, c->start_skip);

            /* Read in every sample for this channel.  */
            for (int i = 0; i < nb_samples; i++) {
                int byte = bytestream2_get_byte(&gb);
                const int index = (byte >> 4) & 0x7;
                const int scale = 1 << (byte & 0xF);
                int factor1 = c->table[ch][index * 2];
                int factor2 = c->table[ch][index * 2 + 1];
                int sample1 = c->status[ch].sample1;
                int sample2 = c->status[ch].sample2;

                /* Decode 14 samples.  */
                for (int n = 0; n < 14 && (i * 14 + n < nb_samples); n++) {
                    int32_t sampledat;

                    if (n & 1) {
                        sampledat = sign_extend(byte, 4);
                    } else {
                        byte = bytestream2_get_byte(&gb);
                        sampledat = sign_extend(byte >> 4, 4);
                    }

                    sampledat = (sampledat * scale) << 11;
                    sampledat = ((sample1 * factor1 +
                                  sample2 * factor2 + 1024 + sampledat) >> 11);
                    *samples = av_clip_int16(sampledat);
                    sample2 = sample1;
                    sample1 = *samples++;
                }

                c->status[ch].sample1 = sample1;
                c->status[ch].sample2 = sample2;
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        break;
#endif /* CONFIG_ADPCM_THP(_LE)_DECODER */
    CASE(ADPCM_NDSP_SI,
        int left = avpkt->size;
        int block_align = (avctx->block_align > 0) ? FFMIN(avctx->block_align, left) : left;
        int samples_offset = 0;
        int input_offset = 0;

        while (left > 0) {
            const int block_size = FFMIN(left, block_align);
            const int nb_samples_per_block = 14 * (block_size / channels / 8);

            for (int ch = 0; ch < channels; ch++) {
                uint8_t *src = avpkt->data + input_offset;
                samples = samples_p[ch] + samples_offset;

                /* Read in every sample for this channel.  */
                for (int i = 0; i < (nb_samples_per_block + 13) / 14; i++) {
                    int factor1, factor2, sample1, sample2;
                    int byte, index, scale;
                    uint8_t data[8];

                    for (int j = 0; j < 8; j++)
                        data[j] = src[(j/2)*2*channels + (j&1) + 2*ch];

                    byte = data[0];
                    index = (byte >> 4) & 0x7;
                    scale = 1 << (byte & 0xF);
                    factor1 = c->table[ch][index * 2];
                    factor2 = c->table[ch][index * 2 + 1];
                    sample1 = c->status[ch].sample1;
                    sample2 = c->status[ch].sample2;

                    /* Decode 14 samples.  */
                    for (int n = 0; n < 14 && (i * 14 + n < nb_samples_per_block); n++) {
                        int32_t sampledat;

                        if (n & 1) {
                            sampledat = sign_extend(byte, 4);
                        } else {
                            byte = data[1+n/2];
                            sampledat = sign_extend(byte >> 4, 4);
                        }

                        sampledat = (sampledat * scale) << 11;
                        sampledat = ((sample1 * factor1 +
                                      sample2 * factor2 + 1024 + sampledat) >> 11);
                        *samples = av_clip_int16(sampledat);
                        sample2 = sample1;
                        sample1 = *samples++;
                    }

                    c->status[ch].sample1 = sample1;
                    c->status[ch].sample2 = sample2;
                }
            }

            samples_offset += nb_samples_per_block;
            input_offset += block_size;
            left -= block_size;
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_NDSP_SI1,
        for (int block = 0; block < avpkt->size / FFMAX(avctx->block_align, 8 * channels); block++) {
            for (int n = 0; n < 8; n++) {
                for (int ch = 0; ch < channels; ch++) {
                    int byte, scale, coeff1, coeff2, sample1, sample2;
                    ADPCMChannelStatus *chs = &c->status[ch];
                    int32_t sampledat;

                    if (n == 0) {
                        int index;

                        byte = bytestream2_get_byteu(&gb);
                        index = (byte >> 4) & 0x7;
                        chs->step = 1 << (byte & 0xF);
                        chs->coeff1 = c->table[ch][index * 2];
                        chs->coeff2 = c->table[ch][index * 2 + 1];
                    } else {
                        sample1 = chs->sample1;
                        sample2 = chs->sample2;
                        coeff1 = chs->coeff1;
                        coeff2 = chs->coeff2;
                        scale =  chs->step;

                        byte = bytestream2_get_byteu(&gb);

                        sampledat = sign_extend(byte >> 4, 4);
                        sampledat = (sampledat * scale) << 11;
                        sampledat = ((sample1 * coeff1 +
                                      sample2 * coeff2 + 1024 + sampledat) >> 11);
                        *samples = av_clip_int16(sampledat);
                        sample2 = sample1;
                        sample1 = *samples++;

                        sampledat = sign_extend(byte, 4);
                        sampledat = (sampledat * scale) << 11;
                        sampledat = ((sample1 * coeff1 +
                                      sample2 * coeff2 + 1024 + sampledat) >> 11);
                        *samples = av_clip_int16(sampledat);
                        sample2 = sample1;
                        sample1 = *samples++;

                        chs->sample1 = sample1;
                        chs->sample2 = sample2;
                    }
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_DTK,
        for (int channel = 0; channel < channels; channel++) {
            samples = samples_p[channel];

            /* Read in every sample for this channel.  */
            for (int i = 0; i < nb_samples / 28; i++) {
                int byte, header;
                if (channel)
                    bytestream2_skipu(&gb, 1);
                header = bytestream2_get_byteu(&gb);
                bytestream2_skipu(&gb, 3 - channel);

                /* Decode 28 samples.  */
                for (int n = 0; n < 28; n++) {
                    int32_t sampledat, prev;

                    switch (header >> 4) {
                    case 1:
                        prev = (c->status[channel].sample1 * 0x3c);
                        break;
                    case 2:
                        prev = (c->status[channel].sample1 * 0x73) - (c->status[channel].sample2 * 0x34);
                        break;
                    case 3:
                        prev = (c->status[channel].sample1 * 0x62) - (c->status[channel].sample2 * 0x37);
                        break;
                    default:
                        prev = 0;
                    }

                    prev = av_clip_intp2((prev + 0x20) >> 6, 21);

                    byte = bytestream2_get_byteu(&gb);
                    if (!channel)
                        sampledat = sign_extend(byte, 4);
                    else
                        sampledat = sign_extend(byte >> 4, 4);

                    sampledat = ((sampledat * (1 << 12)) >> (header & 0xf)) * (1 << 6) + prev;
                    *samples++ = av_clip_int16(sampledat >> 6);
                    c->status[channel].sample2 = c->status[channel].sample1;
                    c->status[channel].sample1 = sampledat;
                }
            }
            if (!channel)
                bytestream2_seek(&gb, 0, SEEK_SET);
        }
        ) /* End of CASE */
    CASE(ADPCM_N64,
        ADPCMChannelStatus *cs = &c->status[0];
        int coefs[8*2*8] = { 0 };

        if (avctx->extradata) {
            int version, order, entries;
            GetByteContext cb;

            bytestream2_init(&cb, avctx->extradata, avctx->extradata_size);

            version = bytestream2_get_be16(&cb);
            order = bytestream2_get_be16(&cb);
            entries = bytestream2_get_be16(&cb);
            if (version != 1 || order != 2 || entries > 8)
                return AVERROR_INVALIDDATA;

            for (int n = 0; n < order * entries * 8; n++)
                coefs[n] = sign_extend(bytestream2_get_be16(&cb), 16);
        }

        for (int block = 0; block < avpkt->size / 9; block++) {
            int scale, index, codes[16];
            int16_t hist[8] = { 0 };
            const int order = 2;
            int16_t out[16];

            hist[6] = cs->sample2;
            hist[7] = cs->sample1;

            samples = samples_p[0] + block * 16;

            scale = (buf[0] >> 4) & 0xF;
            index = (buf[0] >> 0) & 0xF;
            scale = 1 << scale;
            index = FFMIN(index, 8);

            for (int i = 0, j = 0; i < 16; i += 2, j++) {
                int n0 = (buf[j+1] >> 4) & 0xF;
                int n1 = (buf[j+1] >> 0) & 0xF;

                if (n0 & 8)
                    n0 = n0 - 16;
                if (n1 & 8)
                    n1 = n1 - 16;

                codes[i+0] = n0 * scale;
                codes[i+1] = n1 * scale;
            }

            for (int j = 0; j < 2; j++) {
                int *sf_codes = &codes[j*8];
                int16_t *sf_out = &out[j*8];

                for (int i = 0; i < 8; i++) {
                    int sample;
                    unsigned delta = 0;

                    for (int o = 0; o < order; o++)
                        delta += coefs[o*8 + i] * hist[(8 - order) + o];

                    for (int k = i-1; k > -1; k--) {
                        for (int o = 1; o < order; o++)
                            delta += sf_codes[(i-1) - k] * (unsigned)coefs[(o*8) + k];
                    }

                    sample = sf_codes[i] * 2048;
                    sample = (int)(sample + delta) / 2048;
                    sample = av_clip_int16(sample);
                    sf_out[i] = sample;
                }

                for (int i = 8 - order; i < 8; i++)
                    hist[i] = sf_out[i];
            }

            memcpy(samples, out, sizeof(out));

            cs->sample2 = hist[6];
            cs->sample1 = hist[7];

            buf += 9;
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    CASE(ADPCM_PROCYON,
        for (int block = 0; block < avpkt->size / FFMAX(avctx->block_align, 16 * channels); block++) {
            const int nb_samples_per_block = 30 * FFMAX(avctx->block_align, 16 * channels) / (16 * channels);

            for (int channel = 0; channel < channels; channel++) {
                int scale, coef1, coef2, hist1, hist2, filter;
                uint8_t frame[16], header;

                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                bytestream2_get_bufferu(&gb, frame, sizeof(frame));

                header = frame[0x0F] ^ 0x80;
                scale = 12 - (header & 0xf);
                filter = (header >> 4) & 0xf;
                if (filter >= FF_ARRAY_ELEMS(xa_adpcm_table))
                    return AVERROR_INVALIDDATA;

                coef1 = xa_adpcm_table[filter][0];
                coef2 = xa_adpcm_table[filter][1];

                hist1 = c->status[channel].sample1;
                hist2 = c->status[channel].sample2;

                for (int n = 0; n < 30; n++) {
                    uint8_t nibbles = frame[n>>1] ^ 0x80;
                    int32_t sample;

                    sample = (n&1) ? sign_extend(nibbles >>  4, 4) :
                                     sign_extend(nibbles & 0xF, 4);
                    sample = sample * (1 << 12);
                    if (scale < 0)
                        sample <<= -scale;
                    else
                        sample >>= scale;
                    sample = (hist1 * coef1 + hist2 * coef2 + 32) / 64  + (sample * 64);

                    hist2 = hist1;
                    hist1 = sample;

                    samples[n] = av_clip_int16((sample + 32) / 64);
                }

                c->status[channel].sample1 = hist1;
                c->status[channel].sample2 = hist2;
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_PSX,
        const int block_size = (avctx->block_align > 0) ? FFMIN(avctx->block_align, avpkt->size) : avpkt->size;

        for (int block = 0; block < avpkt->size / block_size; block++) {
            int nb_samples_per_block = block_size / (16 * channels) * 28;
            for (int channel = 0; channel < channels; channel++) {
                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                /* Read in every sample for this channel.  */
                for (int i = 0; i < nb_samples_per_block / 28; i++) {
                    int filter, shift, flag, byte, hist1, hist2;
                    float coef1, coef2;

                    filter = bytestream2_get_byteu(&gb);
                    shift  = filter & 15;
                    filter = filter >> 4;
                    flag = bytestream2_get_byteu(&gb) & 7;

                    if (filter > 4)
                        filter = 0;
                    if (shift > 12)
                        shift = 9;

                    coef1 = psx_adpcm_table[filter][0];
                    coef2 = psx_adpcm_table[filter][1];

                    hist1 = c->status[channel].sample1;
                    hist2 = c->status[channel].sample2;

                    /* Decode 28 samples.  */
                    shift = 20 - shift;
                    for (int n = 0; n < 28; n++) {
                        int sample = 0, scale;

                        if (n & 1) {
                            scale = sign_extend(byte >> 4, 4);
                        } else {
                            byte  = bytestream2_get_byteu(&gb);
                            scale = sign_extend(byte & 0xF, 4);
                        }

                        if (flag < 7) {
                            scale  = scale * (1 << shift);
                            sample = scale + (int32_t)((hist1 * coef1 + hist2 * coef2) * 256.f);
                            sample >>= 8;
                        }
                        *samples++ = av_clip_int16(sample);
                        hist2 = hist1;
                        hist1 = sample;
                    }

                    c->status[channel].sample1 = hist1;
                    c->status[channel].sample2 = hist2;
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_PSXC,
        for (int block = 0; block < avpkt->size / avctx->block_align; block++) {
            int nb_samples_per_block = ((avctx->block_align - 1) / channels) * 2;
            for (int channel = 0; channel < channels; channel++) {
                int coef1, coef2, hist1, hist2;
                int filter, shift, byte;

                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                filter = bytestream2_get_byteu(&gb);
                shift  = filter & 0xf;
                filter = filter >> 4;
                if (filter >= FF_ARRAY_ELEMS(xa_adpcm_table))
                    return AVERROR_INVALIDDATA;

                coef1 = xa_adpcm_table[filter][0];
                coef2 = xa_adpcm_table[filter][1];

                hist1 = c->status[channel].sample1;
                hist2 = c->status[channel].sample2;

                for (int n = 0; n < nb_samples_per_block; n++) {
                    int sample = 0, scale;

                    if (n & 1) {
                        scale = sign_extend(byte >> 4, 4);
                    } else {
                        byte  = bytestream2_get_byteu(&gb);
                        scale = sign_extend(byte & 0xF, 4);
                    }

                    scale  = scale * (1 << 12);
                    sample = (int)((scale >> shift) + (hist1 * coef1 + hist2 * coef2) / 64);
                    *samples++ = av_clip_int16(sample);
                    hist2 = hist1;
                    hist1 = sample;
                }

                c->status[channel].sample1 = hist1;
                c->status[channel].sample2 = hist2;
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_HEVAG,
        for (int block = 0; block < avpkt->size / FFMAX(avctx->block_align, 16 * channels); block++) {
            int nb_samples_per_block = 28 * FFMAX(avctx->block_align, 16 * channels) / (16 * channels);
            for (int channel = 0; channel < channels; channel++) {
                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                /* Read in every sample for this channel.  */
                for (int i = 0; i < nb_samples_per_block / 28; i++) {
                    float coef1, coef2, coef3, coef4;
                    int hist1, hist2, hist3, hist4;
                    int filter, shift, flag, byte;

                    byte = bytestream2_get_byteu(&gb);
                    shift = byte & 0xf;
                    filter = byte >> 4;
                    byte = bytestream2_get_byteu(&gb);
                    filter |= byte & 0xf0;
                    if (filter >= FF_ARRAY_ELEMS(hevag_coefs) || shift > 12)
                        return AVERROR_INVALIDDATA;
                    flag = byte & 0xf;

                    coef1 = hevag_coefs[filter][0];
                    coef2 = hevag_coefs[filter][1];
                    coef3 = hevag_coefs[filter][2];
                    coef4 = hevag_coefs[filter][3];

                    hist1 = c->status[channel].sample1;
                    hist2 = c->status[channel].sample2;
                    hist3 = c->status[channel].sample3;
                    hist4 = c->status[channel].sample4;

                    /* Decode 28 samples.  */
                    for (int n = 0; n < 28; n++) {
                        int sample = 0, code;

                        if (n & 1) {
                            code = sign_extend(byte >> 4, 4);
                        } else {
                            byte  = bytestream2_get_byteu(&gb);
                            code = sign_extend(byte & 0xF, 4);
                        }

                        if (flag < 0x07) {
                            code  = (code * (1 << 12)) >> shift;
                            sample = hist1 * coef1 +
                                     hist2 * coef2 +
                                     hist3 * coef3 +
                                     hist4 * coef4;
                            sample += code;
                        }
                        *samples++ = av_clip_int16(sample);
                        hist4 = hist3;
                        hist3 = hist2;
                        hist2 = hist1;
                        hist1 = sample;
                    }

                    c->status[channel].sample1 = hist1;
                    c->status[channel].sample2 = hist2;
                    c->status[channel].sample3 = hist3;
                    c->status[channel].sample4 = hist4;
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_DSA,
        int block_size = avctx->block_align > 0 ? avctx->block_align : avpkt->size;
        for (int block = 0; block < avpkt->size / block_size; block++) {
            int nb_samples_per_block = (block_size / channels - 1) * 2;
            for (int channel = 0; channel < channels; channel++) {
                int index, shift, byte, hist1;
                int32_t coef;

                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                index = bytestream2_get_byteu(&gb);
                shift = 12 - (index >> 4);
                index = index & 0xf;
                coef = dsa_coefs[index];
                hist1 = c->status[channel].sample1;

                for (int n = 0; n < nb_samples_per_block; n++) {
                    int32_t sample;

                    if (n & 1) {
                        sample = sign_extend(byte, 4);
                    } else {
                        byte = bytestream2_get_byteu(&gb);
                        sample = sign_extend(byte >> 4, 4);
                    }

                    sample = (int16_t)((sample * (1 << 12)) >> shift);
                    sample += ((hist1 * coef) >> 16);
                    samples[n] = av_clip_int16(sample * 4);
                    hist1 = sample;
                }

                c->status[channel].sample1 = hist1;
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_BRR,
        for (int i = 0; i < avpkt->size / 9; i++) {
            uint8_t control = bytestream2_get_byteu(&gb);
            int filter, factor, shift, hist1, hist2;

            shift = FFMIN(control >> 4, 12);
            factor = 1 << shift;
            filter = (control & 0xC) >> 2;

            hist1 = c->status[0].sample1;
            hist2 = c->status[0].sample2;

            for (int n = 0; n < 16; n += 2) {
                int32_t sample;
                int8_t nibble;
                uint8_t block;

                block = bytestream2_get_byteu(&gb);

                nibble = sign_extend(block >> 4, 4);
                sample = factor * nibble;
                sample += brr_predict(filter, hist1, hist2);
                sample = av_clip_int16(sample);

                *samples++ = sample;

                hist2 = hist1;
                hist1 = sample;

                nibble = sign_extend(block & 0xf, 4);
                sample = factor * nibble;
                sample += brr_predict(filter, hist1, hist2);
                sample = av_clip_int16(sample);

                *samples++ = sample;

                hist2 = hist1;
                hist1 = sample;
            }

            c->status[0].sample1 = hist1;
            c->status[0].sample2 = hist2;
        }
        ) /* End of CASE */
    CASE(ADPCM_FMOD,
        for (int block = 0; block < avpkt->size / avctx->block_align; block++) {
            int nb_samples_per_block = (avctx->block_align / channels - 0xc) * 2;
            for (int channel = 0; channel < channels; channel++) {
                uint32_t coefs, shifts;
                int hist2, hist1;

                samples = samples_p[channel] + block * nb_samples_per_block;
                av_assert0((block + 1) * nb_samples_per_block <= nb_samples);

                coefs  = bytestream2_get_le32u(&gb);
                shifts = bytestream2_get_le32u(&gb);
                hist1  = sign_extend(bytestream2_get_le16u(&gb), 16);
                hist2  = sign_extend(bytestream2_get_le16u(&gb), 16);

                for (int i = 0; i < 8; i++) {
                    int index, shift, coef1, coef2;

                    index = coefs  & 0x07;
                    shift = shifts & 0x0f;
                    coefs  >>= 4;
                    shifts >>= 4;

                    coef1 = fmod_adpcm_table[index][0];
                    coef2 = fmod_adpcm_table[index][1];
                    shift = 22 - shift;

                    for (int j = 0; j < 4; j++) {
                        uint32_t nibbles = bytestream2_get_le32u(&gb);

                        for (int k = 0; k < 8; k++) {
                            int32_t sample;

                            sample = (nibbles >> k*4) & 0x0f;
                            sample = (sample << 28) >> shift;
                            sample = (sample - hist2*coef2 + hist1*coef1) >> 6;
                            sample = av_clip_int16(sample);

                            *samples++ = sample;

                            hist2 = hist1;
                            hist1 = sample;
                        }
                    }
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_SANYO,
        int (*expand)(ADPCMChannelStatus *c, int bits);
        const int bpcs = avctx->bits_per_coded_sample;
        GetBitContext g;

        switch (bpcs) {
        case 3: expand = adpcm_sanyo_expand3; break;
        case 4: expand = adpcm_sanyo_expand4; break;
        case 5: expand = adpcm_sanyo_expand5; break;
        }

        for (int ch = 0; ch < channels; ch++) {
            c->status[ch].predictor = sign_extend(bytestream2_get_le16(&gb), 16);
            c->status[ch].step = sign_extend(bytestream2_get_le16(&gb), 16);
        }

        init_get_bits8(&g, gb.buffer, bytestream2_get_bytes_left(&gb));
        for (int i = 0; i < nb_samples; i++)
            for (int ch = 0; ch < channels; ch++)
                samples_p[ch][i] = expand(&c->status[ch], get_bits_le(&g, bpcs));

        align_get_bits(&g);
        bytestream2_skip(&gb, get_bits_count(&g) / 8);
        ) /* End of CASE */
    CASE(ADPCM_RHETOREX,
        for (int i = 0; i < nb_samples / 2; i++) {
            uint8_t byte = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_rhetorex_expand_nibble(c->status, byte >> 4);
            *samples++ = adpcm_rhetorex_expand_nibble(c->status, byte & 15);
        }
        ) /* End of CASE */
    CASE(ADPCM_ARGO,
        /*
         * The format of each block:
         *   uint8_t left_control;
         *   uint4_t left_samples[nb_samples];
         *   ---- and if stereo ----
         *   uint8_t right_control;
         *   uint4_t right_samples[nb_samples];
         *
         * Format of the control byte:
         * MSB [SSSSRDRR] LSB
         *   S = (Shift Amount - 2)
         *   D = Decoder flag.
         *   R = Reserved
         *
         * Each block relies on the previous two samples of each channel.
         * They should be 0 initially.
         */
        for (int block = 0; block < avpkt->size / avctx->block_align; block++) {
            for (int channel = 0; channel < avctx->ch_layout.nb_channels; channel++) {
                ADPCMChannelStatus *cs = c->status + channel;
                int control, shift;

                samples = samples_p[channel] + block * 32;

                /* Get the control byte and decode the samples, 2 at a time. */
                control = bytestream2_get_byteu(&gb);
                shift = (control >> 4) + 2;

                for (int n = 0; n < 16; n++) {
                    int sample = bytestream2_get_byteu(&gb);
                    *samples++ = ff_adpcm_argo_expand_nibble(cs, sample >> 4, shift, control & 0x04);
                    *samples++ = ff_adpcm_argo_expand_nibble(cs, sample >> 0, shift, control & 0x04);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_CIRCUS,
        for (int n = 0; n < nb_samples; n++) {
            for (int ch = 0; ch < channels; ch++) {
                int v = bytestream2_get_byteu(&gb);
                *samples++ = adpcm_circus_expand_nibble(&c->status[ch], v);
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_ZORK,
        for (int n = 0; n < nb_samples * channels; n++) {
            int v = bytestream2_get_byteu(&gb);
            *samples++ = adpcm_zork_expand_nibble(&c->status[n % channels], v);
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_MTF,
        for (int n = nb_samples / 2; n > 0; n--) {
            for (int channel = 0; channel < channels; channel++) {
                int v = bytestream2_get_byteu(&gb);
                *samples++  = adpcm_ima_mtf_expand_nibble(&c->status[channel], v >> 4);
                samples[st] = adpcm_ima_mtf_expand_nibble(&c->status[channel], v & 0x0F);
            }
            samples += channels;
        }
        ) /* End of CASE */
    CASE(ADPCM_TANTALUS,
        for (int block = 0; block < nb_samples/30; block++) {
            for (int channel = 0; channel < channels; channel++) {
                ADPCMChannelStatus *cs = &c->status[channel];
                cs->step = bytestream2_get_byteu(&gb) & 0xf;
                samples = samples_p[channel] + block * 30;
                for (int n = 15; n > 0; n--) {
                    int v = bytestream2_get_byteu(&gb);
                    *samples++ = adpcm_tantalus_expand_nibble(cs, v & 0xF);
                    *samples++ = adpcm_tantalus_expand_nibble(cs, v >> 4);
                }
            }
        }
        ) /* End of CASE */
    CASE(ADPCM_IMA_CITRIX,
        while (bytestream2_get_bytes_left(&gb) >= avctx->block_align) {
            for (int ch = 0; ch < channels; ch++) {
                *samples++ = c->status[ch].predictor = sign_extend(bytestream2_get_le16(&gb), 16);
                c->status[ch].step_index = bytestream2_get_byte(&gb);
                if (c->status[ch].step_index > 88)
                    return AVERROR_INVALIDDATA;
                bytestream2_skip(&gb, 1);
            }
            if (channels == 1) {
                for (int block = 0; block < avctx->block_align - 4; block++) {
                    uint8_t bits = bytestream2_get_byteu(&gb);
                    samples[0] = adpcm_citrix_expand(&c->status[0],  bits       & 3);
                    samples[1] = adpcm_citrix_expand(&c->status[0], (bits >> 2) & 3);
                    samples[2] = adpcm_citrix_expand(&c->status[0], (bits >> 4) & 3);
                    samples[3] = adpcm_citrix_expand(&c->status[0], (bits >> 6) & 3);
                    samples += 4;
                }
            } else { // channels == 2
                for (int block = 0; block < (avctx->block_align - 4*channels) / (4*channels); block++) {
                    for (int ch = 0; ch < channels; ch++) {
                        uint32_t bits = bytestream2_get_le32(&gb);
                        for (int j = 0; j < 16; j++)
                            samples[j*channels + ch] = adpcm_citrix_expand(&c->status[ch], (bits >> (2*j)) & 3);
                    }
                    samples += 16*channels;
                }
            }
        }
        bytestream2_seek(&gb, 0, SEEK_END);
        ) /* End of CASE */
    default:
        av_unreachable("There are cases for all codec ids using adpcm_decode_frame");
    }

    if (avpkt->size && bytestream2_tell(&gb) == 0) {
        av_log(avctx, AV_LOG_ERROR, "Nothing consumed\n");
        return AVERROR_INVALIDDATA;
    }

    *got_frame_ptr = frame->nb_samples > 0;

    if (avpkt->size < bytestream2_tell(&gb)) {
        av_log(avctx, AV_LOG_ERROR, "Overread of %d < %d\n", avpkt->size, bytestream2_tell(&gb));
        return avpkt->size;
    }

    return bytestream2_tell(&gb);
}

static av_cold void adpcm_flush(AVCodecContext *avctx)
{
    ADPCMDecodeContext *c = avctx->priv_data;

    /* Just nuke the entire status in state and re-init. */
    memset(c->status, 0, sizeof(c->status));

    switch (avctx->codec_id) {
    case AV_CODEC_ID_ADPCM_CT:
        c->status[0].step = c->status[1].step = 511;
        break;

    case AV_CODEC_ID_ADPCM_IMA_APC:
        if (avctx->extradata && avctx->extradata_size >= 8) {
            c->status[0].predictor = av_clip_intp2(AV_RL32(avctx->extradata    ), 18);
            c->status[1].predictor = av_clip_intp2(AV_RL32(avctx->extradata + 4), 18);
        }
        break;

    case AV_CODEC_ID_ADPCM_IMA_APM:
        if (avctx->extradata && avctx->extradata_size >= 28) {
            c->status[0].predictor  = av_clip_intp2(AV_RL32(avctx->extradata + 16), 18);
            c->status[0].step_index = av_clip(AV_RL32(avctx->extradata + 20), 0, 88);
            c->status[1].predictor  = av_clip_intp2(AV_RL32(avctx->extradata + 4), 18);
            c->status[1].step_index = av_clip(AV_RL32(avctx->extradata + 8), 0, 88);
        }
        break;

    case AV_CODEC_ID_ADPCM_IMA_WS:
        c->vqa_version = avctx->profile;
        break;
    default:
        return;
    }
}


static const enum AVSampleFormat sample_fmts_s16[]  = { AV_SAMPLE_FMT_S16,
                                                        AV_SAMPLE_FMT_NONE };
static const enum AVSampleFormat sample_fmts_s16p[] = { AV_SAMPLE_FMT_S16P,
                                                        AV_SAMPLE_FMT_NONE };
static const enum AVSampleFormat sample_fmts_both[] = { AV_SAMPLE_FMT_S16,
                                                        AV_SAMPLE_FMT_S16P,
                                                        AV_SAMPLE_FMT_NONE };

#define ADPCM_DECODER_0(id_, sample_fmts_, name_, long_name_)
#define ADPCM_DECODER_1(id_, sample_fmts_, name_, long_name_) \
const FFCodec ff_ ## name_ ## _decoder = {                  \
    .p.name         = #name_,                               \
    CODEC_LONG_NAME(long_name_),                            \
    .p.type         = AVMEDIA_TYPE_AUDIO,                   \
    .p.id           = id_,                                  \
    .p.capabilities = AV_CODEC_CAP_DR1,                     \
    CODEC_SAMPLEFMTS_ARRAY(sample_fmts_),                   \
    .priv_data_size = sizeof(ADPCMDecodeContext),           \
    .init           = adpcm_decode_init,                    \
    FF_CODEC_DECODE_CB(adpcm_decode_frame),                 \
    .flush          = adpcm_flush,                          \
};
#define ADPCM_DECODER_2(enabled, codec_id, name, sample_fmts, long_name) \
    ADPCM_DECODER_ ## enabled(codec_id, name, sample_fmts, long_name)
#define ADPCM_DECODER_3(config, codec_id, name, sample_fmts, long_name) \
    ADPCM_DECODER_2(config, codec_id, name, sample_fmts, long_name)
#define ADPCM_DECODER(codec, name, sample_fmts, long_name) \
    ADPCM_DECODER_3(CONFIG_ ## codec ## _DECODER, AV_CODEC_ID_ ## codec, \
                    name, sample_fmts, long_name)

/* Note: Do not forget to add new entries to the Makefile as well. */
ADPCM_DECODER(ADPCM_4XM,         sample_fmts_s16p, adpcm_4xm,         "ADPCM 4X Movie")
ADPCM_DECODER(ADPCM_AFC,         sample_fmts_s16p, adpcm_afc,         "ADPCM Nintendo Gamecube AFC")
ADPCM_DECODER(ADPCM_AGM,         sample_fmts_s16,  adpcm_agm,         "ADPCM AmuseGraphics Movie")
ADPCM_DECODER(ADPCM_AICA,        sample_fmts_s16p, adpcm_aica,        "ADPCM Yamaha AICA")
ADPCM_DECODER(ADPCM_ARGO,        sample_fmts_s16p, adpcm_argo,        "ADPCM Argonaut Games")
ADPCM_DECODER(ADPCM_BRR,         sample_fmts_s16p, adpcm_brr,         "ADPCM Bit Rate Reduction")
ADPCM_DECODER(ADPCM_CIRCUS,      sample_fmts_s16,  adpcm_circus,      "ADPCM Circus")
ADPCM_DECODER(ADPCM_CKMK,        sample_fmts_s16p, adpcm_ckmk,        "ADPCM CKMK")
ADPCM_DECODER(ADPCM_CT,          sample_fmts_s16,  adpcm_ct,          "ADPCM Creative Technology")
ADPCM_DECODER(ADPCM_DSA,         sample_fmts_s16p, adpcm_dsa,         "ADPCM Ocean DSA")
ADPCM_DECODER(ADPCM_DTK,         sample_fmts_s16p, adpcm_dtk,         "ADPCM Nintendo Gamecube DTK")
ADPCM_DECODER(ADPCM_EA,          sample_fmts_s16,  adpcm_ea,          "ADPCM Electronic Arts")
ADPCM_DECODER(ADPCM_EA_MAXIS_XA, sample_fmts_s16,  adpcm_ea_maxis_xa, "ADPCM Electronic Arts Maxis CDROM XA")
ADPCM_DECODER(ADPCM_EA_R1,       sample_fmts_s16p, adpcm_ea_r1,       "ADPCM Electronic Arts R1")
ADPCM_DECODER(ADPCM_EA_R2,       sample_fmts_s16p, adpcm_ea_r2,       "ADPCM Electronic Arts R2")
ADPCM_DECODER(ADPCM_EA_R3,       sample_fmts_s16p, adpcm_ea_r3,       "ADPCM Electronic Arts R3")
ADPCM_DECODER(ADPCM_EA_XAS,      sample_fmts_s16p, adpcm_ea_xas,      "ADPCM Electronic Arts XAS")
ADPCM_DECODER(ADPCM_FMOD,        sample_fmts_s16p, adpcm_fmod,        "ADPCM FMOD")
ADPCM_DECODER(ADPCM_HEVAG,       sample_fmts_s16p, adpcm_hevag,       "ADPCM High Efficiency VAG")
ADPCM_DECODER(ADPCM_IMA,         sample_fmts_s16p, adpcm_ima,         "ADPCM IMA")
ADPCM_DECODER(ADPCM_IMA_ACORN,   sample_fmts_s16,  adpcm_ima_acorn,   "ADPCM IMA Acorn Replay")
ADPCM_DECODER(ADPCM_IMA_AMV,     sample_fmts_s16,  adpcm_ima_amv,     "ADPCM IMA AMV")
ADPCM_DECODER(ADPCM_IMA_APC,     sample_fmts_s16,  adpcm_ima_apc,     "ADPCM IMA CRYO APC")
ADPCM_DECODER(ADPCM_IMA_APM,     sample_fmts_s16,  adpcm_ima_apm,     "ADPCM IMA Ubisoft APM")
ADPCM_DECODER(ADPCM_IMA_AWC,     sample_fmts_s16p, adpcm_ima_awc,     "ADPCM IMA AWC")
ADPCM_DECODER(ADPCM_IMA_CITRIX,  sample_fmts_s16,  adpcm_ima_citrix,  "ADPCM IMA Citrix")
ADPCM_DECODER(ADPCM_IMA_CUNNING, sample_fmts_s16p, adpcm_ima_cunning, "ADPCM IMA Cunning Developments")
ADPCM_DECODER(ADPCM_IMA_DAT4,    sample_fmts_s16,  adpcm_ima_dat4,    "ADPCM IMA Eurocom DAT4")
ADPCM_DECODER(ADPCM_IMA_DK3,     sample_fmts_s16,  adpcm_ima_dk3,     "ADPCM IMA Duck DK3")
ADPCM_DECODER(ADPCM_IMA_DK4,     sample_fmts_s16,  adpcm_ima_dk4,     "ADPCM IMA Duck DK4")
ADPCM_DECODER(ADPCM_IMA_DVI,     sample_fmts_s16p, adpcm_ima_dvi,     "ADPCM IMA Intel DVI")
ADPCM_DECODER(ADPCM_IMA_EA_EACS, sample_fmts_s16,  adpcm_ima_ea_eacs, "ADPCM IMA Electronic Arts EACS")
ADPCM_DECODER(ADPCM_IMA_EA_SEAD, sample_fmts_s16,  adpcm_ima_ea_sead, "ADPCM IMA Electronic Arts SEAD")
ADPCM_DECODER(ADPCM_IMA_ESCAPE,  sample_fmts_s16,  adpcm_ima_escape,  "ADPCM IMA Acorn Escape")
ADPCM_DECODER(ADPCM_IMA_FSB,     sample_fmts_s16p, adpcm_ima_fsb,     "ADPCM IMA FSB")
ADPCM_DECODER(ADPCM_IMA_HVQM2,   sample_fmts_s16,  adpcm_ima_hvqm2,   "ADPCM IMA HVQM2")
ADPCM_DECODER(ADPCM_IMA_HVQM4,   sample_fmts_s16,  adpcm_ima_hvqm4,   "ADPCM IMA HVQM4")
ADPCM_DECODER(ADPCM_IMA_HWAS,    sample_fmts_s16p, adpcm_ima_hwas,    "ADPCM IMA Nintendo DS HWAS")
ADPCM_DECODER(ADPCM_IMA_ISS,     sample_fmts_s16,  adpcm_ima_iss,     "ADPCM IMA Funcom ISS")
ADPCM_DECODER(ADPCM_IMA_MAGIX,   sample_fmts_s16,  adpcm_ima_magix,   "ADPCM IMA Magix")
ADPCM_DECODER(ADPCM_IMA_MO,      sample_fmts_s16p, adpcm_ima_mo,      "ADPCM IMA MobiClip MO")
ADPCM_DECODER(ADPCM_IMA_MOFLEX,  sample_fmts_s16p, adpcm_ima_moflex,  "ADPCM IMA MobiClip MOFLEX")
ADPCM_DECODER(ADPCM_IMA_MTF,     sample_fmts_s16,  adpcm_ima_mtf,     "ADPCM IMA Capcom's MT Framework")
ADPCM_DECODER(ADPCM_IMA_NDS,     sample_fmts_s16p, adpcm_ima_nds,     "ADPCM IMA Nintendo DS")
ADPCM_DECODER(ADPCM_IMA_OKI,     sample_fmts_s16,  adpcm_ima_oki,     "ADPCM IMA Dialogic OKI")
ADPCM_DECODER(ADPCM_IMA_OKI4,    sample_fmts_s16,  adpcm_ima_oki4,    "ADPCM IMA Dialogic OKI (4-shift)")
ADPCM_DECODER(ADPCM_IMA_PDA,     sample_fmts_s16,  adpcm_ima_pda,     "ADPCM IMA PlayDate")
ADPCM_DECODER(ADPCM_IMA_QT,      sample_fmts_s16p, adpcm_ima_qt,      "ADPCM IMA QuickTime")
ADPCM_DECODER(ADPCM_IMA_RAD,     sample_fmts_s16,  adpcm_ima_rad,     "ADPCM IMA Radical")
ADPCM_DECODER(ADPCM_IMA_RAD_MONO,sample_fmts_s16p, adpcm_ima_rad_mono,"ADPCM IMA Radical (Mono)")
ADPCM_DECODER(ADPCM_IMA_RAUD,    sample_fmts_s16p, adpcm_ima_raud,    "ADPCM IMA RAUD")
ADPCM_DECODER(ADPCM_IMA_REF,     sample_fmts_s16p, adpcm_ima_ref,     "ADPCM IMA Reflections")
ADPCM_DECODER(ADPCM_IMA_SSI,     sample_fmts_s16,  adpcm_ima_ssi,     "ADPCM IMA Simon & Schuster Interactive")
ADPCM_DECODER(ADPCM_IMA_SMJPEG,  sample_fmts_s16,  adpcm_ima_smjpeg,  "ADPCM IMA Loki SDL MJPEG")
ADPCM_DECODER(ADPCM_IMA_TRA,     sample_fmts_s16p, adpcm_ima_tra,     "ADPCM IMA TRA")
ADPCM_DECODER(ADPCM_IMA_ALP,     sample_fmts_s16,  adpcm_ima_alp,     "ADPCM IMA High Voltage Software ALP")
ADPCM_DECODER(ADPCM_IMA_WAV,     sample_fmts_s16p, adpcm_ima_wav,     "ADPCM IMA WAV")
ADPCM_DECODER(ADPCM_IMA_WAV_MONO,sample_fmts_s16p, adpcm_ima_wav_mono,"ADPCM IMA WAV (Mono)")
ADPCM_DECODER(ADPCM_IMA_WS,      sample_fmts_both, adpcm_ima_ws,      "ADPCM IMA Westwood")
ADPCM_DECODER(ADPCM_IMA_WV6,     sample_fmts_s16p, adpcm_ima_wv6,     "ADPCM IMA WV6")
ADPCM_DECODER(ADPCM_IMA_XBOX,    sample_fmts_s16p, adpcm_ima_xbox,    "ADPCM IMA Xbox")
ADPCM_DECODER(ADPCM_IMA_XBOX_SBR,sample_fmts_s16p,adpcm_ima_xbox_sbr, "ADPCM IMA Xbox (Saber)")
ADPCM_DECODER(ADPCM_IMA_XBOX_MONO,sample_fmts_s16p,adpcm_ima_xbox_mono,"ADPCM IMA Xbox (Mono)")
ADPCM_DECODER(ADPCM_IMA_WW,      sample_fmts_s16p, adpcm_ima_ww,      "ADPCM IMA Audiokinetic Wwise")
ADPCM_DECODER(ADPCM_IMA_ZMUSIC,  sample_fmts_s16,  adpcm_ima_zmusic,  "ADPCM IMA Z-Music")
ADPCM_DECODER(ADPCM_MS,          sample_fmts_both, adpcm_ms,          "ADPCM Microsoft")
ADPCM_DECODER(ADPCM_MS_MONO,     sample_fmts_s16p, adpcm_ms_mono,     "ADPCM Microsoft (Mono)")
ADPCM_DECODER(ADPCM_MTA2,        sample_fmts_s16p, adpcm_mta2,        "ADPCM MTA2")
ADPCM_DECODER(ADPCM_MTAF,        sample_fmts_s16p, adpcm_mtaf,        "ADPCM MTAF")
ADPCM_DECODER(ADPCM_N64,         sample_fmts_s16p, adpcm_n64,         "ADPCM Silicon Graphics N64")
ADPCM_DECODER(ADPCM_NDSP,        sample_fmts_s16p, adpcm_ndsp,        "ADPCM Nintendo DSP")
ADPCM_DECODER(ADPCM_NDSP_LE,     sample_fmts_s16p, adpcm_ndsp_le,     "ADPCM Nintendo DSP (little-endian)")
ADPCM_DECODER(ADPCM_NDSP_SI,     sample_fmts_s16p, adpcm_ndsp_si,     "ADPCM Nintendo DSP (sub-interleave 2)")
ADPCM_DECODER(ADPCM_NDSP_SI1,    sample_fmts_s16,  adpcm_ndsp_si1,    "ADPCM Nintendo DSP (sub-interleave 1)")
ADPCM_DECODER(ADPCM_NXAP,        sample_fmts_s16p, adpcm_nxap,        "ADPCM NXAP")
ADPCM_DECODER(ADPCM_PROCYON,     sample_fmts_s16p, adpcm_procyon,     "ADPCM Procyon")
ADPCM_DECODER(ADPCM_PSX,         sample_fmts_s16p, adpcm_psx,         "ADPCM PlayStation")
ADPCM_DECODER(ADPCM_PSXC,        sample_fmts_s16p, adpcm_psxc,        "ADPCM PlayStation C")
ADPCM_DECODER(ADPCM_RHETOREX,    sample_fmts_s16p, adpcm_rhetorex,    "ADPCM Rhetorex")
ADPCM_DECODER(ADPCM_SANYO,       sample_fmts_s16p, adpcm_sanyo,       "ADPCM Sanyo")
ADPCM_DECODER(ADPCM_SBPRO_2,     sample_fmts_s16,  adpcm_sbpro_2,     "ADPCM Sound Blaster Pro 2-bit")
ADPCM_DECODER(ADPCM_SBPRO_3,     sample_fmts_s16,  adpcm_sbpro_3,     "ADPCM Sound Blaster Pro 2.6-bit")
ADPCM_DECODER(ADPCM_SBPRO_4,     sample_fmts_s16,  adpcm_sbpro_4,     "ADPCM Sound Blaster Pro 4-bit")
ADPCM_DECODER(ADPCM_SWF,         sample_fmts_s16,  adpcm_swf,         "ADPCM Shockwave Flash")
ADPCM_DECODER(ADPCM_TANTALUS,    sample_fmts_s16p, adpcm_tantalus,    "ADPCM Tantalus")
ADPCM_DECODER(ADPCM_THP_LE,      sample_fmts_s16p, adpcm_thp_le,      "ADPCM Nintendo THP (little-endian)")
ADPCM_DECODER(ADPCM_THP,         sample_fmts_s16p, adpcm_thp,         "ADPCM Nintendo THP")
ADPCM_DECODER(ADPCM_XA,          sample_fmts_s16p, adpcm_xa,          "ADPCM CDROM XA")
ADPCM_DECODER(ADPCM_XA8,         sample_fmts_s16p, adpcm_xa8,         "ADPCM CDROM XA 8-bit")
ADPCM_DECODER(ADPCM_XMD,         sample_fmts_s16p, adpcm_xmd,         "ADPCM Konami XMD")
ADPCM_DECODER(ADPCM_YAMAHA,      sample_fmts_s16,  adpcm_yamaha,      "ADPCM Yamaha")
ADPCM_DECODER(ADPCM_ZORK,        sample_fmts_s16,  adpcm_zork,        "ADPCM Zork")
