/*
 * AC-4 Audio Decoder
 *
 * This file is part of Librempeg
 *
 * Librempeg is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * Librempeg is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with Librempeg; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef AVCODEC_AC4DEC_DATA_H
#define AVCODEC_AC4DEC_DATA_H

#include <stdint.h>
#include <libavutil/mem.h>

static const AVRational resampling_ratios[] = {
    {25025, 24000},
    {25, 24},
    {15, 16},
    {25025, 24000},
    {25, 24},
    {25025, 24000},
    {25, 24},
    {15, 16},
    {25025, 24000},
    {25, 24},
    {15, 16},
    {25025, 24000},
    {25, 24},
    {1, 1},
    {1, 1},
    {1, 1},
};

static const uint8_t aspx_hcb_env_level_15_f0_bits[71] = {
     7,  9,  9,  9,  9,  8,  8,  7,  7,  7,  7,  7,  6,  6,  6,  6,
     6,  6,  6,  6,  6,  6,  5,  5,  5,  5,  5,  5,  5,  5,  4,  5,
     5,  5,  5,  5,  5,  5,  4,  5,  5,  5,  5,  6,  6,  6,  7,  8,
     9, 10, 11, 12, 14, 14, 16, 16, 17, 17, 18, 18, 18, 18, 18, 18,
    18, 18, 17, 17, 17, 17, 16,
};

static const uint32_t aspx_hcb_env_level_15_f0_codes[71] = {
    0x0003e, 0x0007e, 0x0007f, 0x000be, 0x000bf, 0x0003e, 0x0005e, 0x00016,
    0x00017, 0x0001e, 0x0002e, 0x0005e, 0x00012, 0x0000a, 0x0000c, 0x0000e,
    0x00013, 0x00016, 0x0001a, 0x0001b, 0x00022, 0x00023, 0x00004, 0x00008,
    0x0000c, 0x0000e, 0x00012, 0x00014, 0x00015, 0x0001a, 0x00000, 0x00016,
    0x00018, 0x0001e, 0x0001c, 0x00019, 0x0001d, 0x0001f, 0x00001, 0x0001b,
    0x00013, 0x00010, 0x0000a, 0x0002e, 0x0001e, 0x0000d, 0x0003f, 0x000be,
    0x0017e, 0x002fe, 0x005fe, 0x00bfe, 0x02ffe, 0x02ffc, 0x0bffc, 0x0bff6,
    0x17ffa, 0x17ffb, 0x2fff8, 0x2fff9, 0x2fffa, 0x2fffb, 0x2fffc, 0x2fffd,
    0x2fffe, 0x2ffff, 0x17fe8, 0x17fe9, 0x17fea, 0x17feb, 0x0bff7,
};

static const uint8_t aspx_hcb_env_level_15_df_bits[141] = {
    21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
    21, 21, 17, 18, 19, 19, 21, 19, 19, 19, 21, 20, 20, 20, 16, 17,
    19, 19, 18, 18, 17, 15, 15, 15, 15, 14, 14, 14, 14, 13, 13, 13,
    13, 13, 13, 13, 12, 12, 12, 12, 12, 11, 10, 10,  9,  8,  8,  7,
     6,  6,  5,  4,  3,  2,  2,  3,  4,  6,  7,  7,  8,  9, 10, 11,
    11, 12, 13, 13, 14, 14, 15, 15, 15, 16, 16, 16, 17, 17, 17, 17,
    17, 18, 17, 17, 16, 17, 18, 19, 20, 21, 19, 19, 18, 16, 19, 21,
    16, 20, 20, 21, 21, 20, 20, 19, 20, 19, 17, 21, 21, 21, 21, 21,
    21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
};

static const uint32_t aspx_hcb_env_level_15_df_codes[141] = {
    0xfeff2, 0xfeff3, 0xfeff4, 0xfeff5, 0xfeff6, 0xfeff7, 0xfeff8, 0xfeff9,
    0xfeffa, 0xfeffb, 0xfeffc, 0xfeffd, 0xfeffe, 0xfefff, 0xff5e4, 0xff5e5,
    0xff5e6, 0xff5e7, 0x0fef4, 0x1fefe, 0x3fdea, 0x3ffde, 0xff7b6, 0x3fdec,
    0x3fdee, 0x3fd78, 0xff5ee, 0x7f798, 0x7faf6, 0x7f799, 0x07ffa, 0x0fef6,
    0x3fdef, 0x3ffdf, 0x1fdee, 0x1ffee, 0x0ff7e, 0x03d7e, 0x03fba, 0x03fbe,
    0x03ffe, 0x01ebe, 0x01fdc, 0x01fee, 0x01ff6, 0x00f5c, 0x00f5d, 0x00f7e,
    0x00f7f, 0x00ff4, 0x00ff6, 0x00ffe, 0x007bc, 0x007bd, 0x007f6, 0x007fc,
    0x007fe, 0x003fa, 0x001ea, 0x001fc, 0x000f6, 0x00076, 0x0007e, 0x0003c,
    0x0001c, 0x0003e, 0x0001e, 0x0000e, 0x00006, 0x00002, 0x00000, 0x00002,
    0x00006, 0x0003f, 0x0003e, 0x0003a, 0x00077, 0x000f4, 0x001ee, 0x003fc,
    0x003d6, 0x007be, 0x00ffa, 0x00f5e, 0x01ff7, 0x01fea, 0x03ffc, 0x03fd6,
    0x03fbb, 0x07fbe, 0x07fae, 0x07f7e, 0x0fff6, 0x0fffe, 0x0fef5, 0x0fef2,
    0x0f5fe, 0x1fffe, 0x0ff78, 0x0fefe, 0x07afe, 0x0ff79, 0x1fef4, 0x3fd7a,
    0x7f79a, 0xff5ef, 0x3fdfe, 0x3fffe, 0x1fdef, 0x07ffe, 0x3fdff, 0xff5f2,
    0x07f78, 0x7f79b, 0x7f79e, 0xff5f3, 0xff5f4, 0x7f79f, 0x7faf8, 0x3ffff,
    0x7f7f8, 0x3fbce, 0x0f5ff, 0xff5f5, 0xff5f6, 0xff5f7, 0xff5f8, 0xff5f9,
    0xff5fa, 0xff5fb, 0xff5fc, 0xff5fd, 0xff5fe, 0xff5ff, 0xff7ac, 0xff7ad,
    0xff7ae, 0xff7af, 0xff7b4, 0xff7b5, 0xff7b7,
};

static const uint8_t aspx_hcb_env_level_15_dt_bits[141] = {
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 18, 18, 18, 18, 18,
    17, 19, 17, 16, 17, 17, 17, 16, 15, 16, 15, 15, 14, 14, 14, 13,
    12, 10,  8,  6,  4,  2,  1,  3,  5,  7, 10, 11, 12, 14, 14, 15,
    15, 16, 16, 17, 16, 17, 17, 18, 16, 17, 18, 18, 19, 18, 19, 19,
    17, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 18, 19, 19, 19,
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
    19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19,
};

static const uint32_t aspx_hcb_env_level_15_dt_codes[141] = {
    0x7ffa0, 0x7ffa1, 0x7ffa2, 0x7ffa3, 0x7ffa4, 0x7ffa5, 0x7ffa6, 0x7ffa7,
    0x7ffa8, 0x7ffa9, 0x7ffaa, 0x7ffab, 0x7ffac, 0x7ffad, 0x7ffae, 0x7ffaf,
    0x7ffb0, 0x7ffb1, 0x7ffb2, 0x7ffb3, 0x7ffb4, 0x7ffb5, 0x7ffb6, 0x7ffb7,
    0x7ffb8, 0x7ffb9, 0x7ffba, 0x7ffbb, 0x7ffbc, 0x7ffbd, 0x7ffbe, 0x7ffbf,
    0x7ffc0, 0x7ffc1, 0x7ffc2, 0x7ffc3, 0x7ffc4, 0x7ffc5, 0x7ffc6, 0x7ffc7,
    0x7ffcc, 0x7ffcd, 0x7ffce, 0x3ff16, 0x3ff17, 0x3ff1e, 0x3ff1f, 0x3ff3c,
    0x1fefa, 0x7ffcf, 0x1ffb6, 0x0ff7c, 0x1ff8e, 0x1ffbe, 0x1fefb, 0x0ffc4,
    0x07fba, 0x0ffc6, 0x07fbb, 0x07fee, 0x03fdc, 0x03ff0, 0x03ff2, 0x01ffa,
    0x00ffe, 0x003fc, 0x000fe, 0x0003e, 0x0000e, 0x00002, 0x00000, 0x00006,
    0x0001e, 0x0007e, 0x003fe, 0x007fa, 0x00ff6, 0x03ffc, 0x03fde, 0x07fe6,
    0x07fec, 0x0ffda, 0x0ffde, 0x1fefe, 0x0ffce, 0x1fff2, 0x1ffbf, 0x3ff3d,
    0x0ff7e, 0x1feff, 0x3ff3e, 0x3ff3f, 0x7ffd2, 0x3ffe8, 0x7ffd3, 0x7ffd4,
    0x1ff8a, 0x3ff6e, 0x3ff6f, 0x7ffd5, 0x7ffd6, 0x7ffd7, 0x7ffd8, 0x7ffd9,
    0x7ffda, 0x7ffdb, 0x7ffde, 0x7ffdf, 0x3ffee, 0x7ffe0, 0x7ffe1, 0x7ffe2,
    0x7ffe3, 0x7ffe4, 0x7ffe5, 0x7ffe6, 0x7ffe7, 0x7ffe8, 0x7ffe9, 0x7ffea,
    0x7ffeb, 0x7ffec, 0x7ffed, 0x7ffee, 0x7ffef, 0x7fff0, 0x7fff1, 0x7fff2,
    0x7fff3, 0x7fff4, 0x7fff5, 0x7fff6, 0x7fff7, 0x7fff8, 0x7fff9, 0x7fffa,
    0x7fffb, 0x7fffc, 0x7fffd, 0x7fffe, 0x7ffff,
};

static const uint8_t aspx_hcb_env_balance_15_f0_bits[25] = {
    13, 16, 15, 15, 13, 12, 11,  9,  8,  7,  5,  3,  1,  2,  4,  7,
     8,  9, 10, 10, 11, 12, 13, 15, 16,
};

static const uint32_t aspx_hcb_env_balance_15_f0_codes[25] = {
    0x01ffe, 0x0ffea, 0x07ff6, 0x07ff7, 0x01fff, 0x00ffc, 0x007de, 0x001f6,
    0x000fa, 0x0007c, 0x0001e, 0x00006, 0x00000, 0x00002, 0x0000e, 0x0007e,
    0x000fe, 0x001fe, 0x003fe, 0x003ee, 0x007df, 0x00ffd, 0x01ffc, 0x07ff4,
    0x0ffeb,
};

static const uint8_t aspx_hcb_env_balance_15_df_bits[49] = {
    19, 19, 19, 19, 19, 18, 18, 17, 16, 16, 16, 15, 13, 13, 12, 12,
    12, 11, 10,  9,  8,  7,  5,  3,  1,  2,  4,  7,  8, 10, 10, 11,
    12, 12, 13, 13, 14, 15, 16, 18, 18, 17, 18, 18, 18, 19, 19, 18,
    19,
};

static const uint32_t aspx_hcb_env_balance_15_df_codes[49] = {
    0x7def6, 0x7def7, 0x7defa, 0x7defb, 0x7dffe, 0x3ef7c, 0x3ef7e, 0x1f7b2,
    0x0fbd8, 0x0fbda, 0x0fbfe, 0x07dfe, 0x01f6e, 0x01f7a, 0x00f9e, 0x00fb6,
    0x00fbc, 0x007da, 0x003ec, 0x001f2, 0x000fa, 0x0007e, 0x0001e, 0x00006,
    0x00000, 0x00002, 0x0000e, 0x0007f, 0x000f8, 0x003ee, 0x003e6, 0x007ce,
    0x00fbe, 0x00f9f, 0x01f7e, 0x01f6f, 0x03efe, 0x07dee, 0x0fbdb, 0x3ef78,
    0x3ef7f, 0x1f7b3, 0x3effc, 0x3effd, 0x3ef79, 0x7dffc, 0x7dffd, 0x3ef7a,
    0x7dfff,
};

static const uint8_t aspx_hcb_env_balance_15_dt_bits[49] = {
    15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 14, 13, 13, 12, 12,
    11, 12, 11,  9,  8,  7,  4,  2,  1,  3,  5,  7,  9,  9, 10, 11,
    11, 12, 12, 12, 12, 13, 15, 14, 15, 14, 15, 15, 15, 14, 14, 15,
    15,
};

static const uint32_t aspx_hcb_env_balance_15_dt_codes[49] = {
    0x07dce, 0x07dcf, 0x07ddc, 0x07ddd, 0x07dde, 0x07ddf, 0x07dec, 0x07ded,
    0x07dee, 0x07def, 0x07df8, 0x03ebe, 0x01f5e, 0x01f7a, 0x00fb8, 0x00fba,
    0x007cc, 0x00fbe, 0x007d6, 0x001f2, 0x000f8, 0x0007e, 0x0000e, 0x00002,
    0x00000, 0x00006, 0x0001e, 0x0007f, 0x001f6, 0x001f4, 0x003ea, 0x007cd,
    0x007ce, 0x00f9e, 0x00fae, 0x00fbc, 0x00f9f, 0x01f76, 0x07df9, 0x03ebf,
    0x07dfa, 0x03ee4, 0x07dfb, 0x07dfc, 0x07dfd, 0x03ee5, 0x03ee6, 0x07dfe,
    0x07dff,
};

static const uint8_t aspx_hcb_env_level_30_f0_bits[36] = {
    11, 13, 11, 11, 10, 10,  9,  8,  8,  7,  7,  7,  6,  6,  5,  5,
     4,  4,  4,  4,  3,  3,  3,  3,  4,  5,  6,  7,  9, 12, 14, 16,
    17, 16, 17, 16,
};

static const uint32_t aspx_hcb_env_level_30_f0_codes[36] = {
    0x007fe, 0x01ffe, 0x001de, 0x001df, 0x000ee, 0x003fe, 0x001fe, 0x0003a,
    0x000fe, 0x0001c, 0x0001e, 0x0007e, 0x0002e, 0x0003e, 0x00006, 0x00016,
    0x00002, 0x0000a, 0x0000c, 0x0000e, 0x00002, 0x00003, 0x00004, 0x00000,
    0x0000d, 0x0001e, 0x0002f, 0x0001f, 0x00076, 0x00ffe, 0x03ffe, 0x0fffc,
    0x1fffe, 0x0fffe, 0x1ffff, 0x0fffd,
};

static const uint8_t aspx_hcb_env_level_30_df_bits[71] = {
    23, 23, 23, 23, 22, 22, 22, 22, 20, 19, 19, 20, 19, 18, 17, 16,
    16, 15, 14, 14, 14, 13, 13, 13, 13, 12, 12, 12, 11, 10,  9,  8,
     5,  4,  2,  1,  3,  6,  8,  9, 11, 12, 14, 14, 15, 16, 17, 17,
    17, 18, 18, 19, 21, 19, 17, 20, 19, 20, 20, 20, 19, 19, 19, 22,
    22, 22, 22, 22, 22, 22, 22,
};

static const uint32_t aspx_hcb_env_level_30_df_codes[71] = {
    0x7ffbfc, 0x7ffbfd, 0x7ffbfe, 0x7ffbff, 0x3f7f6c, 0x3f7f6d, 0x3f7f6e,
    0x3f7f6f, 0x0fdfee, 0x07effe, 0x07efec, 0x0fff7e, 0x07ffbe, 0x03f7fe,
    0x01fbfe, 0x00fdfc, 0x00fff6, 0x007ffa, 0x003f7e, 0x003ffc, 0x003ffe,
    0x001fba, 0x001fbe, 0x001ffa, 0x001ffb, 0x000fdc, 0x000ffc, 0x000ffe,
    0x0007fc, 0x0003f6, 0x0001fe, 0x0000fe, 0x00001e, 0x00000e, 0x000002,
    0x000000, 0x000006, 0x00003e, 0x0000fc, 0x0001fa, 0x0007fd, 0x000fde,
    0x003fff, 0x003f76, 0x007eee, 0x00fdde, 0x01ffee, 0x01fbfc, 0x01fbfa,
    0x03ffde, 0x03f77e, 0x07efee, 0x1ffefe, 0x07eefe, 0x01fbbe, 0x0fdfea,
    0x07eff6, 0x0fdfda, 0x0fdfde, 0x0fdfef, 0x07eff4, 0x07efff, 0x07eeff,
    0x3f7fae, 0x3f7f7c, 0x3f7f7d, 0x3f7f7e, 0x3f7f7f, 0x3f7fac, 0x3f7fad,
    0x3f7faf,
};

static const uint8_t aspx_hcb_env_level_30_dt_bits[71] = {
    20, 20, 20, 20, 20, 20, 20, 20, 20, 19, 19, 20, 20, 18, 16, 16,
    15, 16, 15, 14, 14, 14, 13, 13, 13, 12, 12, 11, 11, 10, 10,  8,
     6,  4,  2,  1,  3,  5,  8,  9, 11, 11, 12, 13, 13, 14, 14, 14,
    15, 15, 16, 17, 18, 19, 18, 18, 18, 18, 20, 19, 20, 20, 20, 20,
    20, 20, 20, 20, 20, 20, 19,
};

static const uint32_t aspx_hcb_env_level_30_dt_codes[71] = {
    0x0ff7d6, 0x0ff7d7, 0x0ff7d8, 0x0ff7d9, 0x0ff7da, 0x0ff7db, 0x0ff7dc,
    0x0ff7dd, 0x0ff7de, 0x07fbfe, 0x07ed7a, 0x0ff7df, 0x0ff7f2, 0x03fdf4,
    0x00ff7c, 0x00fdae, 0x007ede, 0x00ff7e, 0x007ed2, 0x003f68, 0x003f6e,
    0x003ffa, 0x001fb6, 0x001ffe, 0x001fff, 0x000fde, 0x000ff6, 0x0007ec,
    0x0007fa, 0x0003fc, 0x0003fe, 0x0000fc, 0x00003e, 0x00000e, 0x000002,
    0x000000, 0x000006, 0x00001e, 0x0000fe, 0x0001fa, 0x0007fe, 0x0007ee,
    0x000fdf, 0x001ffc, 0x001fee, 0x003ffb, 0x003fde, 0x003f6a, 0x007ed6,
    0x007ed3, 0x00fdbe, 0x01fb7e, 0x03f6bc, 0x07fbf8, 0x03f6be, 0x03f6bf,
    0x03f6fe, 0x03f6ff, 0x0ff7f3, 0x07fbea, 0x0ff7f4, 0x0ff7f5, 0x0ff7f6,
    0x0ff7f7, 0x0ff7f8, 0x0ff7f9, 0x0ff7fa, 0x0ff7fb, 0x0ff7fe, 0x0ff7ff,
    0x07ed7b,
};

static const uint8_t aspx_hcb_env_balance_30_f0_bits[13] = {
    12, 11,  9,  7,  4,  3,  1,  2,  5,  6,  8, 10, 12,
};

static const uint16_t aspx_hcb_env_balance_30_f0_codes[13] = {
    0x000ffe, 0x0007fe, 0x0001fe, 0x00007e, 0x00000e, 0x000006, 0x000000,
    0x000002, 0x00001e, 0x00003e, 0x0000fe, 0x0003fe, 0x000fff,
};

static const uint8_t aspx_hcb_env_balance_30_df_bits[25] = {
    17, 17, 17, 15, 14, 12,  9,  9,  8,  7,  5,  2,  1,  3,  4,  7,
     8,  9, 10, 11, 14, 15, 16, 16, 17,
};

static const uint32_t aspx_hcb_env_balance_30_df_codes[25] = {
    0x01fffc, 0x01fffd, 0x01fffe, 0x007ffa, 0x003ffc, 0x000ffe, 0x0001fc,
    0x0001fe, 0x0000fa, 0x00007e, 0x00001e, 0x000002, 0x000000, 0x000006,
    0x00000e, 0x00007c, 0x0000fb, 0x0001fd, 0x0003fe, 0x0007fe, 0x003ffe,
    0x007ffb, 0x00fffc, 0x00fffd, 0x01ffff,
};

static const uint8_t aspx_hcb_env_balance_30_dt_bits[25] = {
    15, 15, 15, 14, 13, 13, 10,  8,  8,  7,  4,  2,  1,  3,  5,  7,
     9,  9,  9, 12, 14, 13, 14, 15, 14,
};

static const uint16_t aspx_hcb_env_balance_30_dt_codes[25] = {
    0x007ff2, 0x007ff3, 0x007ff6, 0x003ff6, 0x001ffe, 0x001fff, 0x0003fe,
    0x0000fa, 0x0000fe, 0x00007e, 0x00000e, 0x000002, 0x000000, 0x000006,
    0x00001e, 0x00007c, 0x0001fe, 0x0001f6, 0x0001f7, 0x000ffc, 0x003ffa,
    0x001ffa, 0x003ff7, 0x007ff7, 0x003ff8,
};

static const uint8_t aspx_hcb_noise_level_f0_bits[30] = {
    12, 12,  9,  7,  6,  6,  5,  1,  2,  3,  5,  7,  8,  8,  9, 10,
    11, 12, 12, 12, 13, 13, 14, 12, 14, 14, 11, 16, 16, 15,
};

static const uint16_t aspx_hcb_noise_level_f0_codes[30] = {
    0x000efe, 0x000eff, 0x0001fe, 0x000076, 0x00003a, 0x00003e, 0x00001e,
    0x000000, 0x000002, 0x000006, 0x00001c, 0x00007e, 0x0000fe, 0x0000ee,
    0x0001ff, 0x0003bc, 0x00077c, 0x000efa, 0x000ef4, 0x000ef6, 0x001df6,
    0x001dee, 0x003bee, 0x000ef5, 0x003bde, 0x003bef, 0x00077e, 0x00ef7e,
    0x00ef7f, 0x0077be,
};

static const uint8_t aspx_hcb_noise_level_df_bits[59] = {
    17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 13, 14, 16, 16, 15, 15,
    16, 15, 14, 14, 14, 14, 13, 11, 10,  9,  8,  7,  3,  1,  2,  4,
     5,  7,  8,  9, 10, 12, 13, 13, 14, 16, 17, 17, 17, 17, 17, 17,
    16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
};

static const uint32_t aspx_hcb_noise_level_df_codes[59] = {
    0x01f19e, 0x01f19f, 0x01f1dc, 0x01f1dd, 0x01f1de, 0x01f1df, 0x01f1e8,
    0x01f1e9, 0x01f1ea, 0x01f1eb, 0x001f1a, 0x003e7e, 0x00f9fe, 0x00f8f6,
    0x007c76, 0x007c66, 0x00f8f7, 0x007c7c, 0x003e3c, 0x003e36, 0x003e37,
    0x003e3a, 0x001f3e, 0x0007ce, 0x0003e6, 0x0001f0, 0x0000fa, 0x00007e,
    0x000006, 0x000000, 0x000002, 0x00000e, 0x00001e, 0x00007f, 0x0000fb,
    0x0001f2, 0x0003e2, 0x000f9e, 0x001f1c, 0x001f18, 0x003e32, 0x00f8fa,
    0x01f3fe, 0x01f1f6, 0x01f1f7, 0x01f1f8, 0x01f1f9, 0x01f1fa, 0x00f8ce,
    0x01f1fb, 0x01f1fc, 0x01f1fd, 0x01f1fe, 0x01f1ff, 0x01f3f8, 0x01f3f9,
    0x01f3fa, 0x01f3fb, 0x01f3ff,
};

static const uint8_t aspx_hcb_noise_level_dt_bits[59] = {
    16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 14, 16, 13, 11,  8,  6,  4,  3,  1,  2,  5,
     7, 10, 10, 12, 13, 13, 14, 15, 14, 15, 15, 16, 16, 16, 16, 16,
    16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16,
};

static const uint16_t aspx_hcb_noise_level_dt_codes[59] = {
    0x00ff70, 0x00ff71, 0x00ff72, 0x00ff73, 0x00ff74, 0x00ff75, 0x00ff76,
    0x00ff77, 0x00ff78, 0x00ff79, 0x00ff7a, 0x00ff7b, 0x00ff7c, 0x00ff7d,
    0x00ff7e, 0x00ff7f, 0x00ffe0, 0x00ffe1, 0x00ffe2, 0x00ffe3, 0x00ffe6,
    0x003fd6, 0x00ffe7, 0x001ffe, 0x0007fe, 0x0000fe, 0x00003e, 0x00000e,
    0x000006, 0x000000, 0x000002, 0x00001e, 0x00007e, 0x0003fe, 0x0003fc,
    0x000ff6, 0x001fe8, 0x001fea, 0x003fd2, 0x007fae, 0x003fd3, 0x007ff2,
    0x007faf, 0x00ffe8, 0x00ffe9, 0x00ffea, 0x00ffeb, 0x00ffec, 0x00ffed,
    0x00ffee, 0x00ffef, 0x00fff8, 0x00fff9, 0x00fffa, 0x00fffb, 0x00fffc,
    0x00fffd, 0x00fffe, 0x00ffff,
};

static const uint8_t aspx_hcb_noise_balance_f0_bits[13] = {
    10, 10,  9,  7,  5,  3,  2,  1,  4,  6,  9, 10, 10,
};

static const uint16_t aspx_hcb_noise_balance_f0_codes[13] = {
    0x0003fa, 0x0003fe, 0x0001fc, 0x00007e, 0x00001e, 0x000006,
    0x000002, 0x000000, 0x00000e, 0x00003e, 0x0001fe, 0x0003ff,
    0x0003fb,
};

static const uint8_t aspx_hcb_noise_balance_df_bits[25] = {
    13, 13, 13, 13, 13, 12, 13, 10,  9,  7,  4,  2,  1,  3,  5,  6,
     9, 11, 13, 13, 12, 12, 12, 12, 12,
};

static const uint16_t aspx_hcb_noise_balance_df_codes[25] = {
    0x001fd8, 0x001fd9, 0x001fda, 0x001fdb, 0x001fdc, 0x000fea, 0x001fdd,
    0x0003f8, 0x0001fe, 0x00007e, 0x00000e, 0x000002, 0x000000, 0x000006,
    0x00001e, 0x00003e, 0x0001ff, 0x0007f4, 0x001fde, 0x001fdf, 0x000fe4,
    0x000fe5, 0x000fe6, 0x000fe7, 0x000feb,
};

static const uint8_t aspx_hcb_noise_balance_dt_bits[25] = {
    11, 11, 11, 11, 11, 11, 11, 10, 10,  6,  4,  3,  1,  2,  5,  8,
     9, 11, 10, 11, 11, 11, 11, 11, 11,
};

static const uint16_t aspx_hcb_noise_balance_dt_codes[25] = {
    0x0007e6, 0x0007e7, 0x0007e8, 0x0007e9, 0x0007ea, 0x0007eb, 0x0007ec,
    0x0003fe, 0x0003ff, 0x00003e, 0x00000e, 0x000006, 0x000000, 0x000002,
    0x00001e, 0x0000fe, 0x0001f8, 0x0007ed, 0x0003f2, 0x0007ee, 0x0007ef,
    0x0007f8, 0x0007f9, 0x0007fa, 0x0007fb,
};

static const uint8_t aspx_codebook_signal_off[2][2] = { { 70, 35 }, { 24, 12 } };

static const uint8_t acpl_codebook_signal_off[4][2][3] = {
    {
        { 0, 16, 16 },
        { 0, 32, 32 },
    }, {
        { 0, 4, 4 },
        { 0, 8, 8 },
    }, {
        { 0,  8,  8 },
        { 0, 16, 16 },
    }, {
        { 10, 20, 20 },
        { 20, 40, 40 },
    },
};

static const uint8_t aspx_codebook_noise_off[2] = { 29, 12 };

static const uint8_t scale_factors_bits[121] = {
    17, 14, 14, 14, 14, 14, 14, 15, 14, 14, 14, 14, 14, 14, 14, 14,
    13, 13, 14, 14, 14, 14, 14, 13, 14, 13, 13, 14, 14, 13, 14, 13,
    13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 12, 12, 12, 12, 11,
    11, 11, 10,  9,  9,  8,  8,  6,  6,  4,  4,  3,  1,  4,  4,  5,
     6,  7,  8,  8,  9,  9, 10, 10, 11, 11, 11, 11, 12, 11, 12, 12,
    12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14,
    14, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
    14, 14, 14, 14, 14, 16, 14, 14, 17,
};

static const uint8_t scale_factors_codes[121] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x01,
    0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e,
    0x19, 0x1a, 0x0f, 0x10, 0x11, 0x12, 0x13, 0x1b,
    0x14, 0x1c, 0x1d, 0x15, 0x16, 0x1e, 0x17, 0x1f,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2a, 0x1b, 0x1c, 0x1d, 0x1e, 0x12,
    0x13, 0x14, 0x0d, 0x08, 0x09, 0x06, 0x07, 0x03,
    0x04, 0x02, 0x03, 0x03, 0x01, 0x04, 0x05, 0x03,
    0x05, 0x05, 0x08, 0x09, 0x0a, 0x0b, 0x0e, 0x0f,
    0x15, 0x16, 0x17, 0x18, 0x1f, 0x19, 0x20, 0x21,
    0x22, 0x23, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30,
    0x31, 0x32, 0x33, 0x34, 0x18, 0x19, 0x1a, 0x1b,
    0x1c, 0x35, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22,
    0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a,
    0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x01, 0x30, 0x31,
    0x01,
};

static const uint16_t frame_len_base_48khz[] = {
    1920, 1920, 2048, 1536, 1536, 960, 960, 1024,
    768, 768, 512, 384, 384, 2048, 0, 0,
};

static const uint8_t frame_len_base_idx_48khz[] = {
    1, 1, 0, 2, 2, 4, 4, 3, 5, 5, 6, 7, 7, 0, 0, 0,
};

static const uint16_t transf_length_48khz_2048[] = {
    128, 256, 512, 1024, 2048,
};

static const uint16_t transf_length_48khz_1920[] = {
    120, 240, 480, 960, 1920,
};

static const uint16_t transf_length_48khz_1536[] = {
    96, 192, 384, 768, 1536,
};

static const uint16_t transf_length_48khz_1024[] = {
    128, 256, 512, 1024, 1024,
};

static const uint16_t transf_length_48khz_960[] = {
    120, 240, 480, 960, 960,
};

static const uint16_t transf_length_48khz_768[] = {
    96, 192, 384, 768, 768,
};

static const uint16_t transf_length_48khz_512[] = {
    128, 256, 512, 512, 512,
};

static const uint16_t transf_length_48khz_384[] = {
    96, 192, 384, 384, 384,
};

static const uint16_t *transf_length_48khz[8] = {
    transf_length_48khz_2048,
    transf_length_48khz_1920,
    transf_length_48khz_1536,
    transf_length_48khz_1024,
    transf_length_48khz_960,
    transf_length_48khz_768,
    transf_length_48khz_512,
    transf_length_48khz_384,
};

static const float kbd_window_alpha[8][5] = {
    { 6.f, 5.f, 4.5f, 4.f, 3.0f },
    { 6.f, 5.f, 4.5f, 4.f, 3.0f },
    { 6.f, 5.f, 4.5f, 4.f, 3.0f },
    { 6.f, 5.f, 4.5f, 4.f, 4.0f },
    { 6.f, 5.f, 4.5f, 4.f, 4.0f },
    { 6.f, 5.f, 4.5f, 4.f, 4.0f },
    { 6.f, 5.f, 4.5f, 0.f, 4.5f },
    { 6.f, 5.f, 4.5f, 0.f, 4.5f },
};

static const uint8_t n_grp_bits_a[4][4] = {
    { 15, 10, 8, 7 },
    { 10,  7, 4, 3 },
    {  8,  4, 3, 1 },
    {  7,  3, 1, 1 },
};

static const uint8_t n_grp_bits_b[4] = {
    7, 3, 1, 0,
};

static const uint8_t n_grp_bits_c[4] = {
    3, 1, 0, 0,
};

static const uint8_t channel_mode_bits[] = {
    1, 2, 4, 4, 4, 7, 7, 7, 7, 7, 7, 8, 8, 9, 9, 9, 9,
};

static const uint16_t channel_mode_codes[] = {
    0, 2, 12, 13, 14, 120, 121, 122, 123, 124, 125, 252, 253, 508, 509, 510, 511,
};

static const uint8_t bitrate_indicator_bits[] = {
    3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
};

static const uint8_t bitrate_indicator_codes[] = {
    0, 2, 4, 6, 4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31,
};

static const uint8_t asf_codebook_dim[] = {
    4, 4, 4, 4, 2, 2, 2, 2, 2, 2, 2,
};

static const uint8_t asf_codebook_unsigned[] = {
    0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1,
};

static const uint8_t asf_codebook_off[] = {
    1, 1, 0, 0, 4, 4, 0, 0, 0, 0, 0,
};

static const uint8_t asf_codebook_mod[] = {
    3, 3, 3, 3, 9, 9, 8, 8, 13, 13, 17,
};

static const uint8_t asf_codebook_1_bits[81] = {
     9,  9, 12, 10,  7, 10, 12, 10, 11, 10,  7, 10,  7,  5,  7,  9,
     7, 10, 11,  8,  9,  9,  7,  9, 11, 10, 12,  9,  7, 10,  7,  5,
     7,  9,  7, 10,  7,  5,  7,  5,  1,  5,  7,  5,  7, 10,  7,  8,
     7,  5,  7, 10,  7,  9, 12, 10, 11,  9,  7, 10,  9,  8, 12, 10,
     7,  9,  7,  5,  7,  9,  7, 10, 12, 10, 12, 10,  7, 10, 12,  9,
     9,
};

static const uint8_t asf_codebook_1_codes[81] = {
    0x0b, 0x0c, 0x00, 0x04, 0x08, 0x05, 0x01, 0x06, 0x04, 0x07, 0x09, 0x08, 0x0a, 0x08, 0x0b, 0x0d,
    0x0c, 0x09, 0x05, 0x0d, 0x0e, 0x0f, 0x0d, 0x10, 0x06, 0x0a, 0x02, 0x11, 0x0e, 0x0b, 0x0f, 0x09,
    0x10, 0x12, 0x11, 0x0c, 0x12, 0x0a, 0x13, 0x0b, 0x01, 0x0c, 0x14, 0x0d, 0x15, 0x0d, 0x16, 0x0e,
    0x17, 0x0e, 0x18, 0x0e, 0x19, 0x13, 0x03, 0x0f, 0x07, 0x14, 0x1a, 0x10, 0x15, 0x0f, 0x04, 0x11,
    0x1b, 0x16, 0x1c, 0x0f, 0x1d, 0x17, 0x1e, 0x12, 0x05, 0x13, 0x06, 0x14, 0x1f, 0x15, 0x07, 0x18,
    0x19,
};

static const uint8_t asf_codebook_2_bits[81] = {
     8,  7,  9,  8,  6,  8,  9,  8,  9,  8,  6,  7,  6,  5,  6,  7,
     6,  8,  9,  7,  7,  7,  6,  7,  9,  8,  9,  8,  6,  8,  6,  5,
     6,  7,  6,  8,  6,  5,  6,  5,  3,  5,  6,  5,  6,  8,  6,  7,
     6,  5,  6,  8,  6,  8,  9,  8,  9,  8,  6,  7,  7,  7,  9,  8,
     6,  7,  6,  4,  6,  8,  6,  8,  9,  8,  9,  8,  6,  8,  9,  7,
     8,
};

static const uint8_t asf_codebook_2_codes[81] = {
    0x06, 0x0e, 0x00, 0x07, 0x0e, 0x08, 0x01, 0x09, 0x02, 0x0a, 0x0f, 0x0f, 0x10, 0x13, 0x11, 0x10,
    0x12, 0x0b, 0x03, 0x11, 0x12, 0x13, 0x13, 0x14, 0x04, 0x0c, 0x05, 0x0d, 0x14, 0x0e, 0x15, 0x14,
    0x16, 0x15, 0x17, 0x0f, 0x18, 0x15, 0x19, 0x16, 0x07, 0x17, 0x1a, 0x18, 0x1b, 0x10, 0x1c, 0x16,
    0x1d, 0x19, 0x1e, 0x11, 0x1f, 0x12, 0x06, 0x13, 0x07, 0x14, 0x20, 0x17, 0x18, 0x19, 0x08, 0x15,
    0x21, 0x1a, 0x22, 0x0d, 0x23, 0x16, 0x24, 0x17, 0x09, 0x18, 0x0a, 0x19, 0x25, 0x1a, 0x0b, 0x1b,
    0x1b,
};

static const uint8_t asf_codebook_3_bits[81] = {
     1,  4,  9,  4,  5,  9, 10, 10, 12,  4,  6, 10,  5,  6,  9, 10,
     9, 11, 10, 11, 14, 10, 10, 12, 12, 11, 13,  4,  6, 11,  6,  7,
    10, 11, 10, 12,  5,  7, 11,  6,  6, 10, 10,  9, 11,  9, 10, 13,
     9,  9, 12, 11, 11, 12,  9, 10, 15, 10, 11, 15, 14, 13, 15,  9,
    10, 14,  9, 10, 13, 13, 12, 14, 11, 12, 15, 11, 11, 14, 13, 12,
    14,
};

static const uint8_t asf_codebook_3_codes[81] = {
    0x01, 0x04, 0x0d, 0x05, 0x05, 0x0e, 0x0a, 0x0b, 0x05, 0x06, 0x04, 0x0c, 0x06, 0x05, 0x0f, 0x0d,
    0x10, 0x07, 0x0e, 0x08, 0x02, 0x0f, 0x10, 0x06, 0x07, 0x09, 0x04, 0x07, 0x06, 0x0a, 0x07, 0x06,
    0x11, 0x0b, 0x12, 0x08, 0x07, 0x07, 0x0c, 0x08, 0x09, 0x13, 0x14, 0x11, 0x0d, 0x12, 0x15, 0x05,
    0x13, 0x14, 0x09, 0x0e, 0x0f, 0x0a, 0x15, 0x16, 0x00, 0x17, 0x10, 0x01, 0x03, 0x06, 0x02, 0x16,
    0x18, 0x04, 0x17, 0x19, 0x07, 0x08, 0x0b, 0x05, 0x11, 0x0c, 0x03, 0x12, 0x13, 0x06, 0x09, 0x0d,
    0x07,
};

static const uint8_t asf_codebook_4_bits[81] = {
     4,  4,  9,  5,  4,  8,  9,  8, 11,  4,  5,  8,  5,  4,  8,  8,
     8, 10,  9,  9, 11,  8,  8, 10, 11, 10, 12,  4,  5,  8,  5,  4,
     8,  9,  8, 10,  4,  4,  8,  4,  4,  7,  8,  7,  9,  8,  8, 11,
     8,  7, 10, 10,  9, 10,  9,  8, 11,  8,  8, 11, 11, 10, 12,  8,
     8, 11,  8,  7, 10, 10,  9, 11, 11, 10, 12, 10,  9, 11, 12, 10,
    11,
};

static const uint8_t asf_codebook_4_codes[81] = {
    0x05, 0x06, 0x0a, 0x05, 0x07, 0x0a, 0x0b, 0x0b, 0x02, 0x08, 0x06, 0x0c, 0x07, 0x09, 0x0d, 0x0e,
    0x0f, 0x07, 0x0c, 0x0d, 0x03, 0x10, 0x11, 0x08, 0x04, 0x09, 0x00, 0x0a, 0x08, 0x12, 0x09, 0x0b,
    0x13, 0x0e, 0x14, 0x0a, 0x0c, 0x0d, 0x15, 0x0e, 0x0f, 0x10, 0x16, 0x11, 0x0f, 0x17, 0x18, 0x05,
    0x19, 0x12, 0x0b, 0x0c, 0x10, 0x0d, 0x11, 0x1a, 0x06, 0x1b, 0x1c, 0x07, 0x08, 0x0e, 0x01, 0x1d,
    0x1e, 0x09, 0x1f, 0x13, 0x0f, 0x10, 0x12, 0x0a, 0x0b, 0x11, 0x02, 0x12, 0x13, 0x0c, 0x03, 0x13,
    0x0d,
};

static const uint8_t asf_codebook_5_bits[81] = {
    14, 13, 12, 12, 11, 11, 12, 13, 14, 13, 12, 10,  9,  9,  9, 10,
    11, 13, 13, 10,  9,  8,  7,  7,  9, 10, 12, 12,  9,  8,  5,  4,
     5,  7,  9, 12, 12,  9,  7,  4,  1,  4,  7,  9, 12, 11,  9,  7,
     5,  4,  5,  8,  9, 12, 12, 10,  9,  7,  7,  8,  9, 10, 12, 13,
    11, 10,  9,  9, 10, 10, 12, 13, 14, 12, 12, 12, 11, 11, 12, 13,
    14,
};

static const uint8_t asf_codebook_5_codes[81] = {
    0x00, 0x02, 0x05, 0x06, 0x0b, 0x0c, 0x07, 0x03, 0x01, 0x04, 0x08, 0x09, 0x09, 0x0a, 0x0b, 0x0a,
    0x0d, 0x05, 0x06, 0x0b, 0x0c, 0x0c, 0x08, 0x09, 0x0d, 0x0c, 0x09, 0x0a, 0x0e, 0x0d, 0x04, 0x04,
    0x05, 0x0a, 0x0f, 0x0b, 0x0c, 0x10, 0x0b, 0x05, 0x01, 0x06, 0x0c, 0x11, 0x0d, 0x0e, 0x12, 0x0d,
    0x06, 0x07, 0x07, 0x0e, 0x13, 0x0e, 0x0f, 0x0d, 0x14, 0x0e, 0x0f, 0x0f, 0x15, 0x0e, 0x10, 0x07,
    0x0f, 0x0f, 0x16, 0x17, 0x10, 0x11, 0x11, 0x08, 0x02, 0x12, 0x13, 0x14, 0x10, 0x11, 0x15, 0x09,
    0x03,
};

static const uint8_t asf_codebook_6_bits[81] = {
    12, 11, 10, 10, 10, 10, 10, 11, 12, 11,  9,  8,  8,  8,  8,  8,
     9, 11, 10,  8,  6,  6,  6,  5,  6,  8, 10, 10,  8,  6,  4,  4,
     4,  5,  8, 10, 10,  8,  6,  4,  4,  4,  6,  8, 10, 10,  8,  5,
     4,  4,  4,  6,  8, 10, 10,  8,  6,  5,  6,  5,  6,  8, 11, 11,
     9,  8,  8,  8,  8,  8,  9, 11, 12, 11, 10, 10, 11, 10, 10, 11,
    12,
};

static const uint8_t asf_codebook_6_codes[81] = {
    0x00, 0x02, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x03, 0x01, 0x04, 0x0c, 0x08, 0x09, 0x0a, 0x0b, 0x0c,
    0x0d, 0x05, 0x0b, 0x0d, 0x07, 0x08, 0x09, 0x09, 0x0a, 0x0e, 0x0c, 0x0d, 0x0f, 0x0b, 0x07, 0x08,
    0x09, 0x0a, 0x10, 0x0e, 0x0f, 0x11, 0x0c, 0x0a, 0x0b, 0x0c, 0x0d, 0x12, 0x10, 0x11, 0x13, 0x0b,
    0x0d, 0x0e, 0x0f, 0x0e, 0x14, 0x12, 0x13, 0x15, 0x0f, 0x0c, 0x10, 0x0d, 0x11, 0x16, 0x06, 0x07,
    0x0e, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x0f, 0x08, 0x02, 0x09, 0x14, 0x15, 0x0a, 0x16, 0x17, 0x0b,
    0x03,
};

static const uint8_t asf_codebook_7_bits[64] = {
     1,  3,  6,  8,  9,  9, 10, 11,  3,  4,  6,  7,  8,  8,  9, 10,
     6,  5,  7,  8,  8,  9, 10, 11,  8,  7,  8,  8,  9,  9, 10, 11,
     9,  8,  8,  9, 10, 10, 10, 11,  9,  8,  9,  9, 10, 10, 11, 12,
    10,  9, 10, 10, 10, 11, 12, 12, 12, 10, 11, 11, 12, 12, 12, 12,
};

static const uint8_t asf_codebook_7_codes[64] = {
    0x01, 0x02, 0x07, 0x0b, 0x0a, 0x0b, 0x06, 0x04, 0x03, 0x03, 0x08, 0x0b, 0x0c, 0x0d, 0x0c, 0x07,
    0x09, 0x05, 0x0c, 0x0e, 0x0f, 0x0d, 0x08, 0x05, 0x10, 0x0d, 0x11, 0x12, 0x0e, 0x0f, 0x09, 0x06,
    0x10, 0x13, 0x14, 0x11, 0x0a, 0x0b, 0x0c, 0x07, 0x12, 0x15, 0x13, 0x14, 0x0d, 0x0e, 0x08, 0x00,
    0x0f, 0x15, 0x10, 0x11, 0x12, 0x09, 0x01, 0x02, 0x03, 0x13, 0x0a, 0x0b, 0x04, 0x05, 0x06, 0x07,
};

static const uint8_t asf_codebook_8_bits[64] = {
     4,  4,  5,  6,  7,  8,  9, 10,  4,  3,  4,  5,  6,  7,  8,  9,
     5,  4,  4,  5,  6,  7,  8,  9,  6,  5,  5,  5,  6,  7,  8,  9,
     7,  6,  6,  6,  7,  7,  9, 10,  8,  7,  7,  7,  7,  8,  9, 10,
     9,  8,  8,  8,  8,  9,  9, 10, 11,  9,  9,  9, 10, 10, 10, 11,
};

static const uint8_t asf_codebook_8_codes[64] = {
    0x08, 0x09, 0x09, 0x0a, 0x09, 0x08, 0x04, 0x01, 0x0a, 0x07, 0x0b, 0x0a, 0x0b, 0x0a, 0x09, 0x05,
    0x0b, 0x0c, 0x0d, 0x0c, 0x0c, 0x0b, 0x0a, 0x06, 0x0d, 0x0d, 0x0e, 0x0f, 0x0e, 0x0c, 0x0b, 0x07,
    0x0d, 0x0f, 0x10, 0x11, 0x0e, 0x0f, 0x08, 0x02, 0x0c, 0x10, 0x11, 0x12, 0x13, 0x0d, 0x09, 0x03,
    0x0a, 0x0e, 0x0f, 0x10, 0x11, 0x0b, 0x0c, 0x04, 0x00, 0x0d, 0x0e, 0x0f, 0x05, 0x06, 0x07, 0x01,
};

static const uint8_t asf_codebook_9_bits[169] = {
     1,  3,  6,  8,  9, 10, 10, 11, 11, 12, 12, 12, 13,  3,  4,  6,
     7,  8,  9,  9, 10, 10, 11, 11, 11, 12,  6,  6,  7,  8,  9,  9,
    10, 10, 10, 11, 11, 12, 12,  8,  7,  8,  9,  9, 10, 10, 11, 11,
    11, 12, 12, 12,  9,  8,  9,  9, 10, 10, 11, 11, 11, 12, 12, 12,
    13, 10,  9,  9, 10, 10, 10, 11, 11, 11, 12, 12, 12, 13, 10,  9,
    10, 10, 11, 11, 11, 12, 12, 12, 12, 13, 13, 11, 10, 10, 11, 11,
    12, 12, 12, 12, 12, 13, 13, 13, 11, 10, 10, 11, 11, 11, 12, 12,
    12, 13, 13, 13, 14, 12, 11, 11, 11, 11, 12, 12, 12, 13, 13, 13,
    14, 14, 12, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 12,
    11, 11, 12, 12, 12, 13, 13, 13, 13, 13, 14, 14, 13, 12, 12, 12,
    13, 13, 13, 13, 14, 14, 14, 14, 14,
};

static const uint8_t asf_codebook_9_codes[169] = {
    0x01, 0x02, 0x08, 0x14, 0x1b, 0x20, 0x21, 0x1e, 0x1f, 0x11, 0x12, 0x13, 0x06, 0x03, 0x03, 0x09,
    0x0d, 0x15, 0x1c, 0x1d, 0x22, 0x23, 0x20, 0x21, 0x22, 0x14, 0x0a, 0x0b, 0x0e, 0x16, 0x1e, 0x1f,
    0x24, 0x25, 0x26, 0x23, 0x24, 0x15, 0x16, 0x17, 0x0f, 0x18, 0x20, 0x21, 0x27, 0x28, 0x25, 0x26,
    0x27, 0x17, 0x18, 0x19, 0x22, 0x19, 0x23, 0x24, 0x29, 0x2a, 0x28, 0x29, 0x2a, 0x1a, 0x1b, 0x1c,
    0x07, 0x2b, 0x25, 0x26, 0x2c, 0x2d, 0x2e, 0x2b, 0x2c, 0x2d, 0x1d, 0x1e, 0x1f, 0x08, 0x2f, 0x27,
    0x30, 0x31, 0x2e, 0x2f, 0x30, 0x20, 0x21, 0x22, 0x23, 0x09, 0x0a, 0x31, 0x32, 0x33, 0x32, 0x33,
    0x24, 0x25, 0x26, 0x27, 0x28, 0x0b, 0x0c, 0x0d, 0x34, 0x34, 0x35, 0x35, 0x36, 0x37, 0x29, 0x2a,
    0x2b, 0x0e, 0x0f, 0x10, 0x00, 0x2c, 0x38, 0x39, 0x3a, 0x3b, 0x2d, 0x2e, 0x2f, 0x11, 0x12, 0x13,
    0x01, 0x02, 0x30, 0x3c, 0x3d, 0x31, 0x32, 0x33, 0x34, 0x14, 0x15, 0x16, 0x17, 0x03, 0x04, 0x35,
    0x3e, 0x3f, 0x36, 0x37, 0x38, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x05, 0x06, 0x1d, 0x39, 0x3a, 0x3b,
    0x1e, 0x1f, 0x20, 0x21, 0x07, 0x08, 0x09, 0x0a, 0x0b,
};

static const uint8_t asf_codebook_10_bits[169] = {
     6,  5,  6,  6,  7,  8,  9, 10, 10, 11, 11, 12, 12,  5,  4,  4,
     5,  6,  7,  7,  8,  9, 10, 10, 10, 11,  6,  4,  4,  5,  6,  6,
     7,  8,  9,  9, 10, 10, 11,  6,  5,  5,  5,  6,  7,  7,  8,  8,
     9, 10, 10, 11,  7,  6,  6,  6,  6,  7,  7,  8,  9,  9, 10, 10,
    11,  8,  7,  6,  7,  7,  7,  8,  8,  9,  9, 10, 10, 11,  9,  7,
     7,  7,  7,  8,  8,  9,  9, 10, 10, 10, 12, 10,  8,  8,  8,  8,
     8,  9,  9,  9, 10, 10, 11, 12, 10,  8,  8,  8,  8,  9,  9,  9,
    10, 10, 10, 11, 12, 11,  9,  9,  9,  9,  9, 10, 10, 10, 10, 11,
    11, 13, 11, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 13, 12,
    10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 12, 12, 12, 11, 11, 11,
    11, 11, 11, 11, 12, 12, 13, 12, 13,
};

static const uint8_t asf_codebook_10_codes[169] = {
    0x14, 0x11, 0x15, 0x16, 0x17, 0x1a, 0x1d, 0x11, 0x12, 0x07, 0x08, 0x02, 0x03, 0x12, 0x0c, 0x0d,
    0x13, 0x17, 0x18, 0x19, 0x1b, 0x1e, 0x13, 0x14, 0x15, 0x09, 0x18, 0x0e, 0x0f, 0x14, 0x19, 0x1a,
    0x1a, 0x1c, 0x1f, 0x20, 0x16, 0x17, 0x0a, 0x1b, 0x15, 0x16, 0x17, 0x1c, 0x1b, 0x1c, 0x1d, 0x1e,
    0x21, 0x18, 0x19, 0x0b, 0x1d, 0x1d, 0x1e, 0x1f, 0x20, 0x1e, 0x1f, 0x1f, 0x22, 0x23, 0x1a, 0x1b,
    0x0c, 0x20, 0x20, 0x21, 0x21, 0x22, 0x23, 0x21, 0x22, 0x24, 0x25, 0x1c, 0x1d, 0x0d, 0x26, 0x24,
    0x25, 0x26, 0x27, 0x23, 0x24, 0x27, 0x28, 0x1e, 0x1f, 0x20, 0x04, 0x21, 0x25, 0x26, 0x27, 0x28,
    0x29, 0x29, 0x2a, 0x2b, 0x22, 0x23, 0x0e, 0x05, 0x24, 0x2a, 0x2b, 0x2c, 0x2d, 0x2c, 0x2d, 0x2e,
    0x25, 0x26, 0x27, 0x0f, 0x06, 0x10, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x28, 0x29, 0x2a, 0x2b, 0x11,
    0x12, 0x00, 0x13, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x14, 0x15, 0x16, 0x17, 0x01, 0x07,
    0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x18, 0x19, 0x1a, 0x08, 0x09, 0x0a, 0x1b, 0x1c, 0x1d,
    0x1e, 0x1f, 0x20, 0x21, 0x0b, 0x0c, 0x02, 0x0d, 0x03,
};

static const uint8_t asf_codebook_11_bits[289] = {
     3,  4,  6,  7,  8,  9,  9, 10, 10, 11, 11, 11, 12, 12, 12, 12,
    10,  4,  4,  5,  6,  7,  8,  8,  9,  9,  9,  9, 10, 10, 10, 11,
    11,  9,  6,  5,  6,  6,  7,  7,  8,  8,  9,  9,  9,  9, 10, 10,
    10, 11,  8,  7,  6,  6,  7,  7,  7,  8,  8,  9,  9,  9,  9, 10,
    10, 10, 11,  8,  8,  7,  7,  7,  7,  8,  8,  9,  9,  9,  9, 10,
    10, 10, 10, 11,  8,  9,  7,  7,  7,  8,  8,  8,  9,  9,  9, 10,
    10, 10, 10, 11, 11,  8,  9,  8,  8,  8,  8,  8,  9,  9,  9, 10,
    10, 10, 10, 10, 11, 11,  8, 10,  9,  8,  8,  8,  9,  9,  9,  9,
    10, 10, 10, 11, 11, 11, 11,  9, 10,  9,  9,  9,  9,  9,  9,  9,
    10, 10, 10, 10, 11, 11, 11, 11,  9, 11,  9,  9,  9,  9,  9, 10,
    10, 10, 10, 10, 10, 11, 11, 11, 12,  9, 11,  9,  9,  9,  9, 10,
    10, 10, 10, 10, 10, 11, 11, 11, 11, 12,  9, 11, 10,  9,  9,  9,
    10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12,  9, 12, 10, 10, 10,
    10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 12, 12,  9, 11, 10, 10,
    10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12,  9, 12, 11,
    10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12,  9, 12,
    11, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12,  9,
    10,  8,  8,  8,  8,  8,  8,  8,  9,  9,  9,  9,  9,  9,  9,  9,
     5,
};

static const uint8_t asf_codebook_11_codes[289] = {
    0x07, 0x0b, 0x1f, 0x2f, 0x3d, 0x36, 0x37, 0x26, 0x27, 0x0d, 0x0e, 0x0f, 0x00, 0x01, 0x02, 0x03,
    0x28, 0x0c, 0x0d, 0x13, 0x20, 0x30, 0x3e, 0x3f, 0x38, 0x39, 0x3a, 0x3b, 0x29, 0x2a, 0x2b, 0x10,
    0x11, 0x3c, 0x21, 0x14, 0x22, 0x23, 0x31, 0x32, 0x40, 0x41, 0x3d, 0x3e, 0x3f, 0x40, 0x2c, 0x2d,
    0x2e, 0x12, 0x42, 0x33, 0x24, 0x25, 0x34, 0x35, 0x36, 0x43, 0x44, 0x41, 0x42, 0x43, 0x44, 0x2f,
    0x30, 0x31, 0x13, 0x45, 0x46, 0x37, 0x38, 0x39, 0x3a, 0x47, 0x48, 0x45, 0x46, 0x47, 0x48, 0x32,
    0x33, 0x34, 0x35, 0x14, 0x49, 0x49, 0x3b, 0x3c, 0x3d, 0x4a, 0x4b, 0x4c, 0x4a, 0x4b, 0x4c, 0x36,
    0x37, 0x38, 0x39, 0x15, 0x16, 0x4d, 0x4d, 0x4e, 0x4f, 0x50, 0x51, 0x52, 0x4e, 0x4f, 0x50, 0x3a,
    0x3b, 0x3c, 0x3d, 0x3e, 0x17, 0x18, 0x53, 0x3f, 0x51, 0x54, 0x55, 0x56, 0x52, 0x53, 0x54, 0x55,
    0x40, 0x41, 0x42, 0x19, 0x1a, 0x1b, 0x1c, 0x56, 0x43, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d,
    0x44, 0x45, 0x46, 0x47, 0x1d, 0x1e, 0x1f, 0x20, 0x5e, 0x21, 0x5f, 0x60, 0x61, 0x62, 0x63, 0x48,
    0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x22, 0x23, 0x24, 0x04, 0x64, 0x25, 0x65, 0x66, 0x67, 0x68, 0x4e,
    0x4f, 0x50, 0x51, 0x52, 0x53, 0x26, 0x27, 0x28, 0x29, 0x05, 0x69, 0x2a, 0x54, 0x6a, 0x6b, 0x6c,
    0x55, 0x56, 0x57, 0x58, 0x59, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x06, 0x6d, 0x07, 0x5a, 0x5b, 0x5c,
    0x5d, 0x5e, 0x5f, 0x60, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x08, 0x09, 0x6e, 0x36, 0x61, 0x62,
    0x63, 0x64, 0x65, 0x66, 0x67, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x0a, 0x0b, 0x0c, 0x6f, 0x0d, 0x3c,
    0x68, 0x69, 0x6a, 0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x0e, 0x0f, 0x10, 0x11, 0x70, 0x12,
    0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x71,
    0x6b, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79,
    0x15,
};

static const uint16_t sfb_offset_48khz_2048[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40,
    44, 52, 60, 68, 76, 84, 92, 100, 108, 116,
    124, 136, 148, 160, 172, 188, 204, 220, 240,
    260, 284, 308, 336, 364, 396, 432, 468, 508,
    552, 600, 652, 704, 768, 832, 896, 960, 1024,
    1088, 1152, 1216, 1280, 1344, 1408, 1472, 1536,
    1600, 1664, 1728, 1792, 1856, 1920, 1984, 2048,
    2176, 2304, 2432, 2560, 2688, 2816, 2944, 3072,
    3200, 3328, 3456, 3584, 3712, 3840, 3968, 4096,
    4224, 4352, 4480, 4608, 4736, 4864, 4992, 5120,
    5248, 5376, 5504, 5632, 5760, 5888, 6016, 6144,
    6272, 6400, 6528, 6656, 6784, 6912, 7040, 7168,
    7296, 7424, 7552, 7680, 7808, 7936, 8064, 8192,
};

static const uint16_t sfb_offset_48khz_1920[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 52, 60, 68,
    76, 84, 92, 100, 108, 116, 124, 136, 148, 160, 172, 188,
    204, 220, 240, 260, 284, 308, 336, 364, 396, 432, 468,
    508, 552, 600, 652, 704, 768, 832, 896, 960, 1024, 1088,
    1152, 1216, 1280, 1344, 1408, 1472, 1536, 1600, 1664, 1728,
    1792, 1856, 1920, 2048, 2176, 2304, 2432, 2560, 2688, 2816,
    2944, 3072, 3200, 3328, 3456, 3584, 3712, 3840, 3968, 4096,
    4224, 4352, 4480, 4608, 4736, 4864, 4992, 5120, 5248, 5376,
    5504, 5632, 5760, 5888, 6016, 6144, 6272, 6400, 6528, 6656,
    6784, 6912, 7040, 7168, 7296, 7424, 7552, 7680,
};

static const uint16_t sfb_offset_48khz_1536[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40,
    44, 52, 60, 68, 76, 84, 92, 100, 108, 116,
    124, 136, 148, 160, 172, 188, 204, 220, 240,
    260, 284, 308, 336, 364, 396, 432, 468, 508,
    552, 600, 652, 704, 768, 832, 896, 960, 1024,
    1088, 1152, 1216, 1280, 1344, 1408, 1472, 1536,
    1664, 1792, 1920, 2048, 2176, 2304, 2432, 2560,
    2688, 2816, 2944, 3072, 3200, 3328, 3456, 3584,
    3712, 3840, 3968, 4096, 4224, 4352, 4480, 4608,
    4736, 4864, 4992, 5120, 5248, 5376, 5504, 5632,
    5760, 5888, 6016, 6144,
};

static const uint16_t sfb_offset_48khz_1024[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 48,
    56, 64, 72, 80, 88, 96, 108, 120, 132, 144,
    160, 176, 196, 216, 240, 264, 292, 320, 352,
    384, 416, 448, 480, 512, 544, 576, 608, 640,
    672, 704, 736, 768, 800, 832, 864, 896, 928,
    1024, 1152, 1280, 1408, 1536, 1664, 1792, 1920,
    2048, 2176, 2304, 2432, 2560, 2688, 2816, 2944,
    3072, 3200, 3328, 3456, 3584, 3712, 3840, 3968,
    4096,
};

static const uint16_t sfb_offset_48khz_960[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 48, 56, 64, 72,
    80, 88, 96, 108, 120, 132, 144, 160, 176, 196, 216, 240,
    264, 292, 320, 352, 384, 416, 448, 480, 512, 544,
    576, 608, 640, 672, 704, 736, 768, 800, 832, 864, 896,
    928, 960, 1024, 1152, 1280, 1408, 1536, 1664, 1792, 1920,
    2048, 2176, 2304, 2432, 2560, 2688, 2816, 2944, 3072,
    3200, 3328, 3456, 3584, 3712, 3840,
};

static const uint16_t sfb_offset_48khz_768[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 48,
    56, 64, 72, 80, 88, 96, 108, 120, 132, 144,
    160, 176, 196, 216, 240, 264, 292, 320, 352,
    384, 416, 448, 480, 512, 544, 576, 608, 640,
    672, 704, 736, 768, 896, 1024, 1152, 1280, 1408,
    1536, 1664, 1792, 1920, 2048, 2176, 2304, 2432,
    2560, 2688, 2816, 2944, 3072,
};

static const uint16_t sfb_offset_48khz_512[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52,
    56, 60, 68, 76, 84, 92, 100, 112, 124, 136, 148, 164,
    184, 208, 236, 268, 300, 332, 364, 396, 428, 460, 512,
    576, 640, 704, 768, 832, 896, 960, 1024, 1088, 1152,
    1216, 1280, 1344, 1408, 1472, 1536, 1600, 1664, 1728,
    1792, 1856, 1920, 1984, 2048,
};

static const uint16_t sfb_offset_48khz_480[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56,
    60, 68, 76, 84, 92, 100, 112, 124, 136, 148, 164, 184,
    208, 236, 268, 300, 332, 364, 396, 428, 460, 480, 512,
    576, 640, 704, 768, 832, 896, 960, 1024, 1088, 1152,
    1216, 1280, 1344, 1408, 1472, 1536, 1600, 1664, 1728,
    1792, 1856, 1920,
};

static const uint16_t sfb_offset_48khz_384[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52,
    56, 60, 68, 76, 84, 92, 100, 112, 124, 136, 148, 164,
    184, 208, 236, 268, 300, 332, 364, 384, 448, 512, 576,
    640, 704, 768, 832, 896, 960, 1024, 1088, 1152,
    1216, 1280, 1344, 1408, 1472, 1536,
};

static const uint16_t sfb_offset_48khz_256[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 36, 44, 52, 64, 76,
    92, 108, 128, 148, 172, 196, 224, 256, 288, 320,
    352, 384, 416, 448, 480, 512, 576, 640, 704, 768,
    832, 896, 960, 1024,
};

static const uint16_t sfb_offset_48khz_240[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 36, 44, 52, 64, 76, 92, 108,
    128, 148, 172, 196, 224, 240, 256, 288, 320, 352, 384, 416,
    448, 480, 512, 576, 640, 704, 768, 832, 896, 960,
};

static const uint16_t sfb_offset_48khz_192[] = {
    0, 4, 8, 12, 16, 20, 24, 28, 36, 44, 52, 64, 76,
    92, 108, 128, 148, 172, 192, 224, 256, 288, 320,
    352, 384, 448, 512, 576, 640, 704, 768,
};

static const uint16_t sfb_offset_48khz_128[] = {
    0, 4, 8, 12, 16, 20, 28, 36, 44, 56, 68, 80, 96, 112,
    128, 144, 160, 176, 192, 208, 224, 240, 256, 288, 320,
    352, 384, 416, 448, 480, 512,
};

static const uint16_t sfb_offset_48khz_120[] = {
    0, 4, 8, 12, 16, 20, 28, 36, 44, 56, 68, 80, 96, 112,
    120, 128, 144, 160, 176, 192, 208, 224, 240, 256, 288,
    320, 352, 384, 416, 448, 480,
};

static const uint16_t sfb_offset_48khz_96[] = {
    0, 4, 8, 12, 16, 20, 28, 36, 44, 56, 68, 80, 96, 112,
    128, 144, 160, 176, 192, 224, 256, 288, 320, 352, 384,
};

static const uint8_t snf_bits[22] = {
    4, 7, 8, 8, 7, 6, 6, 6, 6, 5, 5, 4, 4, 3, 3, 3, 3, 4, 4, 6, 7, 6,
};

static const uint8_t snf_codes[22] = {
    0x03, 0x01, 0x00, 0x01, 0x02, 0x02, 0x03, 0x04,
    0x05, 0x04, 0x05, 0x04, 0x05, 0x04, 0x05, 0x06,
    0x07, 0x06, 0x07, 0x06, 0x03, 0x07,
};

static const uint8_t aspx_int_class_bits[4] = {
    1, 2, 3, 3,
};

static const uint8_t aspx_int_class_codes[4] = {
    0, 2, 6, 7,
};

static const uint8_t sbg_template_lowres[] = {
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
    22, 24, 26, 28, 30, 32, 35, 38, 42, 46,
};

static const uint8_t sbg_template_highres[] = {
    18, 19, 20, 21, 22, 23, 24, 26, 28, 30, 32, 34,
    36, 38, 40, 42, 44, 47, 50, 53, 56, 59, 62,
};

static const uint8_t tab_border[5][3][5] = {
    {
        { 0, 6, 0, 0, 0, },
        { 0, 3, 6, 0, 0, },
        { 0, 2, 3, 4, 6, },
    },
    {
        { 0, 8, 0, 0, 0, },
        { 0, 4, 8, 0, 0, },
        { 0, 2, 4, 6, 8, },
    },
    {
        { 0,12, 0, 0, 0, },
        { 0, 6,12, 0, 0, },
        { 0, 3, 6, 9,12, },
    },
    {
        { 0,15, 0, 0, 0, },
        { 0, 8,15, 0, 0, },
        { 0, 4, 8,12,15, },
    },
    {
        { 0,16, 0, 0, 0, },
        { 0, 8,16, 0, 0, },
        { 0, 4, 8,12,16, },
    },
};

static const uint8_t qmf_subbands[][4] = {
    { 0, 0, 0, 0 },
    { 1, 1, 1, 1 },
    { 2, 2, 2, 2 },
    { 3, 3, 3, 2 },
    { 4, 4, 3, 3 },
    { 5, 4, 4, 3 },
    { 6, 5, 4, 3 },
    { 7, 5, 5, 3 },
    { 8, 6, 5, 4 },
    { 9, 6, 6, 4 },
    {10, 7, 6, 4 },
    {11, 8, 7, 5 },
    {12, 9, 7, 5 },
    {13,10, 8, 6 },
    {14,11, 8, 6 },
};

static const uint8_t acpl_num_param_bands[] = {
    15, 12, 9, 7,
};

static const uint8_t acpl_hcb_alpha_coarse_f0_bits[17] = {
    10, 10,  9,  8,  6,  6,  5,  2,  1,  3,  5,  7,  7,  8,  9, 10,
    10,
};

static const uint16_t acpl_hcb_alpha_coarse_f0_codes[17] = {
    0x0003be, 0x0003fe, 0x0001fe, 0x0000fe, 0x00003e, 0x00003a,
    0x00001e, 0x000002, 0x000000, 0x000006, 0x00001c, 0x00007e,
    0x000076, 0x0000ee, 0x0001de, 0x0003ff, 0x0003bf,
};

static const uint8_t acpl_hcb_alpha_fine_f0_bits[33] = {
    10, 12, 11, 11, 10, 10,  9,  8,  7,  7,  8,  7,  6,  6,  4,  3,
     1,  3,  4,  6,  6,  7,  8,  8,  9,  9, 10, 10, 10, 10, 11, 12,
    10,
};

static const uint16_t acpl_hcb_alpha_fine_f0_codes[33] = {
    0x0002ce, 0x000b5e, 0x0004fe, 0x0005ae, 0x00027e, 0x0002de,
    0x00016a, 0x0000b2, 0x00004a, 0x00004b, 0x0000b6, 0x00004e,
    0x000024, 0x00002e, 0x00000a, 0x000006, 0x000000, 0x000007,
    0x000008, 0x00002f, 0x000026, 0x000058, 0x0000b4, 0x00009e,
    0x00016e, 0x000166, 0x0002df, 0x0002cf, 0x00027c, 0x00027d,
    0x0004ff, 0x000b5f, 0x0002d6,
};

static const uint8_t acpl_hcb_alpha_coarse_df_bits[33] = {
    15, 18, 17, 17, 16, 15, 15, 13, 12, 11, 10,  9,  8,  7,  4,  3,
     1,  2,  5,  7,  8,  9, 10, 11, 12, 13, 15, 16, 16, 17, 16, 18,
    15,
};

static const uint32_t acpl_hcb_alpha_coarse_df_codes[33] = {
    0x007c76, 0x03e3fe, 0x01f1f6, 0x01f1f7, 0x00f8ea, 0x007c74, 0x007c7c,
    0x001f1c, 0x000f9e, 0x0007ce, 0x0003e2, 0x0001f0, 0x0000fa, 0x00007e,
    0x00000e, 0x000006, 0x000000, 0x000002, 0x00001e, 0x00007f, 0x0000fb,
    0x0001f2, 0x0003e6, 0x0007c6, 0x000f9f, 0x001f1e, 0x007c7e, 0x00f8fe,
    0x00f8fa, 0x01f1fe, 0x00f8eb, 0x03e3ff, 0x007c77,
};

static const uint8_t acpl_hcb_alpha_fine_df_bits[65] = {
    13, 17, 17, 17, 16, 17, 17, 17, 17, 16, 16, 16, 15, 15, 14, 13,
    13, 12, 12, 11, 11, 11, 10, 10, 10,  9,  8,  7,  7,  5,  4,  3,
     1,  3,  4,  5,  6,  7,  8,  9,  9, 10, 10, 11, 11, 12, 12, 12,
    13, 13, 14, 15, 15, 16, 16, 17, 16, 16, 17, 16, 16, 17, 17, 17,
    13,
};

static const uint32_t acpl_hcb_alpha_fine_df_codes[65] = {
    0x0011de, 0x011ffe, 0x013dea, 0x013df6, 0x008eea, 0x013df7, 0x013dee,
    0x013deb, 0x013dec, 0x008eee, 0x008ffe, 0x009efe, 0x0047fe, 0x004f7c,
    0x0023fe, 0x0011fe, 0x0013fe, 0x0008f6, 0x0009ee, 0x000476, 0x00047a,
    0x0004f6, 0x00023a, 0x00027a, 0x00027e, 0x00013e, 0x00009a, 0x00004c,
    0x00004e, 0x000012, 0x00000a, 0x000006, 0x000000, 0x000007, 0x00000b,
    0x000010, 0x000022, 0x000046, 0x00009b, 0x00013c, 0x00011c, 0x00023e,
    0x00023c, 0x0004fe, 0x00047e, 0x0009fe, 0x0008fe, 0x0008f7, 0x0013ff,
    0x0011df, 0x0027bc, 0x004f7e, 0x004776, 0x009efa, 0x009ef4, 0x013dfe,
    0x008eeb, 0x008ee8, 0x013dff, 0x008ee9, 0x008eef, 0x011fff, 0x013ded,
    0x013def, 0x0011dc,
};

static const uint8_t acpl_hcb_alpha_coarse_dt_bits[33] = {
    14, 16, 15, 16, 15, 15, 14, 13, 12, 12, 10,  9,  8,  7,  5,  3,
     1,  2,  4,  7,  8,  9, 10, 11, 12, 13, 14, 15, 15, 16, 15, 16,
    14,
};

static const uint32_t acpl_hcb_alpha_coarse_dt_codes[33] = {
    0x003efc, 0x00fbfa, 0x007ddc, 0x00fbfe, 0x007dde, 0x007dfc, 0x003ef6,
    0x001f76, 0x000fba, 0x000fbe, 0x0003ec, 0x0001f2, 0x0000f8, 0x00007e,
    0x00001e, 0x000006, 0x000000, 0x000002, 0x00000e, 0x00007f, 0x0000fa,
    0x0001f3, 0x0003ed, 0x0007dc, 0x000fbc, 0x001f7a, 0x003ef7, 0x007dfe,
    0x007ddf, 0x00fbff, 0x007ddd, 0x00fbfb, 0x003efd,
};

static const uint8_t acpl_hcb_alpha_fine_dt_bits[65] = {
    16, 18, 18, 18, 17, 17, 17, 18, 17, 17, 17, 16, 16, 16, 15, 15,
    14, 14, 13, 13, 13, 12, 11, 11, 10, 10,  9,  9,  7,  6,  5,  3,
     1,  2,  5,  6,  7,  9,  9, 10, 10, 11, 11, 12, 12, 13, 13, 14,
    14, 15, 15, 16, 16, 16, 17, 17, 17, 17, 17, 18, 17, 18, 18, 18,
    16,
};

static const uint32_t acpl_hcb_alpha_fine_dt_codes[65] = {
    0x00eeee, 0x03b3ee, 0x03b3f6, 0x03b3fc, 0x01d9bc, 0x01d9bd, 0x01d9b2,
    0x03b3fe, 0x01d9be, 0x01d9f6, 0x01d9fc, 0x00ecda, 0x00ecfa, 0x00eeef,
    0x00766e, 0x007776, 0x003b3a, 0x003bba, 0x001d9a, 0x001ddc, 0x001dde,
    0x000eec, 0x000764, 0x000772, 0x0003b0, 0x0003b8, 0x0001da, 0x0001de,
    0x000072, 0x000038, 0x00001e, 0x000006, 0x000000, 0x000002, 0x00001f,
    0x00003a, 0x000073, 0x0001df, 0x0001db, 0x0003ba, 0x0003b1, 0x000773,
    0x000765, 0x000eed, 0x000ecc, 0x001d9e, 0x001d9c, 0x003bbe, 0x003b3b,
    0x00777e, 0x00767c, 0x00eefe, 0x00ecfc, 0x00ecd8, 0x01d9fd, 0x01d9fa,
    0x01d9bf, 0x01d9b6, 0x01d9b3, 0x03b3fd, 0x01d9b7, 0x03b3ff, 0x03b3ef,
    0x03b3f7, 0x00eeff,
};

static const uint8_t acpl_hcb_beta_coarse_f0_bits[5] = {
     1,  2,  3,  4,  4,
};

static const uint8_t acpl_hcb_beta_coarse_f0_codes[5] = {
    0x000000, 0x000002, 0x000006, 0x00000e, 0x00000f,
};

static const uint8_t acpl_hcb_beta_fine_f0_bits[9] = {
     1,  2,  3,  4,  5,  6,  7,  8,  8,
};

static const uint8_t acpl_hcb_beta_fine_f0_codes[9] = {
    0x000000, 0x000002, 0x000006, 0x00000e, 0x00001e, 0x00003e, 0x00007e, 0x0000fe, 0x0000ff,
};

static const uint8_t acpl_hcb_beta_coarse_df_bits[9] = {
     8,  6,  4,  3,  1,  2,  5,  7,  8,
};

static const uint8_t acpl_hcb_beta_coarse_df_codes[9] = {
    0x0000fe, 0x00003e, 0x00000e, 0x000006, 0x000000, 0x000002, 0x00001e, 0x00007e, 0x0000ff,
};

static const uint8_t acpl_hcb_beta_fine_df_bits[17] = {
    13, 12, 10,  9,  8,  7,  5,  3,  1,  2,  4,  7,  8,  9,  9, 11,
    13,
};

static const uint32_t acpl_hcb_beta_fine_df_codes[17] = {
    0x001f1e, 0x000f8e, 0x0003e2, 0x0001f2, 0x0000fa, 0x00007e,
    0x00001e, 0x000006, 0x000000, 0x000002, 0x00000e, 0x00007f,
    0x0000fb, 0x0001f3, 0x0001f0, 0x0007c6, 0x001f1f,
};

static const uint8_t acpl_hcb_beta_coarse_dt_bits[9] = {
     8,  7,  5,  3,  1,  2,  4,  6,  8,
};

static const uint8_t acpl_hcb_beta_coarse_dt_codes[9] = {
    0x0000fe, 0x00007e, 0x00001e, 0x000006, 0x000000, 0x000002, 0x00000e, 0x00003e, 0x0000ff,
};

static const uint8_t acpl_hcb_beta_fine_dt_bits[17] = {
    15, 14, 12, 10,  8,  7,  5,  3,  1,  2,  4,  7,  7,  9, 11, 13,
    15,
};

static const uint32_t acpl_hcb_beta_fine_dt_codes[17] = {
    0x007dfe, 0x003efe, 0x000fbe, 0x0003ee, 0x0000fa,
    0x00007e, 0x00001e, 0x000006, 0x000000, 0x000002,
    0x00000e, 0x00007f, 0x00007c, 0x0001f6, 0x0007de,
    0x001f7e, 0x007dff,
};

static const uint8_t acpl_hcb_beta3_coarse_f0_bits[9] = {
     5,  3,  3,  2,  2,  3,  4,  6,  6,
};

static const uint8_t acpl_hcb_beta3_coarse_f0_codes[9] = {
    0x000001, 0x000006, 0x000007, 0x000001, 0x000002, 0x000001, 0x000001, 0x000001, 0x000000,
};

static const uint8_t acpl_hcb_beta3_fine_f0_bits[17] = {
     7,  5,  4,  4,  4,  3,  3,  3,  3,  3,  4,  5,  6,  6,  7,  7,
     7,
};

static const uint8_t acpl_hcb_beta3_fine_f0_codes[17] = {
    0x00000d, 0x000002, 0x000000, 0x00000c, 0x00000e, 0x000001, 0x000003,
    0x000005, 0x000004, 0x000002, 0x00000d, 0x00001f, 0x00003d, 0x000007,
    0x000078, 0x00000c, 0x000079,
};

static const uint8_t acpl_hcb_beta3_coarse_df_bits[17] = {
    13, 12, 12, 11,  9,  6,  4,  2,  1,  3,  5,  7,  9, 11, 12, 13,
     9,
};

static const uint32_t acpl_hcb_beta3_coarse_df_codes[17] = {
    0x000a93, 0x000548, 0x00054b, 0x0002a7, 0x0000ab, 0x000014,
    0x000004, 0x000000, 0x000001, 0x000003, 0x00000b, 0x00002b,
    0x0000aa, 0x0002a6, 0x00054a, 0x000a92, 0x0000a8,
};

static const uint8_t acpl_hcb_beta3_fine_df_bits[33] = {
    14, 15, 14, 13, 13, 12, 11, 11,  9,  8,  7,  6,  5,  4,  3,  2,
     2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 12, 13, 14, 14, 14,
    15,
};

static const uint32_t acpl_hcb_beta3_fine_df_codes[33] = {
    0x0019e9, 0x0033f7, 0x0019f3, 0x000cf5, 0x000cfc, 0x00067d, 0x00033c,
    0x0007ff, 0x0000ce, 0x000066, 0x000032, 0x000018, 0x00000d, 0x000007,
    0x000002, 0x000000, 0x000002, 0x000006, 0x00000e, 0x00001e, 0x00003e,
    0x00007e, 0x0000fe, 0x0001fe, 0x0003fe, 0x0007fe, 0x00067f, 0x00067b,
    0x000cf8, 0x0019fa, 0x0019f2, 0x0019e8, 0x0033f6,
};

static const uint8_t acpl_hcb_beta3_coarse_dt_bits[17] = {
    15, 15, 14, 12, 10,  7,  5,  3,  1,  2,  4,  6,  8, 11, 14, 14,
     9,
};

static const uint16_t acpl_hcb_beta3_coarse_dt_codes[17] = {
    0x000adc, 0x000add, 0x00056c, 0x00015a, 0x000057, 0x00000b, 0x000003,
    0x000001, 0x000001, 0x000001, 0x000000, 0x000004, 0x000014, 0x0000ac,
    0x00056f, 0x00056d, 0x00002a,
};

static const uint8_t acpl_hcb_beta3_fine_dt_bits[33] = {
    16, 16, 16, 16, 16, 16, 15, 14, 12, 11, 10,  9,  8,  7,  5,  3,
     1,  2,  4,  7,  8,  9, 10, 11, 12, 13, 14, 15, 15, 16, 16, 16,
    16,
};

static const uint32_t acpl_hcb_beta3_fine_dt_codes[33] = {
    0x00501e, 0x00501d, 0x00501c, 0x00501b, 0x00510e, 0x00510d, 0x002809,
    0x001442, 0x000500, 0x000281, 0x000141, 0x0000a1, 0x000052, 0x00002a,
    0x00000b, 0x000003, 0x000001, 0x000000, 0x000004, 0x00002b, 0x000053,
    0x0000a3, 0x000145, 0x000289, 0x000511, 0x000a20, 0x001405, 0x00280c,
    0x002808, 0x00510f, 0x00510c, 0x00501f, 0x00501a,
};

static const uint8_t acpl_hcb_gamma_coarse_f0_bits[21] = {
    13, 13, 13, 13, 11,  9,  7,  6,  5,  3,  2,  3,  3,  4,  3,  3,
     8, 11, 12, 13, 13,
};

static const uint16_t acpl_hcb_gamma_coarse_f0_codes[21] = {
    0x000af4, 0x000af8, 0x000af9, 0x000afb, 0x0002bc, 0x0000ae, 0x00002a, 0x000014,
    0x00000b, 0x000001, 0x000003, 0x000005, 0x000000, 0x000004, 0x000004, 0x000003,
    0x000056, 0x0002bf, 0x00057b, 0x000af5, 0x000afa,
};

static const uint8_t acpl_hcb_gamma_fine_f0_bits[41] = {
    12, 13, 13, 12, 12, 12, 12, 11,  9, 10,  9,  8,  8,  7,  7,  6,
     5,  5,  4,  4,  3,  3,  4,  4,  5,  5,  5,  5,  4,  3,  4,  7,
     8,  9, 10, 11, 11, 12, 12, 12, 12,
};

static const uint32_t acpl_hcb_gamma_fine_f0_codes[41] = {
    0x0004b6, 0x001c6d, 0x001c6c, 0x00049b, 0x0004b5, 0x0004b7, 0x000e35, 0x00024e,
    0x0001c7, 0x00038c, 0x000097, 0x000048, 0x0000e2, 0x000070, 0x000073, 0x000013,
    0x000008, 0x000017, 0x000005, 0x00000c, 0x000004, 0x000001, 0x00000d, 0x00000a,
    0x00001f, 0x00001e, 0x000016, 0x00001d, 0x000006, 0x000000, 0x000007, 0x000072,
    0x00004a, 0x000092, 0x00012c, 0x00024f, 0x00024c, 0x000e34, 0x0004b4, 0x00049a,
    0x000e37,
};

static const uint8_t acpl_hcb_gamma_coarse_df_bits[41] = {
    16, 16, 16, 16, 16, 16, 16, 16, 16, 15, 15, 14, 13, 13, 11, 10,
     8,  7,  4,  2,  1,  3,  5,  7,  8, 10, 11, 13, 13, 14, 15, 16,
    16, 16, 16, 16, 16, 16, 16, 16,  8,
};

static const uint32_t acpl_hcb_gamma_coarse_df_codes[41] = {
    0x0053e1, 0x0053e0, 0x0053db, 0x0053da, 0x0053d9, 0x0053e2, 0x0053e4, 0x0053ea,
    0x0053eb, 0x0029ea, 0x0029f4, 0x0014f4, 0x000a78, 0x000a7f, 0x000299, 0x00014d,
    0x000051, 0x00002a, 0x000004, 0x000000, 0x000001, 0x000003, 0x00000b, 0x00002b,
    0x000052, 0x00014e, 0x000298, 0x000a7e, 0x000a79, 0x0014f7, 0x0029f6, 0x0053ef,
    0x0053ee, 0x0053e7, 0x0053e6, 0x0053e3, 0x0053e5, 0x0053d8, 0x0053d7, 0x0053d6,
    0x000050,
};

static const uint8_t acpl_hcb_gamma_fine_df_bits[81] = {
    17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
    17, 17, 16, 16, 16, 15, 15, 15, 14, 14, 13, 13, 13, 12, 11, 11,
    10,  9,  8,  7,  6,  5,  4,  3,  1,  3,  4,  5,  6,  7,  9,  9,
    10, 11, 11, 12, 13, 13, 14, 14, 14, 15, 15, 15, 16, 16, 16, 17,
    17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17,
    17,
};

static const uint32_t acpl_hcb_gamma_fine_df_codes[81] = {
    0x013e1f, 0x013e35, 0x013e1e, 0x013e1d, 0x013e1c, 0x013e1b, 0x013e1a, 0x013e19,
    0x013e34, 0x013e33, 0x013e18, 0x013ec2, 0x013ec1, 0x013ece, 0x013edf, 0x013e17,
    0x013ede, 0x013edd, 0x009d52, 0x009f18, 0x009f1b, 0x004eaa, 0x004ea8, 0x004fb1,
    0x002753, 0x002757, 0x0013a8, 0x0013e0, 0x0013ee, 0x0009d6, 0x0004e9, 0x0004fa,
    0x00027b, 0x00013c, 0x00009c, 0x00004d, 0x000021, 0x000012, 0x00000b, 0x000007,
    0x000000, 0x000006, 0x00000a, 0x000011, 0x000020, 0x00004c, 0x00013f, 0x00013b,
    0x00027a, 0x0004f9, 0x0004e8, 0x0009d7, 0x0013ef, 0x0013e2, 0x0027da, 0x0027c7,
    0x002752, 0x004fb6, 0x004eac, 0x004eab, 0x009f65, 0x009d5a, 0x009d53, 0x013ecd,
    0x013edc, 0x013ecc, 0x013ecf, 0x013ec9, 0x013e32, 0x013ec3, 0x013e16, 0x013ec0,
    0x013ec8, 0x013e15, 0x013e14, 0x013e13, 0x013e12, 0x013e11, 0x013e10, 0x013ab7,
    0x013ab6,
};

static const uint8_t acpl_hcb_gamma_coarse_dt_bits[41] = {
    17, 17, 17, 17, 16, 17, 16, 16, 16, 15, 14, 13, 12, 12, 10,  9,
     8,  7,  5,  3,  1,  2,  4,  7,  8, 10, 11, 12, 13, 13, 14, 15,
    16, 16, 16, 17, 17, 17, 17, 17,  9,
};

static const uint32_t acpl_hcb_gamma_coarse_dt_codes[41] = {
    0x00a7f3, 0x00a7f1, 0x00a7f9, 0x00a7f8, 0x0050e1, 0x00a7fe, 0x0050e8, 0x0050eb,
    0x0053fe, 0x0029fd, 0x00143b, 0x000a1b, 0x00050c, 0x00053e, 0x000142, 0x0000a0,
    0x000052, 0x00002b, 0x00000b, 0x000003, 0x000001, 0x000000, 0x000004, 0x00002a,
    0x000051, 0x00014e, 0x00029e, 0x00050f, 0x000a7e, 0x000a1a, 0x001439, 0x002871,
    0x0050ea, 0x0050e9, 0x0050e0, 0x00a7ff, 0x00a7fb, 0x00a7fa, 0x00a7f2, 0x00a7f0,
    0x0000a6,
};

static const uint8_t acpl_hcb_gamma_fine_dt_bits[81] = {
    18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 17,
    17, 17, 17, 17, 16, 16, 16, 15, 15, 15, 14, 14, 13, 13, 12, 12,
    11, 10,  9,  8,  7,  6,  5,  2,  1,  3,  5,  6,  7,  8, 10, 10,
    11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 17, 17, 17, 17,
    17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18,
    18,
};

static const uint32_t acpl_hcb_gamma_fine_dt_codes[81] = {
    0x031e44, 0x031d1d, 0x031e42, 0x031e16, 0x031e41, 0x031e47, 0x031d1c, 0x031e43,
    0x031e73, 0x031e72, 0x031e15, 0x031e70, 0x031e75, 0x031e7f, 0x031e7e, 0x018e88,
    0x018d8b, 0x018e8f, 0x018f0e, 0x018f3e, 0x00c746, 0x00c796, 0x00c79e, 0x006361,
    0x0063c9, 0x0063d8, 0x0031d0, 0x0031e6, 0x0018d9, 0x0018f1, 0x000c6d, 0x000c7a,
    0x00063b, 0x00031c, 0x00018c, 0x0000c1, 0x000062, 0x000033, 0x00001b, 0x000002,
    0x000000, 0x000007, 0x00001a, 0x000032, 0x000061, 0x0000c0, 0x00031f, 0x00031a,
    0x000637, 0x000c75, 0x0018f7, 0x0018e9, 0x0031ed, 0x0031e0, 0x0063d9, 0x0063ca,
    0x006363, 0x006360, 0x00c786, 0x00c745, 0x018f3b, 0x018f2e, 0x018e89, 0x018d88,
    0x018d8a, 0x018d89, 0x031e5f, 0x031e74, 0x031e40, 0x031e71, 0x031e46, 0x031e5e,
    0x031e1f, 0x031e45, 0x031e1e, 0x031e14, 0x031e17, 0x031e13, 0x031e12, 0x031e11,
    0x031e10,
};

DECLARE_ASM_CONST(32, float, qwin)[640] = {
    0,
    1.990318758627504e-004,  2.494762615491542e-004,  3.021769445225078e-004,
    3.548460080857985e-004,  4.058915811480806e-004,  4.546408052001889e-004,
    5.012680176678405e-004,  5.464958142195282e-004,  5.912073950641334e-004,
    6.361178026937039e-004,  6.816060488244358e-004,  7.277257095064290e-004,
    7.743418255606097e-004,  8.212990636826637e-004,  8.685363488152327e-004,
    9.161071539925993e-004,  9.641168291303352e-004,  1.012630507392736e-003,
    1.061605258108620e-003,  1.110882587090581e-003,  1.160236901298543e-003,
    1.209448942573337e-003,  1.258362795150757e-003,  1.306902381715039e-003,
    1.355046337751365e-003,  1.402784629568410e-003,  1.450086694843816e-003,
    1.496898951224534e-003,  1.543170821958483e-003,  1.588889089195869e-003,
    1.634098242730728e-003,  1.678892372493930e-003,  1.723381173920660e-003,
    1.767651163797991e-003,  1.811741998614740e-003,  1.855650606587200e-003,
    1.899360915083620e-003,  1.942876625831283e-003,  1.986241654706626e-003,
    2.029534125962055e-003,  2.072840712410525e-003,  2.116229103721749e-003,
    2.159738034390673e-003,  2.203392976200947e-003,  2.247239773881968e-003,
    2.291373966775394e-003,  2.335946110021889e-003,  2.381132815654862e-003,
    2.427086732976290e-003,  2.473891839822582e-003,  2.521550367974952e-003,
    2.570013995199655e-003,  2.619244058999978e-003,  2.669265893796866e-003,
    2.720177146231281e-003,  2.772088849679780e-003,  2.825009494162980e-003,
    2.878716544061140e-003,  2.932677076291194e-003,  2.986067366389476e-003,
    3.037905983043366e-003,  3.087269477594307e-003,  3.133519274378684e-003,
    3.176460810085721e-003,  3.216374095471449e-003,  3.253902493849856e-003,
    3.289837867273167e-003,  3.324873276103132e-003,  3.359407689115599e-003,
    3.393454084675361e-003,  3.426668323773391e-003,  3.458465815999750e-003,
    3.488171121469781e-003,  3.515141351338780e-003,  3.538827383683883e-003,
    3.558767785536742e-003,  3.574539247363964e-003,  3.585697968628984e-003,
    3.591743339500398e-003,  3.592116764752254e-003,  3.586228204993297e-003,
    3.573492966885132e-003,  3.553356715665694e-003,  3.525300399274114e-003,
    3.488824092931520e-003,  3.443423145747434e-003,  3.388568319085867e-003,
    3.323699442173841e-003,  3.248231770523395e-003,  3.161568930730635e-003,
    3.063113666967670e-003,  2.952270973359112e-003,  2.828441943181057e-003,
    2.691016173288500e-003,  2.539366102140493e-003,  2.372848583221744e-003,
    2.190814088754598e-003,  1.992618085548526e-003,  1.777631090142623e-003,
    1.545242163079598e-003,  1.294855985911958e-003,  1.025885587325796e-003,
    7.377456851538827e-004,  4.298496740962311e-004,  1.016113723823784e-004,
   -2.475493814535340e-004, -6.181972580227641e-004, -1.010876063031582e-003,
   -1.426108207321696e-003, -1.864392667409557e-003, -2.326207721179968e-003,
   -2.812013688448634e-003, -3.322252633537029e-003, -3.857344314546718e-003,
   -4.417678415707104e-003, -5.003604409245843e-003, -5.615422427540850e-003,
   -6.253382198869787e-003, -6.917691380307223e-003, -7.608536937561301e-003,
   -8.326113472848559e-003, -9.070651572928327e-003, -9.842433610911637e-003,
   -1.064178450184536e-002, -1.146903570409307e-002, -1.232446526717138e-002,
   -1.320822893615923e-002,  1.412030102138547e-002,  1.506045143737221e-002,
    1.602824700934038e-002,  1.702310507234504e-002,  1.804435938034114e-002,
    1.909132707403387e-002,  2.016335321815832e-002,  2.125982139139435e-002,
    2.238013015948307e-002,  2.352365148441367e-002,  2.468968228813486e-002,
    2.587741357605385e-002,  2.708591966384863e-002,  2.831416731612567e-002,
    2.956103453432552e-002,  3.082532788511644e-002,  3.210578787607558e-002,
    3.340108247607704e-002,  3.470979250147262e-002,  3.603039785904666e-002,
    3.736126987823528e-002,  3.870067428980750e-002,  4.004677994303860e-002,
    4.139766786359423e-002,  4.275134353925827e-002,  4.410572893128047e-002,
    4.545866171224587e-002,  4.680788921400311e-002,  4.815106534667384e-002,
    4.948575188369231e-002,  5.080942296260306e-002,  5.211947012173918e-002,
    5.341320372603929e-002,  5.468785186395163e-002,  5.594055607104873e-002,
    5.716836923188953e-002,  5.836825629443718e-002,  5.953709945765930e-002,
    6.067170625396996e-002,  6.176881705202805e-002,  6.282510999827461e-002,
    6.383720245755561e-002,  6.480165083585107e-002,  6.571495100350305e-002,
    6.657354346196487e-002,  6.737381445564891e-002,  6.811211000439976e-002,
    6.878473991370719e-002,  6.938797895654626e-002,  6.991806618580000e-002,
    7.037120381110623e-002,  7.074355866301176e-002,  7.103126866531538e-002,
    7.123045563399449e-002,  7.133723888151840e-002,  7.134774334517399e-002,
    7.125810128129656e-002,  7.106444395777428e-002,  7.076288963679085e-002,
    7.034953453342756e-002,  6.982045490146145e-002,  6.917172452383333e-002,
    6.839944399575645e-002,  6.749977716975542e-002,  6.646898181809889e-002,
    6.530342654389224e-002,  6.399958984339946e-002,  6.255404354954748e-002,
    6.096342863203985e-002,  5.922443337469448e-002,  5.733378365410422e-002,
    5.528824660015738e-002,  5.308464739461209e-002,  5.071989148277166e-002,
    4.819098634672628e-002,  4.549505579582869e-002,  4.262934676625042e-002,
    3.959122947020497e-002,  3.637819581239452e-002,  3.298786054608736e-002,
    2.941796954479800e-002,  2.566640058060906e-002,  2.173117939155709e-002,
    1.761048656968719e-002,  1.330266415707108e-002,  8.806217289921706e-003,
    4.119815918461287e-003, -7.577038291607129e-004, -5.827337082489678e-003,
   -1.108990619665782e-002, -1.654605559674886e-002, -2.219624707735291e-002,
   -2.804075556277473e-002, -3.407966641908426e-002, -4.031287253355741e-002,
   -4.674007190475649e-002, -5.336076390182971e-002, -6.017424526940620e-002,
   -6.717960594283154e-002, -7.437572538762392e-002, -8.176127022450692e-002,
   -8.933469320120192e-002, -9.709423309043450e-002, -1.050379143754414e-001,
   -1.131635475471188e-001, -1.214687284677367e-001, -1.299508386078101e-001,
   -1.386070430802319e-001, -1.474342913196958e-001, -1.564293167898782e-001,
   -1.655886374953163e-001, -1.749085568711785e-001, -1.843851642116290e-001,
   -1.940143360850268e-001, -2.037917371113644e-001, -2.137128217101543e-001,
   -2.237728356363325e-001, -2.339668182208061e-001, -2.442896055908444e-001,
   -2.547358344658102e-001, -2.652999476893712e-001, -2.759762003673840e-001,
   -2.867586659726799e-001, -2.976412485679301e-001, -3.086176827721830e-001,
   -3.196815399704708e-001, -3.308262316588501e-001, -3.420450091826495e-001,
    3.533309414505971e-001,  3.646770149404552e-001,  3.760759747758828e-001,
    3.875204555118187e-001,  3.990029533969267e-001,  4.105158411581483e-001,
    4.220513789540003e-001,  4.336017251305980e-001,  4.451589452332786e-001,
    4.567150149423557e-001,  4.682618290579831e-001,  4.797912086537587e-001,
    4.912949058677955e-001,  5.027646134968753e-001,  5.141919746376279e-001,
    5.255685924518015e-001,  5.368860394090674e-001,  5.481358656081351e-001,
    5.593096071830315e-001,  5.703987947306394e-001,  5.813949615434598e-001,
    5.922896536434017e-001,  6.030744392774144e-001,  6.137409201916185e-001,
    6.242807411441345e-001,  6.346855991963545e-001,  6.449472531836600e-001,
    6.550575323798634e-001,  6.650083455855346e-001,  6.747916901830467e-001,
    6.843996616799759e-001,  6.938244627003839e-001,  7.030584122393319e-001,
    7.120939537241190e-001,  7.209236637533725e-001,  7.295402599029810e-001,
    7.379366091028713e-001,  7.461057359576386e-001,  7.540408314942230e-001,
    7.617352611504460e-001,  7.691825714586890e-001,  7.763765020733762e-001,
    7.833109874824341e-001,  7.899801646390305e-001,  7.963783815797485e-001,
    8.025002033685581e-001,  8.083404191294724e-001,  8.138940486031526e-001,
    8.191563476989879e-001,  8.241228138607196e-001,  8.287891904413357e-001,
    8.331514714928793e-001,  8.372059062705359e-001,  8.409490040631689e-001,
    8.443775395556067e-001,  8.474885573145614e-001,  8.502793750759253e-001,
    8.527475863595390e-001,  8.548910606594570e-001,  8.567079441260879e-001,
    8.581966597760032e-001,  8.593559096378087e-001,  8.601846769933608e-001,
    8.606822313166693e-001,  8.608481078185764e-001,  8.606822313166693e-001,
    8.601846769933608e-001,  8.593559096378087e-001,  8.581966597760032e-001,
    8.567079441260879e-001,  8.548910606594570e-001,  8.527475863595390e-001,
    8.502793750759253e-001,  8.474885573145614e-001,  8.443775395556067e-001,
    8.409490040631689e-001,  8.372059062705359e-001,  8.331514714928793e-001,
    8.287891904413357e-001,  8.241228138607196e-001,  8.191563476989879e-001,
    8.138940486031526e-001,  8.083404191294724e-001,  8.025002033685581e-001,
    7.963783815797485e-001,  7.899801646390305e-001,  7.833109874824341e-001,
    7.763765020733762e-001,  7.691825714586890e-001,  7.617352611504460e-001,
    7.540408314942230e-001,  7.461057359576386e-001,  7.379366091028713e-001,
    7.295402599029810e-001,  7.209236637533725e-001,  7.120939537241190e-001,
    7.030584122393319e-001,  6.938244627003839e-001,  6.843996616799759e-001,
    6.747916901830467e-001,  6.650083455855346e-001,  6.550575323798634e-001,
    6.449472531836600e-001,  6.346855991963545e-001,  6.242807411441345e-001,
    6.137409201916185e-001,  6.030744392774144e-001,  5.922896536434017e-001,
    5.813949615434598e-001,  5.703987947306394e-001,  5.593096071830315e-001,
    5.481358656081351e-001,  5.368860394090674e-001,  5.255685924518015e-001,
    5.141919746376279e-001,  5.027646134968753e-001,  4.912949058677955e-001,
    4.797912086537587e-001,  4.682618290579831e-001,  4.567150149423557e-001,
    4.451589452332786e-001,  4.336017251305980e-001,  4.220513789540003e-001,
    4.105158411581483e-001,  3.990029533969267e-001,  3.875204555118187e-001,
    3.760759747758828e-001,  3.646770149404552e-001, -3.533309414505971e-001,
   -3.420450091826495e-001, -3.308262316588501e-001, -3.196815399704708e-001,
   -3.086176827721830e-001, -2.976412485679301e-001, -2.867586659726799e-001,
   -2.759762003673840e-001, -2.652999476893712e-001, -2.547358344658102e-001,
   -2.442896055908444e-001, -2.339668182208061e-001, -2.237728356363325e-001,
   -2.137128217101543e-001, -2.037917371113644e-001, -1.940143360850268e-001,
   -1.843851642116290e-001, -1.749085568711785e-001, -1.655886374953163e-001,
   -1.564293167898782e-001, -1.474342913196958e-001, -1.386070430802319e-001,
   -1.299508386078101e-001, -1.214687284677367e-001, -1.131635475471188e-001,
   -1.050379143754414e-001, -9.709423309043450e-002, -8.933469320120192e-002,
   -8.176127022450692e-002, -7.437572538762392e-002, -6.717960594283154e-002,
   -6.017424526940620e-002, -5.336076390182971e-002, -4.674007190475649e-002,
   -4.031287253355741e-002, -3.407966641908426e-002, -2.804075556277473e-002,
   -2.219624707735291e-002, -1.654605559674886e-002, -1.108990619665782e-002,
   -5.827337082489678e-003, -7.577038291607129e-004,  4.119815918461287e-003,
    8.806217289921706e-003,  1.330266415707108e-002,  1.761048656968719e-002,
    2.173117939155709e-002,  2.566640058060906e-002,  2.941796954479800e-002,
    3.298786054608736e-002,  3.637819581239452e-002,  3.959122947020497e-002,
    4.262934676625042e-002,  4.549505579582869e-002,  4.819098634672628e-002,
    5.071989148277166e-002,  5.308464739461209e-002,  5.528824660015738e-002,
    5.733378365410422e-002,  5.922443337469448e-002,  6.096342863203985e-002,
    6.255404354954748e-002,  6.399958984339946e-002,  6.530342654389224e-002,
    6.646898181809889e-002,  6.749977716975542e-002,  6.839944399575645e-002,
    6.917172452383333e-002,  6.982045490146145e-002,  7.034953453342756e-002,
    7.076288963679085e-002,  7.106444395777428e-002,  7.125810128129656e-002,
    7.134774334517399e-002,  7.133723888151840e-002,  7.123045563399449e-002,
    7.103126866531538e-002,  7.074355866301176e-002,  7.037120381110623e-002,
    6.991806618580000e-002,  6.938797895654626e-002,  6.878473991370719e-002,
    6.811211000439976e-002,  6.737381445564891e-002,  6.657354346196487e-002,
    6.571495100350305e-002,  6.480165083585107e-002,  6.383720245755561e-002,
    6.282510999827461e-002,  6.176881705202805e-002,  6.067170625396996e-002,
    5.953709945765930e-002,  5.836825629443718e-002,  5.716836923188953e-002,
    5.594055607104873e-002,  5.468785186395163e-002,  5.341320372603929e-002,
    5.211947012173918e-002,  5.080942296260306e-002,  4.948575188369231e-002,
    4.815106534667384e-002,  4.680788921400311e-002,  4.545866171224587e-002,
    4.410572893128047e-002,  4.275134353925827e-002,  4.139766786359423e-002,
    4.004677994303860e-002,  3.870067428980750e-002,  3.736126987823528e-002,
    3.603039785904666e-002,  3.470979250147262e-002,  3.340108247607704e-002,
    3.210578787607558e-002,  3.082532788511644e-002,  2.956103453432552e-002,
    2.831416731612567e-002,  2.708591966384863e-002,  2.587741357605385e-002,
    2.468968228813486e-002,  2.352365148441367e-002,  2.238013015948307e-002,
    2.125982139139435e-002,  2.016335321815832e-002,  1.909132707403387e-002,
    1.804435938034114e-002,  1.702310507234504e-002,  1.602824700934038e-002,
    1.506045143737221e-002, -1.412030102138547e-002, -1.320822893615923e-002,
   -1.232446526717138e-002, -1.146903570409307e-002, -1.064178450184536e-002,
   -9.842433610911637e-003, -9.070651572928327e-003, -8.326113472848559e-003,
   -7.608536937561301e-003, -6.917691380307223e-003, -6.253382198869787e-003,
   -5.615422427540850e-003, -5.003604409245843e-003, -4.417678415707104e-003,
   -3.857344314546718e-003, -3.322252633537029e-003, -2.812013688448634e-003,
   -2.326207721179968e-003, -1.864392667409557e-003, -1.426108207321696e-003,
   -1.010876063031582e-003, -6.181972580227641e-004, -2.475493814535340e-004,
    1.016113723823784e-004,  4.298496740962311e-004,  7.377456851538827e-004,
    1.025885587325796e-003,  1.294855985911958e-003,  1.545242163079598e-003,
    1.777631090142623e-003,  1.992618085548526e-003,  2.190814088754598e-003,
    2.372848583221744e-003,  2.539366102140493e-003,  2.691016173288500e-003,
    2.828441943181057e-003,  2.952270973359112e-003,  3.063113666967670e-003,
    3.161568930730635e-003,  3.248231770523395e-003,  3.323699442173841e-003,
    3.388568319085867e-003,  3.443423145747434e-003,  3.488824092931520e-003,
    3.525300399274114e-003,  3.553356715665694e-003,  3.573492966885132e-003,
    3.586228204993297e-003,  3.592116764752254e-003,  3.591743339500398e-003,
    3.585697968628984e-003,  3.574539247363964e-003,  3.558767785536742e-003,
    3.538827383683883e-003,  3.515141351338780e-003,  3.488171121469781e-003,
    3.458465815999750e-003,  3.426668323773391e-003,  3.393454084675361e-003,
    3.359407689115599e-003,  3.324873276103132e-003,  3.289837867273167e-003,
    3.253902493849856e-003,  3.216374095471449e-003,  3.176460810085721e-003,
    3.133519274378684e-003,  3.087269477594307e-003,  3.037905983043366e-003,
    2.986067366389476e-003,  2.932677076291194e-003,  2.878716544061140e-003,
    2.825009494162980e-003,  2.772088849679780e-003,  2.720177146231281e-003,
    2.669265893796866e-003,  2.619244058999978e-003,  2.570013995199655e-003,
    2.521550367974952e-003,  2.473891839822582e-003,  2.427086732976290e-003,
    2.381132815654862e-003,  2.335946110021889e-003,  2.291373966775394e-003,
    2.247239773881968e-003,  2.203392976200947e-003,  2.159738034390673e-003,
    2.116229103721749e-003,  2.072840712410525e-003,  2.029534125962055e-003,
    1.986241654706626e-003,  1.942876625831283e-003,  1.899360915083620e-003,
    1.855650606587200e-003,  1.811741998614740e-003,  1.767651163797991e-003,
    1.723381173920660e-003,  1.678892372493930e-003,  1.634098242730728e-003,
    1.588889089195869e-003,  1.543170821958483e-003,  1.496898951224534e-003,
    1.450086694843816e-003,  1.402784629568410e-003,  1.355046337751365e-003,
    1.306902381715039e-003,  1.258362795150757e-003,  1.209448942573337e-003,
    1.160236901298543e-003,  1.110882587090581e-003,  1.061605258108620e-003,
    1.012630507392736e-003,  9.641168291303352e-004,  9.161071539925993e-004,
    8.685363488152327e-004,  8.212990636826637e-004,  7.743418255606097e-004,
    7.277257095064290e-004,  6.816060488244358e-004,  6.361178026937039e-004,
    5.912073950641334e-004,  5.464958142195282e-004,  5.012680176678405e-004,
    4.546408052001889e-004,  4.058915811480806e-004,  3.548460080857985e-004,
    3.021769445225078e-004,  2.494762615491542e-004,  1.990318758627504e-004,
};

static const float new_chirp_tab[4][4] = {
    { 0.0,  0.6,  0.0,  0.0,  },
    { 0.6,  0.75, 0.75, 0.75, },
    { 0.9,  0.9,  0.9,  0.9,  },
    { 0.98, 0.98, 0.98, 0.98, },
};

static const int8_t aspx_sine[2][4] = {
    { 1, 0, -1,  0 }, { 0, 1,  0, -1 },
};

static const float aspx_noise[512][2] = {
    {-0.782083, -0.623174}, { 0.705088, -0.70912}, { 0.268786, -0.9632},
    { 0.689305, -0.724471}, {-0.0430946, -0.999071}, {-0.998077, -0.0619922},
    { 0.867875, -0.496783}, { 0.814907, -0.579591}, { 0.880168, 0.474663},
    {-0.39062, -0.920552}, { 0.0434465, 0.999056}, { 0.610173, -0.792268},
    {-0.942195, 0.335065}, {-0.911161, 0.412052}, {-0.999084, -0.0427925},
    {-0.811795, 0.583942}, { 0.836524, 0.54793}, { 0.475443, 0.879747},
    { 0.961597, -0.274466}, { 0.820146, 0.572155}, {-0.498318, -0.866994},
    { 0.825586, -0.564277}, { 0.999973, 0.00730176}, { 0.895923, 0.44421},
    {-0.80517, -0.593044}, { 0.277753, 0.960652}, {-0.999688, 0.0249582},
    {-0.802608, -0.596507}, { 0.936737, -0.350035}, {-0.997477, -0.0709933},
    {-0.674713, -0.73808}, {-0.957686, -0.287817}, { 0.983532, 0.180732},
    { 0.634759, -0.77271}, {-0.150723, -0.988576}, {-0.113979, 0.993483},
    {-0.993827, -0.110942}, { 0.781536, 0.62386}, {-0.615104, -0.788446},
    {-0.586834, 0.809707}, {-0.226253, 0.974069}, { 0.949896, -0.312565},
    { 0.830084, 0.557638}, { 0.60415, 0.796871}, { 0.655412, 0.755272},
    {-0.916524, -0.399979}, { 0.763757, -0.645503}, { 0.822298, 0.569058},
    {-0.0283442, -0.999598}, {-0.644058, -0.764977}, {-0.390833, -0.920462},
    {-0.984217, -0.176967}, { 0.719987, 0.693987}, { 0.999088, -0.042707},
    { 0.754487, 0.656315}, { 0.498312, 0.866998}, { 0.999389, 0.0349481},
    {-0.811845, -0.583873}, { 0.532015, -0.846735}, {-0.463781, 0.88595},
    {-0.819481, -0.573106}, { 0.637789, 0.770211}, { 0.814253, -0.58051},
    { 0.180489, -0.983577}, { 0.988691, -0.149968}, { 0.606847, -0.794819},
    {-0.061914, 0.998081}, { 0.627066, 0.778966}, {-0.544097, -0.839023},
    {-0.859249, -0.511558}, {-0.91818, 0.396163}, {-0.165942, 0.986136},
    { 0.992322, 0.123685}, { 0.758555, 0.651609}, { 0.985543, -0.169427},
    {-0.154971, -0.987919}, { 0.245336, 0.969438}, {-0.522038, -0.852922},
    {-0.33027, -0.943886}, { 0.998067, -0.0621421}, { 0.516758, 0.856132},
    { 0.843123, -0.537721}, { 0.44306, 0.896492}, {-0.814913, 0.579584},
    {-0.336464, -0.941696}, { 0.732896, 0.68034}, { 0.201774, -0.979432},
    { 0.741954, 0.670451}, {-0.469083, 0.883154}, { 0.867784, 0.496941},
    { 0.494202, -0.869347}, { 0.9367, -0.350134}, { 0.906328, 0.422575},
    { 0.764111, 0.645085}, { 0.631052, -0.77574}, {-0.0498248, -0.998758},
    { 0.974691, -0.223555}, { 0.361405, -0.932409}, {-0.748625, 0.662994},
    { 0.811839, -0.583881}, { 0.303931, 0.952694}, {-0.992668, -0.120876},
    {-0.996672, -0.0815161}, {-0.324622, 0.945844}, {-0.0246385, -0.999696},
    {-0.588361, 0.808598}, {-0.49898, 0.866613}, { 0.924578, -0.380994},
    {-0.755619, 0.655011}, { 0.92214, -0.386857}, { 0.818638, 0.57431},
    {-0.920451, 0.390857}, { 0.0380205, -0.999277}, { 0.446606, -0.894731},
    { 0.722557, -0.691312}, { 0.762113, -0.647444}, {-0.256731, -0.966483},
    { 0.471301, -0.881972}, {-0.530869, -0.847454}, {-0.749876, 0.661579},
    {-0.593767, -0.804637}, {-0.834805, 0.550545}, { 0.748843, 0.662747},
    {-0.70794, 0.706273}, {-0.0503228, -0.998733}, { 0.402884, -0.915251},
    { 0.0945791, -0.995517}, {-0.390889, -0.920438}, {-0.0994705, -0.995041},
    {-0.767207, -0.641399}, {-0.563485, -0.826126}, {-0.521859, 0.853032},
    { 0.503637, 0.863915}, {-0.739851, -0.672771}, { 0.442624, -0.896707},
    {-0.997671, 0.0682121}, { 0.776117, -0.630589}, {-0.964601, -0.263713},
    {-0.656053, 0.754715}, {-0.865578, 0.500775}, {-0.586255, -0.810127},
    { 0.0425286, -0.999095}, { 0.656339, 0.754466}, {-0.341906, 0.939734},
    {-0.605904, 0.795538}, {-0.658238, -0.752809}, {-0.652856, 0.757482},
    {-0.994554, 0.104219}, { 0.176725, -0.98426}, {-0.231945, 0.972729},
    {-0.997717, -0.0675303}, {-0.997805, 0.0662198}, { 0.661155, 0.75025},
    { 0.999669, -0.02573}, {-0.946982, -0.321287}, {-0.587897, 0.808936},
    { 0.957862, -0.28723}, { 0.613392, -0.789779}, {-0.956489, 0.291768},
    { 0.169829, -0.985474}, {-0.943551, -0.331226}, { 0.416834, 0.908983},
    { 0.684727, -0.7288}, { 0.952329, 0.305074}, {-0.328392, 0.944541},
    { 0.943344, 0.331816}, { 0.650872, 0.759187}, {-0.59941, -0.800442},
    {-0.768448, -0.639912}, { 0.539894, 0.841733}, { 0.606048, -0.795428},
    { 0.403588, 0.914941}, {-0.838111, 0.545499}, { 0.976157, -0.217066},
    {-0.995495, -0.0948107}, {-0.943792, 0.330539}, {-0.990415, 0.138123},
    { 0.281355, 0.959604}, { 0.371208, 0.92855}, {-0.4711, 0.88208},
    {-0.999459, -0.0328787}, {-0.988179, 0.153305}, {-0.843124, -0.537718},
    { 0.997108, 0.0759971}, {-0.268201, -0.963363}, { 0.0457651, 0.998952},
    {-0.983762, 0.179479}, {-0.439728, -0.898131}, { 0.162945, -0.986635},
    {-0.055868, 0.998438}, {-0.384381, 0.923174}, { 0.744138, -0.668026},
    {-0.0706482, -0.997501}, { 0.831219, 0.555945}, { 0.711624, 0.70256},
    { 0.161772, -0.986828}, { 0.8387, 0.544593}, {-0.418108, 0.908397},
    { 0.412208, 0.91109}, {-0.986564, 0.163375}, { 0.925222, 0.379427},
    { 0.411092, -0.911594}, {-0.103885, -0.994589}, {-0.923358, -0.383941},
    {-0.761339, 0.648355}, {-0.887774, -0.46028}, { 0.755699, -0.654919},
    { 0.597832, -0.801622}, { 0.542946, -0.839768}, { 0.999842, -0.0177525},
    {-0.954864, 0.297044}, {-0.999961, -0.00886517}, { 0.929688, -0.368347},
    { 0.699205, 0.714921}, {-0.894118, 0.447831}, {-0.903496, 0.428597},
    { 0.362774, -0.931877}, { 0.850158, -0.526527}, { 0.523993, -0.851722},
    {-0.735767, 0.677235}, {-0.999673, -0.02558}, {-0.954685, 0.297619},
    {-0.195193, -0.980765}, { 0.0672577, -0.997736}, {-0.659842, -0.751405},
    { 0.779366, 0.626569}, { 0.751561, -0.659663}, {-0.34458, -0.938757},
    { 0.316872, 0.948468}, { 0.953601, 0.301074}, { 0.363243, 0.931694},
    {-0.537299, -0.843392}, { 0.996839, 0.0794518}, { 0.950462, -0.310842},
    { 0.224973, 0.974365}, {-0.772894, -0.634535}, {-0.94373, -0.330718},
    { 0.930603, 0.36603}, { 0.994059, 0.10884}, { 0.845518, -0.533947},
    { 0.988122, -0.15367}, { 0.880641, -0.473785}, { 0.783488, -0.621407},
    { 0.72854, 0.685004}, {-0.772294, 0.635265}, { 0.662444, 0.749111},
    {-0.0649291, 0.99789}, {-0.285125, 0.95849}, {-0.673637, -0.739062},
    {-0.394791, -0.918771}, {-0.938677, -0.344798}, {-0.708925, -0.705284},
    { 0.31416, 0.94937}, {-0.113645, 0.993521}, {-0.296446, 0.95505},
    { 0.670712, -0.741718}, {-0.605825, 0.795598}, { 0.996229, 0.0867643},
    { 0.686613, -0.727023}, {-0.740136, 0.672457}, { 0.876977, 0.480532},
    {-0.561046, 0.827785}, { 0.414562, -0.910021}, {-0.645953, -0.763377},
    { 0.802263, 0.596971}, {-0.854981, 0.51866}, {-0.769916, 0.638145}, { 0.648047, 0.7616},
    {-0.773406, 0.633911}, {-0.252579, -0.967576}, { 0.962561, -0.271064},
    { 0.959193, -0.282751}, { 0.727508, 0.686099}, {-0.667916, 0.744236},
    {-0.599333, 0.8005}, { 0.622504, 0.782616}, { 0.375433, -0.92685},
    {-0.9972, 0.0747742}, {-0.879355, 0.476166}, { 0.409574, 0.912277},
    { 0.747405, -0.664369}, {-0.940177, -0.340687}, { 0.562532, 0.826776},
    {-0.929015, 0.370041}, { 0.0978642, 0.9952}, { 0.916896, -0.399125},
    {-0.608038, -0.793908}, {-0.845653, -0.533732}, {-0.455945, -0.890008},
    { 0.923484, -0.383637}, { 0.354901, 0.934904}, { 0.319134, -0.94771},
    { 0.769603, -0.638523}, {-0.899207, 0.437524}, { 0.666669, -0.745354},
    { 0.142655, -0.989772}, {-0.892, -0.452035}, {-0.999915, -0.0130018},
    {-0.87033, 0.492469}, { 0.156511, 0.987676}, {-0.146752, 0.989173},
    {-0.809057, 0.58773}, {-0.497325, -0.867565}, {-0.258455, -0.966023},
    {-0.863292, -0.504705}, {-0.976343, -0.216225}, {-0.257626, -0.966245},
    { 0.809568, -0.587027}, { 0.582491, 0.812837}, {-0.997088, -0.0762565},
    {-0.878262, 0.47818}, {-0.165343, -0.986236}, { 0.0455161, 0.998964},
    {-0.570664, 0.821184}, { 0.658564, 0.752525}, { 0.319839, -0.947472},
    {-0.643905, -0.765106}, {-0.590256, 0.807216}, { 0.512137, 0.858904},
    {-0.998558, 0.0536785}, { 0.373964, -0.927443}, { 0.633108, -0.774063},
    {-0.968108, 0.250531}, { 0.787337, 0.616523}, { 0.698247, -0.715857},
    { 0.98937, 0.145419}, { 0.582241, -0.813016}, { 0.359617, 0.9331},
    {-0.758164, -0.652064}, { 0.635102, 0.772429}, {-0.0254028, -0.999677},
    { 0.266382, -0.963868}, { 0.660974, -0.750409}, { 0.585176, -0.810906},
    {-0.98243, 0.186631}, { 0.777252, -0.629189}, {-0.0267382, 0.999642},
    {-0.95591, 0.293661}, { 0.70368, -0.710517}, { 0.732467, -0.680803},
    { 0.854099, -0.52011}, { 0.536151, 0.844122}, {-0.00781503, 0.999969},
    {-0.534447, 0.845202}, { 0.297782, 0.954634}, { 0.905724, 0.423868},
    { 0.115617, -0.993294}, {-0.993408, -0.114636}, { 0.156977, 0.987602},
    { 0.639408, -0.768868}, {-0.995898, 0.0904832}, {-0.956372, 0.29215},
    { 0.990545, 0.137189}, { 0.659118, 0.75204}, {-0.0398563, -0.999205},
    {-0.679682, -0.733507}, {-0.540035, 0.841643}, {-0.0501135, -0.998744},
    {-0.196305, -0.980543}, { 0.56964, 0.821894}, {-0.703653, 0.710544},
    { 0.162676, -0.98668}, {-0.919545, 0.392984}, { 0.805179, 0.593031},
    { 0.998757, 0.0498406}, { 0.358168, 0.933657}, {-0.611152, -0.791513},
    {-0.440479, 0.897763}, { 0.292587, 0.956239}, {-0.217415, -0.976079},
    {-0.252622, -0.967565}, {-0.679998, -0.733214}, { 0.402652, -0.915353},
    {-0.993189, 0.116516}, { 0.0634956, 0.997982}, { 0.432309, -0.901725},
    { 0.923434, 0.383756}, {-0.502058, 0.864834}, { 0.935584, -0.353105},
    { 0.912111, -0.409944}, {-0.298643, 0.954365}, {-0.796165, 0.60508},
    {-0.741295, -0.671179}, { 0.856386, 0.516336}, {-0.515876, -0.856663},
    { 0.994745, -0.102384}, { 0.648698, -0.761046}, {-0.999675, -0.0254761},
    {-0.130115, 0.991499}, {-0.998787, 0.0492413}, { 0.27449, -0.96159},
    {-0.996501, -0.0835749}, {-0.387182, 0.922003}, { 0.701006, -0.713156},
    { 0.98733, -0.158679}, {-0.713847, 0.700302}, {-0.329606, 0.944118},
    { 0.279362, 0.960186}, {-0.968574, -0.248726}, {-0.68131, 0.731995},
    { 0.220789, -0.975322}, {-0.985566, -0.169292}, { 0.0132834, 0.999912},
    {-0.422317, 0.906448}, {-0.772023, -0.635594}, { 0.842036, -0.539421},
    {-0.803312, 0.595558}, { 0.725035, 0.688712}, { 0.328206, 0.944606},
    { 0.711898, 0.702283}, {-0.691674, 0.72221}, {-0.871274, 0.490797},
    { 0.213736, 0.976891}, { 0.255845, 0.966718}, { 0.883381, 0.468656}, {-0.596736, 0.802437},
    { 0.779861, 0.625953}, {-0.607233, 0.794524}, {-0.944679, -0.327996},
    { 0.851219, -0.52481}, {-0.859337, -0.51141}, { 0.953486, -0.301437},
    { 0.512244, -0.85884}, { 0.160393, 0.987053}, { 0.752002, 0.659161},
    { 0.999882, 0.0153624}, { 0.778011, -0.628251}, { 0.9293, -0.369326},
    {-0.605896, 0.795544}, { 0.633164, 0.774017}, {-0.923382, -0.383883},
    {-0.790911, 0.611931}, { 0.673492, 0.739195}, {-0.784902, 0.61962},
    { 0.289472, 0.957187}, { 0.605387, -0.795931}, {-0.459844, -0.888},
    {-0.990035, 0.140822}, {-0.686367, -0.727256}, {-0.549857, 0.835259},
    { 0.90982, 0.415003}, {-0.42105, 0.907037}, {-0.07295, 0.997336},
    {-0.24021, 0.970721}, { 0.993154, -0.116813}, {-0.59563, -0.803259},
    { 0.526545, -0.850147}, { 0.9987, -0.0509667}, {-0.85017, -0.526508},
    {-0.818838, -0.574025}, { 0.982094, 0.188394}, { 0.577634, -0.816296},
    {-0.418394, -0.908265}, { 0.62868, -0.777664}, {-0.118173, -0.992993},
    { 0.896113, 0.443827}, {-0.159857, -0.98714}, { 0.750036, 0.661397},
    { 0.745659, 0.666328}, {-0.938865, -0.344285}, {-0.583143, 0.812369},
    { 0.479122, 0.877748}, {-0.869898, -0.493231}, {-0.791797, 0.610784}, { 0.35785, 0.933779},
    { 0.25248, -0.967602}, {-0.573942, -0.818896}, {-0.930426, -0.366479},
    {-0.378158, 0.925741}, {-0.942114, 0.335293}, { 0.647836, -0.76178},
    { 0.814174, 0.580622}, { 0.023769, 0.999717}, { 0.112026, -0.993705},
    { 0.659378, -0.751811}, {-0.615064, -0.788477}, {-0.00328067, 0.999995},
    { 0.902263, -0.431186}, { 0.201174, -0.979556}, { 0.541589, 0.840644},
    {-0.996013, 0.0892081}, { 0.987237, 0.159261}, {-0.692353, 0.721559},
    { 0.940855, -0.338809}, { 0.164224, -0.986423}, { 0.0618662, 0.998084},
    { 0.784694, 0.619883}, { 0.156281, -0.987713}, {-0.424548, -0.905405},
    { 0.927622, 0.37352}, {-0.923711, 0.383089}, { 0.708767, -0.705442},
    {-0.941076, 0.338195}, {-0.268226, 0.963356}, { 0.653964, 0.756526},
    { 0.983767, -0.179452}, {-0.480029, 0.877253}, {-0.845565, -0.533873},
    {-0.768586, -0.639746}, { 0.208936, 0.977929}, { 0.512539, -0.858664},
    { 0.988163, -0.153409}, { 0.780816, 0.624761}, {-0.232748, 0.972537},
    { 0.988528, -0.151035}, {-0.106602, -0.994302}, {-0.633295, 0.773911},
    { 0.322068, -0.946717}, { 0.989632, -0.143627}, { 0.973492, -0.228721},
    { 0.998266, 0.0588631}, {-0.145619, 0.989341}
};

#endif /* AVCODEC_AC4DEC_DATA_H */
