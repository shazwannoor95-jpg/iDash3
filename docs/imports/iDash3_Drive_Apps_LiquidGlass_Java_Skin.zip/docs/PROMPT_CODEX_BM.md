# Prompt Codex — integrate skin sahaja

**Model disyorkan:** Sol Medium (integrasi kecil); Sol High hanya jika berlaku konflik UI atau regresi.

Saya sertakan ZIP `iDash3_Drive_Apps_Glass_Skin_Package.zip` yang mengandungi tiga kelas Java Native Android:
`ScenicBackdropDrawable.java`, `LiquidGlassStrokeDrawable.java`, `PageGlassSkin.java`.

Tugas: Integrasikan ke iDash3 **secara appearance-only** untuk dua halaman **Drive/map** dan **App Library**. Jangan ubah layout, teks, grid, navigasi, widget JAKIM, peta, panel media, waktu, fungsi search/refresh, split-screen, accessibility, wallpaper global ataupun click handler. Matlamat hanya menambah scenic background dan rim glass cyan/ungu pada surface yang sedia ada.

1. Semak fail kod semasa, khususnya `LauncherActivity.java`, `DrivePage.java`, `HomeGrid.java`, `IosStyle.java`, `GlassSurface.java`. Jangan buat andaian jika repo berubah daripada panduan.
2. Letak tiga fail Java pada package `com.shazwan.idash3` dan adapt jika perlu. Gunakan integrasi minimum dalam `LauncherActivity.render()` dan `filter()` seperti panduan.
3. Jangan ganti `GlassSurface` sedia ada; hanya tambah neon foreground pada komponen yang tidak menjejaskan ripple/interaction.
4. Pastikan area map masih jelas, carian Apps, klik ikon, pagination, dock, serta Drive split-screen bekerja seperti asal.
5. Performance untuk ARM32/API26+ dan 1GB RAM: tiada blur berulang, animasi berat, dependency tambahan atau objek grafik berlebihan per frame.
6. Jalankan `:app:assembleDebug` dan ujian yang tersedia; semak screenshot pada 800x480 dan 1024x600. Maklumkan jika ada regresi. **Jangan commit/push** ke GitHub.

Berikan laporan fail yang berubah dan hasil build; jika tidak dapat ujikan, nyatakan dengan jelas.
