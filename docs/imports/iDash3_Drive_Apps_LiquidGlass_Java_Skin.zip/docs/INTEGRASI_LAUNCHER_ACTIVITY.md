# Integrasi di LauncherActivity.java (Java asli iDash3)

Fail asal **tidak diubah** oleh ZIP ini. Sebelum buat patch, `git status` dan buat backup.

## 1. Copy tiga fail Java

Salin folder dalam `app/src/main/java/com/shazwan/idash3/` ke lokasi yang sama dalam projek iDash3. Jangan ubah package.

## 2. Panggil skin selepas halaman dan dock dibina

Dalam `LauncherActivity.java`, cari di hujung `render()`:

```java
buildDock(); updateClock();IosStyle.enter(body);
```

Tukar kepada:

```java
buildDock();
updateClock();
PageGlassSkin.apply(this, shell, body, page);
IosStyle.enter(body);
```

Pastikan panggilan **selepas** `buildDock()` supaya header, halaman dan dock turut diproses.

## 3. Panggil semula setelah grid apps dibina

Dalam `filter()`, tambah sebelum penutup fungsi:

```java
PageGlassSkin.refreshAppsGrid(this, grid);
```

**Penting:** `filter()` ada laluan `return` awal apabila tiada hasil carian. Jika ingin style seragam bagi keadaan itu, tambah panggilan yang sama **sebelum `return;` awal**. Tidak perlu salin atau menggantikan keseluruhan `filter()`.

## 4. Ujian

1. Jalankan `./gradlew :app:assembleDebug` dari akar repo (Windows: `gradlew.bat :app:assembleDebug`).
2. Pastikan `Drive` masih boleh memilih peta/media, bertukar sisi dan melancarkan split-screen.
3. Pastikan `Apps` masih boleh mencari, membuka dan menyemat app ke favorites.
4. Semak 800×480 serta 1024×600 dan tetapan contrast/light mode.
5. Perhatikan foreground pada mana-mana butang yang ada ripple/animasi tersendiri; jika foreground asal terganti, skip komponen itu dalam `styleTree`.

## Kekangan

- Gaya ini ialah **tiruan visual**: rim/gloss + gradient scenic, bukan salinan piksel tepat dari gambar dan **bukan blur langsung di belakang setiap kad**. Komponen `GlassSurface` sedia ada kekal sebagai material kaca.
- `PageGlassSkin` menukar latar `shell` hanya bagi halaman `drive` dan `apps`; peta dan kandungan asal tidak diubah.
- Kelas ini tidak menambah event handler, perubahan permission, atau panggilan web.
- Uji pada repo Codex semasa; jangan terus overwrite jika ada perubahan lain.
