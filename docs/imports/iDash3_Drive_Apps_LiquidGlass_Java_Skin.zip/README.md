# iDash3 Drive + Apps Glass Skin Package

**Tujuan:** membungkus kod dalam jawapan terdahulu: background scenic biru-magenta dan rim Liquid Glass cyan/ungu, hanya untuk halaman Drive dan Apps, tanpa mengubah fungsi/posisi UI.

## Kandungan

- `app/src/main/java/com/shazwan/idash3/ScenicBackdropDrawable.java`
- `app/src/main/java/com/shazwan/idash3/LiquidGlassStrokeDrawable.java`
- `app/src/main/java/com/shazwan/idash3/PageGlassSkin.java`
- `docs/INTEGRASI_LAUNCHER_ACTIVITY.md`
- `docs/PROMPT_CODEX_BM.md`

## Status

Sumber Java dan ZIP disediakan, bukan APK. Kelas-kelas ini perlu dimasukkan ke repo iDash3 dan dipanggil daripada `LauncherActivity.java`; ZIP ini **tidak** mengubah fail di GitHub dan **belum** disahkan dengan kompilasi Android/ujian peranti.

**Nota:** `PageGlassSkin` sengaja mengubah latar belakang shell untuk halaman Drive/Apps. Ia tidak membuang peta. Jika shell menggunakan latar lain dari branch terkini, sesuaikan aplikasi skin agar tidak menutup latar yang dikehendaki.
