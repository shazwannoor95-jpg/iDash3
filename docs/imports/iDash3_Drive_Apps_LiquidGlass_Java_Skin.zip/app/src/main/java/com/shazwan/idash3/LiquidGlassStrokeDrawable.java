package com.shazwan.idash3;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Decorative neon rim placed over an existing GlassSurface. */
final class LiquidGlassStrokeDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path gloss = new Path();
    private final RectF box = new RectF();
    private final float density;
    private final float radiusDp;

    LiquidGlassStrokeDrawable(float density, float radiusDp) {
        this.density = density;
        this.radiusDp = radiusDp;
    }

    private float dp(float v) { return v * density; }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        box.set(b.left + dp(1.2f), b.top + dp(1.2f),
                b.right - dp(1.2f), b.bottom - dp(1.2f));
        float r = Math.min(dp(radiusDp), Math.min(box.width(), box.height()) / 2f);

        paint.reset(); paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2.1f));
        paint.setShader(new LinearGradient(box.left, box.top, box.right, box.bottom,
                new int[]{0xaa37d8ff, 0x99f255ff}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(box, r, r, paint);

        paint.setShader(null); paint.setColor(0x7affffff); paint.setStrokeWidth(dp(1f));
        RectF inner = new RectF(box.left + dp(1.2f), box.top + dp(1.2f),
                box.right - dp(1.2f), box.bottom - dp(1.2f));
        canvas.drawRoundRect(inner, Math.max(0f, r-dp(1.2f)), Math.max(0f, r-dp(1.2f)), paint);

        RectF glossBox = new RectF(box.left + dp(5), box.top + dp(4),
                box.right - dp(5), box.top + box.height() * 0.42f);
        if (glossBox.width() > 0 && glossBox.height() > 0) {
            gloss.reset();
            gloss.addRoundRect(glossBox, new float[]{r,r,r,r,dp(18),dp(18),dp(18),dp(18)}, Path.Direction.CW);
            paint.setStyle(Paint.Style.FILL);
            paint.setShader(new LinearGradient(0, glossBox.top, 0, glossBox.bottom,
                    new int[]{0x38ffffff, 0x10ffffff, 0x00ffffff},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawPath(gloss, paint);
        }
        paint.setShader(new LinearGradient(0, box.centerY(), 0, box.bottom,
                new int[]{0x00000000, 0x14000000},
                new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(box, r, r, paint);
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter colorFilter) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
