package com.shazwan.idash3;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Lightweight scenic blue-to-magenta backdrop for Drive / Apps, no live blur. */
final class ScenicBackdropDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path hill1 = new Path();
    private final Path hill2 = new Path();
    private final Path hill3 = new Path();
    private final float density;

    ScenicBackdropDrawable(float density) {
        this.density = density;
    }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        canvas.save();
        canvas.translate(b.left, b.top);
        int w = b.width(), h = b.height();
        paint.reset();
        paint.setAntiAlias(true);
        paint.setShader(new LinearGradient(
                0, 0, w, h,
                new int[]{0xff1e7ec2, 0xff2d58b6, 0xff6c3eb8, 0xffb64d87},
                new float[]{0f, 0.32f, 0.70f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, paint);
        drawGlow(canvas, w * 0.12f, h * 0.10f, w * 0.22f, 0x663ee8ff);
        drawGlow(canvas, w * 0.82f, h * 0.14f, w * 0.24f, 0x55ff52d9);
        drawGlow(canvas, w * 0.55f, h * 0.80f, w * 0.30f, 0x33ff88c8);
        hill3.reset();
        hill3.moveTo(0, h * 0.82f);
        hill3.cubicTo(w * 0.18f, h * 0.72f, w * 0.36f, h * 0.92f, w * 0.52f, h * 0.84f);
        hill3.cubicTo(w * 0.72f, h * 0.73f, w * 0.86f, h * 0.90f, w, h * 0.78f);
        hill3.lineTo(w, h); hill3.lineTo(0, h); hill3.close();
        paint.setShader(null); paint.setColor(0x4017264f);
        canvas.drawPath(hill3, paint);
        hill2.reset();
        hill2.moveTo(0, h * 0.88f);
        hill2.cubicTo(w * 0.15f, h * 0.80f, w * 0.28f, h * 0.96f, w * 0.46f, h * 0.86f);
        hill2.cubicTo(w * 0.64f, h * 0.76f, w * 0.82f, h * 0.94f, w, h * 0.83f);
        hill2.lineTo(w, h); hill2.lineTo(0, h); hill2.close();
        paint.setColor(0x2a0d1735); canvas.drawPath(hill2, paint);
        hill1.reset();
        hill1.moveTo(0, h * 0.93f);
        hill1.cubicTo(w * 0.20f, h * 0.86f, w * 0.42f, h * 1.00f, w * 0.60f, h * 0.92f);
        hill1.cubicTo(w * 0.76f, h * 0.85f, w * 0.90f, h * 0.98f, w, h * 0.90f);
        hill1.lineTo(w, h); hill1.lineTo(0, h); hill1.close();
        paint.setColor(0x26081426); canvas.drawPath(hill1, paint);
        canvas.restore();
    }

    private void drawGlow(Canvas canvas, float cx, float cy, float radius, int color) {
        Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        glow.setShader(new RadialGradient(cx, cy, radius,
                new int[]{color, 0x00ffffff}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, radius, glow);
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter colorFilter) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
