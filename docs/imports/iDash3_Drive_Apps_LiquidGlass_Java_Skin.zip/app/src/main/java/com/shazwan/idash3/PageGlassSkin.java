package com.shazwan.idash3;

import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/** Appearance-only skin for Drive / App Library. No control or page logic changes. */
final class PageGlassSkin {
    private PageGlassSkin() {}

    static void apply(LauncherActivity a, View shell, View body, String page) {
        if (!"drive".equals(page) && !"apps".equals(page)) return;
        shell.setBackground(new ScenicBackdropDrawable(a.getResources().getDisplayMetrics().density));
        styleTree(a, shell, page);
    }

    static void refreshAppsGrid(LauncherActivity a, View grid) {
        if (grid != null) styleTree(a, grid, "apps");
    }

    private static void styleTree(LauncherActivity a, View v, String page) {
        if (v == null) return;
        if (v instanceof EditText && "apps".equals(page)) {
            v.setBackground(IosStyle.glass(a, 0x55ffffff, 18));
            attachForeground(v, 18f, a);
        }
        if (v.getBackground() instanceof GlassSurface) {
            attachForeground(v, guessRadiusDp(v, a), a);
        }
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            tv.setShadowLayer(a.dp(2), 0, a.dp(1), 0x35000000);
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) styleTree(a, g.getChildAt(i), page);
        }
    }

    private static void attachForeground(View v, float radiusDp, LauncherActivity a) {
        // API 26+ as configured by iDash3. Foreground is decoration only.
        if (Build.VERSION.SDK_INT >= 23 && !(v.getForeground() instanceof LiquidGlassStrokeDrawable)) {
            v.setForeground(new LiquidGlassStrokeDrawable(
                    a.getResources().getDisplayMetrics().density, radiusDp));
        }
    }

    private static float guessRadiusDp(View v, LauncherActivity a) {
        int h = v.getHeight();
        if (h <= 0 && v.getLayoutParams() != null) h = v.getLayoutParams().height;
        if (h <= 0) return 22f;
        float dpH = h / a.getResources().getDisplayMetrics().density;
        if (dpH <= 48) return 18f;
        if (dpH <= 64) return 20f;
        if (dpH <= 100) return 22f;
        return 26f;
    }
}
