# Status ujian & batas kesahihan

Disediakan: 19 November 2026.

## Pemeriksaan yang telah dibuat

- [x] Semua 6 sumber Java diparse menggunakan compiler JDK (`JavacTask.parse`) — **0 syntax errors**.
- [x] Nama package ialah `com.shazwan.idash3` dan folder sasaran selari dengan projek iDash3.
- [x] `UltraGlassSkin` hanya menyasarkan `page = drive` / `apps`; `GlassSurface` asal kekal sebagai background kawalan.
- [x] Tiada logik navigation, map, media, JAKIM, search ataupun aplikasi dipindahkan ke dalam kelas baru.
- [x] Bitmap adegan statik dipisahkan daripada teks/ikon; tiada UI baked-in dalam `mosque_road.webp`.
- [x] Animasi overlay boleh dihentikan melalui `UltraGlassSkin.pause()`.

## Perkara yang MASIH PERLU DIUJI oleh Codex/Android Studio

- [ ] `gradlew.bat :app:assembleDebug` — **belum dibina**, tiada Android SDK tempatan.
- [ ] Kesesuaian AGSL pada API 33/34/35 dan OEM shader compiler sebenar.
- [ ] Kesan pemasangan `LayerDrawable` apabila suatu View sudah mempunyai foreground sendiri.
- [ ] Ketepatan sudut membulat terhadap setiap saiz widget dan density head unit.
- [ ] Prestasi frame time/GPU memory jika 60 fps aktif pada banyak butang serentak.
- [ ] Ujian skrin Drive semasa peta hidup, Lokasi, dan dialog permission.
- [ ] Ujian App Library semasa Search, Refresh dan long-press.
- [ ] Semakan visual bersebelahan `reference/`.

## Had platform yang tidak boleh dihapuskan hanya dengan mengubah kod

- `RuntimeShader` memerlukan **API 33+**.
- `RenderEffect` memerlukan **API 31+** dan memburamkan kandungan lapisan yang dipasang, bukan secara automatik mengaburkan apa sahaja di belakangnya.
- Refraction / blur pada *live map* memerlukan pipeline compositing berasingan; kod ini tidak mengaktifkannya secara palsu.
- Paparan akhir tetap terikat pada prestasi GPU head unit, memori sebenar dan versi Android OEM.

## Penanda aras digalakkan

Ambil screenshot 1024×600 dan 800×480 untuk Drive/Apps, periksa UI dalam mod landscape serta onPause/onResume. Jangan buat `git push` sehingga pengguna meluluskan.
