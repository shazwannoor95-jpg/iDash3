# Prompt Codex — Integrasi iDash3 ULTRA Liquid Glass

**Model disyorkan: Sol High (integrasi shader/animasi pertama). Pilihan jimat: Sol Medium untuk pembaikan kecil selepas build stabil.**

Anda ialah Senior Android Java Graphics Engineer bagi projek `https://github.com/shazwannoor95-jpg/iDash3`.

Saya lampirkan ZIP `iDash3_ULTRA_LiquidGlass_Drive_Apps.zip`. Ini ialah versi **eksperimen maksimum**, bukan versi ringan iDash3.

**Objektif:** Integrasikan *appearance-only* Ultra Liquid Glass pada halaman Drive (map) dan App Library (Apps) sahaja. JANGAN ubah kedudukan, saiz asas atau fungsi apa-apa elemen dalam screenshot. JANGAN tambah page/widget baru. JANGAN ubah peta, aplikasi, komponen media, klik, swipe, carian, JAKIM atau perkhidmatan split-screen. Panel peta mesti tetap berfungsi secara langsung dan tidak ditukar menjadi gambar.

1. Audit dahulu `LauncherActivity.java`, `DrivePage.java`, `HomeGrid.java`, `GlassSurface.java`, `IosStyle.java`, `GlassPerf.java`, kemudian baca `docs/INTEGRASI_BM.md`.
2. Salin enam fail Java dan satu aset WebP mengikut struktur. Kekalkan fail/fungsi asal.
3. Integrasi `UltraGlassSkin.apply(this,shell,page)` selepas `buildDock()`; tambah `UltraGlassSkin.pause/resume` dalam lifecycle; `afterAppsFiltered` selepas senarai Apps dibina semula jika perlu.
4. `UltraGlassOverlay` ialah lapisan foreground visual; kekalkan `GlassSurface` sebagai latar. Jangan tangkap atau memintas sentuhan. Jangan letak refleksi berat di atas teks.
5. Gunakan GPU AGSL pada Android13+ untuk caustics; jangan gunakan API33 tanpa pemeriksaan versi. Gunakan versi Android lama hanya sebagai fallback—profil ini memang disasarkan ke peranti moden.
6. Blur GPU yang menggunakan `RenderEffect` boleh diuji pada lapisan backdrop **berasingan** API31+, bukan pada TextView/ViewGroup yang menempatkan teks, bukan pada peta. Helper `UltraGlassBlurPreview` adalah opsyen eksperimen, tidak automatik.
7. Pastikan visual mirip screenshot rujukan di folder `reference/` tanpa mengubah struktur elemen. Utamakan ketepatan reka bentuk dan Liquid Glass berkualiti tinggi.
8. Jalankan `:app:assembleDebug`, lint, uji tekan semua kawalan, layout screenshot pada 1024x600 dan 800x480, dan semak memory/frame pacing. Laporkan apa yang gagal secara jujur.
9. Jangan commit atau push sebarang perubahan GitHub. Bekerja pada salinan kerja tempatan sahaja dan sediakan diff/laporan.

**Penting:** Jika `PageGlassSkin` atau `NeonPageSkin` daripada kit lama sudah digunakan, jangan gunakan dua skin serentak. Gantikan panggilan appearance sahaja secara terkawal.
