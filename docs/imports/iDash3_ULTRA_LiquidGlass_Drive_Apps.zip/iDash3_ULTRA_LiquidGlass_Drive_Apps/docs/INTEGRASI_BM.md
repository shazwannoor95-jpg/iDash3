# Cara Integrasi ULTRA ke iDash3 (tanpa ubah susun atur)

Repo rujukan: `https://github.com/shazwannoor95-jpg/iDash3` pada branch `main` semasa semakan. Fokus kod asal: `LauncherActivity.java`, `IosStyle.java`, `GlassSurface.java`, `DrivePage.java` dan `HomeGrid.java`.

## 1. Fail baharu

Salin **enam** fail Java dalam `app/src/main/java/com/shazwan/idash3/` ke path yang sama dalam projek lokal. Salin `app/src/main/assets/ultraglass/mosque_road.webp` ke path yang sama.

Jangan overwrite `GlassSurface.java`, `DrivePage.java`, `DriveController.java`, `HomeGrid.java`, `JakimCalendar.java` atau mana-mana fail lama.

## 2. LauncherActivity.java — render()

Kod asal lebih kurang:

```java
if("apps".equals(page)) buildDrawer();
else if("drive".equals(page)) DrivePage.build(this,body);
else if("settings".equals(page)){settingsScreen=new DashSettings(this);settingsScreen.build(body);}
else buildHome();
buildDock();
updateClock();
IosStyle.enter(body);
```

**Tambah SATU panggilan sahaja selepas `buildDock()`** (jangan salin seluruh fungsi jika Codex sudah mengubahnya):

```java
buildDock();
UltraGlassSkin.apply(this, shell, page);  // rupa Drive & Apps sahaja
updateClock();
IosStyle.enter(body);
```

Bagi halaman lain, `UltraGlassSkin.apply` tidak mengubah apa-apa.

## 3. onPause / onResume — lifecycle animasi

Sisipkan pada fungsi Activity yang memang wujud:

```java
// Dalam onPause(), sebelum super.onPause():
UltraGlassSkin.pause(this);

// Dalam onResume(), selepas super.onResume():
UltraGlassSkin.resume(this);
```

Ini penting: efek 60 fps tidak boleh terus berputar apabila aplikasi di belakang. Dalam `render()`, session lama turut dihentikan.

## 4. filter() — App Library

Panggil ini selepas grid aplikasi dibina semula, termasuk kes "tiada hasil":

```java
UltraGlassSkin.afterAppsFiltered(this, grid);
```

Jika tiada elemen glass baharu dalam grid, ia hanyalah no-op. **Jangan** ubah loop grid, kaedah pagination, ikon aplikasi atau search handler.

## 5. Kawalan visual

Dalam `UltraGlassConfig.java`:

- `SCENE_FOR_DRIVE = true`: hanya latar luar peta, bukan ganti peta.
- `SCENE_FOR_APPS = false`: background biru/ungu/magenta abstrak tanpa widget tambahan.
- `FRAME_TIME_MS = 16`: sekitar 60 fps, tiada adaptive limiter.
- `ENABLE_AGSL = true`: caustics shader berfungsi pada API33+ sahaja.
- `ENABLE_ANIMATION = true`: glint hidup.

Tiada mod prestasi rendah automatik dalam kit ini.

## 6. Ujian minimum sebelum guna APK

1. Jalankan `./gradlew :app:assembleDebug` (Windows: `gradlew.bat :app:assembleDebug`).
2. Buka Drive, uji pemilihan PETA dan MEDIA, swap, permission status, `Mula Drive` dan `Tutup`.
3. Buka Apps: uji Search, Refresh, Done, long press favorite, ikon dan pagination jika ada.
4. Buka JAKIM, FM Radio, Settings dan Home: pastikan UI asal tidak berubah.
5. Periksa `onPause/onResume` supaya animasi berhenti dan sambung seperti sepatutnya.
6. Uji API33+, 1024x600 dan 800x480 (jika disasarkan juga); pastikan perkataan, butang dan peta tidak dilindungi glow.
7. Ukur frame time/GPU memory sebelum pertimbangkan dipasang pada head unit sebenar.

## Nota keselamatan integrasi

- Jangan `git commit` atau `git push` tanpa arahan pengguna.
- Jika versi ringan `PageGlassSkin.apply(...)` sudah digunakan, **buang panggilan versi ringan** sebelum mengaktifkan Ultra—jangan skin dua kali.
- Jika Codex telah menyusun semula `LauncherActivity`, integrasi perlu dibuat secara manual dan diuji, bukan replace keseluruhan file.
