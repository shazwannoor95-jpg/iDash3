# iDash3 — ULTRA Liquid Glass / Drive & App Library (eksperimen)

**Versi tanpa had prestasi buatan daripada profil iDash3 lama.** Ini ialah kit kod Java sumber, **bukan APK**. Repo asal tidak disentuh. Kit ini berasingan daripada ZIP `iDash3_Drive_Apps_LiquidGlass_Java_Skin.zip` yang ringan.

## Tujuan

Hanya **rupa** bagi dua halaman: **Drive / peta** dan **App Library / Apps**. Susun atur, bilangan dan kedudukan butang, peta hidup, ikon aplikasi sebenar, bar sisi/dock, Search/Refresh/Done, pilihan map/media dan semua fungsi split-screen **kekal menggunakan kod sedia ada**.

## Apa yang baharu

- `UltraGlassOverlay`: halo neon cyan/ungu/merah jambu berlapis, rim prisma, top sheen, filem kaca telus, sweep glint pada 60 fps, dan AGSL caustics **API 33+**.
- `UltraGlassScene`: latar Drive menggunakan imej pemandangan tanpa teks; latar Apps menggunakan gradient, ambient glow dan bukit parametrik. Panel peta **tidak diganti**.
- `UltraGlassSkin`: tambah lapisan **di atas** komponen dengan `GlassSurface` sedia ada; tidak mengubah click/touch handlers, layout params atau logik.
- `UltraGlassBlurPreview`: pilihan **API 31+** untuk blur GPU pada *salinan imej backdrop sahaja* apabila ada panel `FrameLayout` yang menyokong lapisan belakang khusus. **Tidak diaktifkan secara lalai** kerana ia memerlukan tambahan lapisan, dan blur seluruh View akan turut mengaburkan teks.
- `UltraGlassAgsl`: shader Android 13+ untuk specular/caustics (tiada rendering dependency pihak ketiga).

## Sasaran

Untuk **reka bentuk maksimum di hardware moden**. `compileSdk 35` di repo sudah cukup untuk API 33. Kode Java 8 masih digunakan. Efek penuh memerlukan **Android 13+ dengan hardware-accelerated rendering**. Pada peranti API 26–32, shader AGSL tidak tersedia dan ada fallback Canvas; ia **bukan visual maksimum**. Ini tidak menjamin head unit lama 1GB RAM akan lancar—versi ini sengaja tidak mematuhi had prestasi `GlassPerf.low()`.

## Apa yang belum dilakukan

- Tidak ada live backdrop-blur/refraction pada kandungan *peta bergerak*. Meniru ini tanpa menukar pokok view memerlukan komposit/capture khusus.
- Tiada `RenderEffect` dipasang terus ke kad sedia ada kerana ia mengaburkan kandungan kad sendiri, bukan semestinya latar di belakangnya.
- Kelas ini **belum lulus build Android Studio**, ujian emulator atau head unit; hanya syntax parse dapat dijalankan di sini.
- Tiada jaminan gambar AI boleh dihasilkan piksel-sebiji oleh kod Canvas.

## Struktur

```
app/src/main/java/com/shazwan/idash3/
  UltraGlassConfig.java
  UltraGlassScene.java
  UltraGlassOverlay.java
  UltraGlassAgsl.java
  UltraGlassSkin.java
  UltraGlassBlurPreview.java
app/src/main/assets/ultraglass/
  mosque_road.webp
reference/
  drive_original_reference.png
  apps_original_reference.png
docs/
  INTEGRASI_BM.md
  PROMPT_CODEX_BM.md
  SEMAKAN.md
```

**Mula di `docs/INTEGRASI_BM.md`**; pastikan Codex tidak campurkan dua versi lama/baru sekali gus.
