package com.shazwan.idash3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewGroup;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.WeakHashMap;

/**
 * Non-destructive appearance-only plugin for Drive and App Library.
 * No layout params, app list, map, click listeners, Drive controller, or JAKIM logic changed.
 *
 * Place AFTER buildDock() so existing View instances can be decorated in place.
 */
final class UltraGlassSkin {
    private UltraGlassSkin(){}
    private static final WeakHashMap<LauncherActivity,Session> active = new WeakHashMap<>();

    static void apply(LauncherActivity host,View shell,String page){
        Session old=active.remove(host);if(old!=null)old.dispose();
        if(!"apps".equals(page)&&!"drive".equals(page))return;
        Session session=new Session();active.put(host,session);
        boolean scenic="drive".equals(page)?UltraGlassConfig.SCENE_FOR_DRIVE:UltraGlassConfig.SCENE_FOR_APPS;
        shell.setBackground(new UltraGlassScene(scenic?loadArtwork(host):null,scenic));
        decorate(host,shell,session);
        session.resume();
    }

    /** Call after search results/grid have been reconstructed, if new glass controls were added. */
    static void afterAppsFiltered(LauncherActivity host,View grid){
        Session session=active.get(host);
        if(session!=null&&grid!=null)decorate(host,grid,session);
    }

    /** Call from onPause / onResume. Prevents GPU animations in background. */
    static void pause(LauncherActivity host){Session s=active.get(host);if(s!=null)s.stop();}
    static void resume(LauncherActivity host){Session s=active.get(host);if(s!=null)s.resume();}

    private static Bitmap loadArtwork(LauncherActivity host){
        try(InputStream in=host.getAssets().open("ultraglass/mosque_road.webp")){
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inPreferredConfig=Bitmap.Config.ARGB_8888;
            options.inScaled=false;
            return BitmapFactory.decodeStream(in,null,options);
        }catch(IOException|RuntimeException failed){return null;}
    }

    private static void decorate(LauncherActivity host,View v,Session session){
        if(v==null)return;
        Drawable bg=v.getBackground();
        // Existing GlassSurface is STILL the background: only add chromatic rim over it.
        if(bg instanceof GlassSurface && !session.viewDecorations.containsKey(v)){
            float radius=radius(v,host);
            UltraGlassOverlay overlay=new UltraGlassOverlay(host.getResources().getDisplayMetrics().density,radius);
            Drawable original=v.getForeground();
            if(original==null)v.setForeground(overlay);
            else v.setForeground(new LayerDrawable(new Drawable[]{original,overlay}));
            session.items.add(new WeakReference<>(overlay));
            session.viewDecorations.put(v,overlay);
            final UltraGlassOverlay fx=overlay;
            v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){
                @Override public void onViewAttachedToWindow(View attached){if(session.playing)fx.start();}
                @Override public void onViewDetachedFromWindow(View detached){fx.stop();}
            });
        }
        if(v instanceof ViewGroup){
            ViewGroup group=(ViewGroup)v;
            for(int i=0;i<group.getChildCount();i++)decorate(host,group.getChildAt(i),session);
        }
    }

    private static float radius(View v,LauncherActivity a){
        ViewGroup.LayoutParams params=v.getLayoutParams();
        float dp=a.getResources().getDisplayMetrics().density;
        int px=params==null?0:params.height;
        if(px<=0)px=v.getHeight();
        float h=px>0?px/Math.max(.1f,dp):100;
        if(h<55)return 20;
        if(h<110)return 22;
        return 26;
    }

    private static final class Session {
        final ArrayList<WeakReference<UltraGlassOverlay>> items=new ArrayList<>();
        final WeakHashMap<View,UltraGlassOverlay> viewDecorations=new WeakHashMap<>();
        boolean playing;
        void resume(){playing=true;for(WeakReference<UltraGlassOverlay> r:items){UltraGlassOverlay g=r.get();if(g!=null)g.start();}}
        void stop(){playing=false;for(WeakReference<UltraGlassOverlay> r:items){UltraGlassOverlay g=r.get();if(g!=null)g.stop();}}
        void dispose(){stop();items.clear();viewDecorations.clear();}
    }
}
