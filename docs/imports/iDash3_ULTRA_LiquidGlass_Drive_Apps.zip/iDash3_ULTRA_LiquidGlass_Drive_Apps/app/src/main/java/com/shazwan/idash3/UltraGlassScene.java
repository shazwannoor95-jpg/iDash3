package com.shazwan.idash3;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Pure scenery behind the existing Drive / Apps views. No icon, map, or app UI is painted here. */
final class UltraGlassScene extends Drawable {
    private final Bitmap backdrop;
    private final boolean useScenery;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path mountains = new Path();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private int alpha = 255;

    UltraGlassScene(Bitmap scenic, boolean useScenery) {
        this.backdrop = scenic;
        this.useScenery = useScenery;
    }

    @Override public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        c.save();
        c.translate(b.left, b.top);
        c.clipRect(0, 0, b.width(), b.height());
        float w = b.width(), h = b.height();

        p.reset();p.setAntiAlias(true);p.setFilterBitmap(true);p.setAlpha(alpha);
        p.setShader(new LinearGradient(0,0,w,h,
            new int[]{0xff045080,0xff122a70,0xff452271,0xff9f347c},
            new float[]{0f,.32f,.70f,1f},Shader.TileMode.CLAMP));
        c.drawRect(0,0,w,h,p);
        p.setShader(null);

        if (useScenery && backdrop != null && !backdrop.isRecycled()) {
            // CENTER_CROP; static artwork never contains UI or baked-in text.
            float cropRatio = Math.max(w / backdrop.getWidth(), h / backdrop.getHeight());
            int sw = Math.min(backdrop.getWidth(), Math.max(1,Math.round(w / cropRatio)));
            int sh = Math.min(backdrop.getHeight(),Math.max(1,Math.round(h / cropRatio)));
            src.set((backdrop.getWidth()-sw)/2,(backdrop.getHeight()-sh)/2,
                (backdrop.getWidth()+sw)/2,(backdrop.getHeight()+sh)/2);
            dst.set(0,0,w,h);
            p.setAlpha(alpha);
            c.drawBitmap(backdrop,src,dst,p);
            p.setShader(new LinearGradient(0,0,0,h,
                new int[]{0x22031530,0x10000000,0x33061131},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);
            p.setShader(null);
        } else {
            // High-resolution pure Canvas atmosphere for App Library; no JPG/PNG UI ghosts.
            glow(c,.10f*w,.10f*h,.43f*w,0x8861dfff);
            glow(c,.85f*w,.28f*h,.48f*w,0x88ff52d5);
            glow(c,.55f*w,.75f*h,.35f*w,0x557f87ff);
            hill(c,w,h,.78f,.08f,0x45423c89);
            hill(c,w,h,.87f,.13f,0x5536317f);
            hill(c,w,h,.95f,.08f,0x55201552);
        }
        // Ambient colour wash and bottom satin glow, spatially limited.
        glow(c,.20f*w,h*1.03f,.50f*w,0x5543bfff);
        glow(c,.83f*w,h*1.02f,.54f*w,0x77ff36dc);
        c.restore();
    }

    private void glow(Canvas c,float x,float y,float radius,int color){
        p.setShader(new RadialGradient(x,y,Math.max(1,radius),
            new int[]{color,Color.TRANSPARENT},null,Shader.TileMode.CLAMP));
        c.drawCircle(x,y,radius,p);p.setShader(null);
    }
    private void hill(Canvas c,float w,float h,float y,float variance,int color){
        mountains.reset();
        mountains.moveTo(0,h*y);
        mountains.cubicTo(w*.14f,h*(y-variance),w*.24f,h*(y+variance),w*.42f,h*y);
        mountains.cubicTo(w*.62f,h*(y-variance),w*.79f,h*(y+variance),w,h*(y-variance*.3f));
        mountains.lineTo(w,h);mountains.lineTo(0,h);mountains.close();
        p.setColor(color);c.drawPath(mountains,p);p.setColor(Color.WHITE);
    }
    @Override public void setAlpha(int value){alpha=value;invalidateSelf();}
    @Override public void setColorFilter(ColorFilter filter){p.setColorFilter(filter);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
