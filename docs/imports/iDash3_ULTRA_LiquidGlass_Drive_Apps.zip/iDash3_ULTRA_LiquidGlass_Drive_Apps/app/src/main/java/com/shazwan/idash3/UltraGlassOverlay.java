package com.shazwan.idash3;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.SystemClock;

/**
 * Animated ULTRA glass rim. Added as View foreground so it NEVER replaces an
 * existing GlassSurface, widget, listener, or map content.
 *
 * Composition: cached diffuse neon halo + white bevel + chromatic edge +
 * specular streak + moving light sweep + optional AGSL caustics (API33+).
 */
final class UltraGlassOverlay extends Drawable implements Animatable {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF box=new RectF(), inner=new RectF();
    private final Path rim=new Path(),inside=new Path();
    private final float density, requestedRadius;
    private Shader staticGradient, topGradient, agsl;
    private Bitmap cachedHalo;
    private boolean running;
    private long startTime;
    private int alpha=255;
    private final Runnable frame=new Runnable(){@Override public void run(){
        if(!running)return;
        invalidateSelf();
        scheduleSelf(this,SystemClock.uptimeMillis()+UltraGlassConfig.FRAME_TIME_MS);
    }};

    UltraGlassOverlay(float density,float radiusDp){
        this.density=Math.max(.5f,density);
        this.requestedRadius=radiusDp;
        if(UltraGlassConfig.ENABLE_AGSL && Build.VERSION.SDK_INT>=33){
            try{agsl=Api33.create();}catch(RuntimeException|LinkageError unsupported){agsl=null;}
        }
    }

    private float dp(float n){return n*density;}

    @Override protected void onBoundsChange(Rect b){
        // Leave old Bitmap to GC; RenderThread may still have an in-flight draw command.
        cachedHalo=null;
        float w=b.width(),h=b.height();
        if(w<8||h<8)return;
        float inset=dp(3),radius=Math.min(dp(requestedRadius),Math.min(w,h)*.5f);
        box.set(inset,inset,w-inset,h-inset);
        inner.set(box);inner.inset(dp(2.6f),dp(2.6f));
        rim.reset();rim.setFillType(Path.FillType.EVEN_ODD);
        rim.addRoundRect(box,radius,radius,Path.Direction.CW);
        float inRadius=Math.max(1f,radius-dp(2.6f));
        rim.addRoundRect(inner,inRadius,inRadius,Path.Direction.CW);
        inside.reset();inside.addRoundRect(box,radius,radius,Path.Direction.CW);
        staticGradient=new LinearGradient(0,0,w,h,
            new int[]{0xff5ce9ff,0xff9ccfff,0xffdb5dff,0xffff79df},
            new float[]{0f,.37f,.70f,1f},Shader.TileMode.CLAMP);
        topGradient=new LinearGradient(0,box.top,0,box.top+Math.max(1f,h*.48f),
            new int[]{0x45ffffff,0x10ffffff,0x00ffffff},
            new float[]{0f,.30f,1f},Shader.TileMode.CLAMP);
        if(UltraGlassConfig.ENABLE_STATIC_HALOS)cacheHalo(Math.round(w),Math.round(h),radius);
    }

    private void cacheHalo(int w,int h,float r){
        if(w<=0||h<=0)return;
        try{
            Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
            Canvas c=new Canvas(b);
            Paint glow=new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE);
            glow.setShader(staticGradient);
            // Several broad translucent layers imitate optical bloom without a full-screen post-FX pass.
            float[] widths={dp(16),dp(11),dp(7),dp(4.4f)};
            int[] levels={13,19,29,45};
            for(int i=0;i<widths.length;i++){
                glow.setStrokeWidth(widths[i]);glow.setAlpha(levels[i]);
                c.drawRoundRect(box,r,r,glow);
            }
            cachedHalo=b;
        }catch(OutOfMemoryError insufficient){cachedHalo=null;}
    }

    @Override public void draw(Canvas canvas){
        Rect b=getBounds();if(b.width()<=8||b.height()<=8)return;
        canvas.save();canvas.translate(b.left,b.top);
        final float w=b.width(),h=b.height();
        final float radius=Math.min(dp(requestedRadius),Math.min(w,h)*.5f);
        float seconds=running?(SystemClock.uptimeMillis()-startTime)/1000f:0f;

        if(cachedHalo!=null && !cachedHalo.isRecycled()){
            p.reset();p.setAntiAlias(true);p.setAlpha(alpha);
            canvas.drawBitmap(cachedHalo,0,0,p);
        }

        // Matte liquid film: remains transparent, protecting actual text and icons.
        p.reset();p.setAntiAlias(true);p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0,0,w,h,
            new int[]{0x1407bcef,0x070b204d,0x0eff56df},null,Shader.TileMode.CLAMP));
        canvas.drawRoundRect(box,radius,radius,p);p.setShader(null);

        // High-end AGSL caustics. Only internal glass film, not a destructive blur of the View's text.
        if(UltraGlassConfig.ENABLE_CAUSTICS && agsl!=null && canvas.isHardwareAccelerated()){
            try{
                Api33.update(agsl,w,h,seconds);
                canvas.save();canvas.clipPath(inside);
                p.setShader(agsl);p.setAlpha(Math.round(alpha*.8f));
                canvas.drawRect(0,0,w,h,p);
                canvas.restore();p.setShader(null);
            }catch(RuntimeException shaderFailure){agsl=null;p.setShader(null);}
        }

        // Top prism reflection and subtle glass bevel.
        canvas.save();canvas.clipPath(inside);p.setStyle(Paint.Style.FILL);p.setShader(topGradient);
        canvas.drawRect(0,0,w,h*.48f,p);p.setShader(null);canvas.restore();

        p.setStyle(Paint.Style.STROKE);p.setShader(staticGradient);p.setAlpha(Math.min(255,alpha));
        p.setStrokeWidth(dp(1.8f));canvas.drawRoundRect(box,radius,radius,p);
        p.setShader(null);p.setColor(0xaaffffff);p.setStrokeWidth(dp(.72f));
        canvas.drawRoundRect(inner,Math.max(1f,radius-dp(2.6f)),Math.max(1f,radius-dp(2.6f)),p);

        // Animated white/blue/pink traveling glint: clipped to narrow rim ONLY.
        if(UltraGlassConfig.ENABLE_ANIMATION && running){
            float x=w*(.1f+.8f*(.5f+.5f*(float)Math.sin(seconds*.76f)));
            p.setStyle(Paint.Style.FILL);
            p.setShader(new RadialGradient(x,box.top+dp(2),Math.max(dp(45),w*.22f),
                new int[]{0xbbffffff,0x6656e7ff,0x00ffffff},
                new float[]{0f,.32f,1f},Shader.TileMode.CLAMP));
            canvas.drawPath(rim,p);p.setShader(null);
        }
        canvas.restore();
    }

    @Override public void start(){
        if(running || !UltraGlassConfig.ENABLE_ANIMATION)return;
        running=true;startTime=SystemClock.uptimeMillis();
        unscheduleSelf(frame);invalidateSelf();
        scheduleSelf(frame,SystemClock.uptimeMillis()+UltraGlassConfig.FRAME_TIME_MS);
    }
    @Override public void stop(){running=false;unscheduleSelf(frame);}
    @Override public boolean isRunning(){return running;}
    @Override public boolean setVisible(boolean visible,boolean restart){
        boolean changed=super.setVisible(visible,restart);
        if(!visible)stop();
        return changed;
    }
    @Override public void setAlpha(int a){alpha=Math.max(0,Math.min(255,a));invalidateSelf();}
    @Override public void setColorFilter(ColorFilter filter){p.setColorFilter(filter);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}

    /** Isolates Android 13-only classes from Android 8/11 verifier loading. */
    private static final class Api33 {
        static Shader create(){return UltraGlassAgsl.create();}
        static void update(Shader s,float w,float h,float t){UltraGlassAgsl.update((android.graphics.RuntimeShader)s,w,h,t);}
    }
}
